---
name: work-the-pipeline-and-contracts
description: "Find warm opportunities in Sessionboard CRM, move them through the pipeline, and send or void contracts on your OK."
---

# Work your pipeline and send contracts

The person gets their pipeline moving: warm people found, the right Contacts in the right stage for the right event, every move recorded with a note, and agreements sent for e-signature and tracked to the signed PDF. It works the same for a self-serve CRM workspace and a full-platform organization. Plan limits and role permissions are enforced by Sessionboard, not by you.

The pipeline and contracts take **Contact** ids. A person in People and their Contact are two records linked by email, never one: a person who is not yet a Contact is made one with `add_people_to_crm_contacts` (ask first), and nothing is merged.

## When to use

Use this when someone wants to work their Sessionboard CRM pipeline and contracts — find warm people nobody is working yet, put speakers, sponsors or exhibitors in the pipeline for an event, move them between stages with a note, take someone off, send a speaker, sponsor or exhibitor agreement for e-signature from a template, check who has signed, email a signer again, or void a contract. Triggers on "who should we be talking to?", "warm opportunities", "add these five to the pipeline for Summit 2027", "move Dana to confirmed", "who is still in contacted?", "send Dana the speaker agreement", "has Acme signed?", "resend the sponsor contract", "void that contract", "get me the signed PDF".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Scopes: `read:crm` to read, `write:crm` to add, move, archive, send or void. They are preview scopes, so they must be named explicitly when the connector or key is set up.
- Sessionboard checks the person's org **Contacts** permissions for the pipeline (READ to look, UPDATE to add or move), and the org **Contracts** permissions for contracts (read to look, create to send, update to resend, delete to void; adding a starter template needs create and update). Contracts must also be turned on for the organization. A role limited to some portfolios is refused here; that person uses Contacts in Sessionboard.

## Guardrails (read first)

- **Confirm before every write or send.** Before adding, moving, archiving, sending, resending or voiding, show exactly what will change (names, stage, event, counts) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Sending a contract reaches someone outside the organization and cannot be taken back, only voided.** Before `send_crm_contract`, name the template, the title, the recipient's name and email (from `get_crm_contact`), the event and any custom subject or message. Pass `confirmed: true` only after the person says yes to exactly that. A resend is a new send: ask again.
- **Voiding cannot be undone.** Name the contract and the signer, ask, then pass `confirmed: true`. A new contract can be sent afterwards.
- **Archiving takes someone off the pipeline.** Their Contact, history and contracts stay. To record a no, offer to move them to declined or future fit instead. `confirmed: true` only after a yes.
- **Contract wording and signer roles** are edited by a person in Sessionboard's template editor; no tool changes them.
- Adding to the pipeline, moving and archiving email no one. Words: say **stage** for the pipeline, **prospect** (never "lead"), **sponsor** (never "partner"). Never name the in-product assistant or internal engines.

## The workflow

1. **Pick the event.** When the person names an event for the pipeline, find it: `find_event { search }`. If more than one matches (for example the 2026 and 2027 editions), ask which. Use its id in steps 4 and 8.
2. **Find who to work.** `find_warm_opportunities { event_id?, type?, member?, sort?, page?, per_page? }`: people who came to five or more webinars or events, are not in the pipeline and are not customers, busiest first. Its `event_id` means "attended that event": never pass the event the pipeline is for (an upcoming event has no attendees, so it returns no one); pass it only when the person asks for people who came to a past event. Or search: `find_crm_people { q?, roles?, in_pipeline?, ... }`. This changes nothing; suggest a next step.
   - "The top one" or "the best few": rank by `events_attended` + `webinars_attended`, then the most recent `last_signal_at`. The answer has no score; if people still tie, show them and ask which.
3. **Get Contact ids.** A row from `find_crm_people` shows whether the person is a Contact. If they are not:
   **Pause:** "Dana Lee and 2 others aren't Contacts yet. Make them Contacts so they can go in the pipeline? It emails no one."
   On yes: `add_people_to_crm_contacts { keys, types? }` (types: speaker, sme, influencer, exhibitor, sponsor). Its answer gives each person's `contact_id` (`people[].contact_id`): use those; no second lookup is needed. `find_crm_contacts { q }` is for Contacts that already existed.
4. **Read the pipeline.** `get_crm_pipeline { q?, stage_id?, type?, tag_id?, event_id?, sort?, page?, per_page? }` returns the stages with counts and the entries. Use the stage ids from `stages`. One entry's history: `get_crm_pipeline { entry_id }`.
5. **Add to the pipeline.**
   **Pause:** "Add these 5 Contacts to the pipeline in Identified, for Summit 2027?"
   `add_to_crm_pipeline { contact_ids, stage_id?, event_id? }` (up to 200; first stage by default). Anyone already in it comes back in `already`: say who. It takes Contact ids only and never makes a Contact from a person's key: step 3 comes first.
6. **Move a stage.**
   **Pause:** "Move Dana Lee from Contacted to Confirmed, with the note 'Agreed to keynote'?"
   `move_crm_pipeline_entry { entry_id, stage_id?, note?, event_id? }`. A note goes only with a stage move. Every move is kept in the history.
7. **Take someone off.**
   **Pause:** "Take Sam Ortiz off the pipeline? Their Contact and contracts stay. Or move them to Declined instead?"
   `archive_crm_pipeline_entry { entry_id, confirmed: true }`.
8. **Pick a template.** `list_crm_contract_templates {}`, before any contract pause. Only a published template can be sent. If it answers in plain text that contracts are not turned on for the organization (it may add "so nothing was sent" although nothing was being sent), stop the contract part here: say contracts are off for the organization and a person with admin rights asks Sessionboard support. Do not offer to send. If the organization has none, offer a starter: ask, then `add_crm_contract_starter { key: "speaker" | "sponsor" | "exhibitor" }` (created and published; sends nothing).
9. **Send a contract.** Read the recipient with `get_crm_contact { contact_id }`.
   **Pause:** "Send 'Summit 2027 Speaker Agreement' (template: Speaker agreement) to Dana Lee <dana@example.org> for Summit 2027, with the default email? Once sent it can only be voided."
   On a clear yes: `send_crm_contract { contact_id, template_id, title?, event_id?, email_subject?, email_message?, confirmed: true }`.
10. **Check status.** `list_crm_contracts { q?, status?, contact_id?, sort?, page?, per_page? }` (statuses: created, sent, delivered, completed, declined, voided; `facets.statuses` counts them). One contract: `get_crm_contract { contract_id, include_pdf? }` gives each signer's status and when they viewed, signed or declined. With `include_pdf: true`, `pdf_url` is a short-lived link once everyone has signed, and `null` before that.
11. **Email the signer again.**
    **Pause:** "Email Dana Lee the signing link for 'Summit 2027 Speaker Agreement' again?"
    `send_crm_contract { contract_id, confirmed: true }`.
12. **Void.**
    **Pause:** "Void 'Acme Sponsorship 2027' sent to Pat Kim? The signing link stops working and it cannot be brought back."
    `void_crm_contract { contract_id, reason?, confirmed: true }`.

## When something goes wrong

- **"Not sent / Not voided / Not archived: tell the person …"**: `confirmed: true` was missing. Ask, then call again only after a yes.
- **"This Contact already has a contract out for signature from this template"**: nothing was sent. Offer a resend with `contract_id`.
- **"Already in the pipeline"**: nothing was added.
- **"Contracts are not turned on for this organization yet"** (`FEATURE_NOT_ENABLED`): it shows first on `list_crm_contract_templates`, as plain text rather than a code. Nothing was sent; a person with admin rights asks Sessionboard support.
- **403 "This connection cannot use Sessionboard CRM"**: missing `read:crm` / `write:crm`, or the role lacks the Contacts or Contracts permission. If scopes were added after connecting, disconnect and reconnect.
- **Read-only** (`trial_ended`, `plan_ended`, `paused`, `payment_due`, `read_only`): everything can still be read; a person with admin rights fixes the plan in CRM → Plan and billing. **`yearly_only`**: paid CRM plans are billed yearly.
- **404**: check Contact ids with `find_crm_contacts`, entry and stage ids with `get_crm_pipeline`, contract ids with `list_crm_contracts`.

## What this skill does not do

- It cannot edit a template's wording or signer roles, add or rename pipeline stages, or export the pipeline or contracts (the CRM pages export CSV).
- It does not email a prospect outside a contract; invitations and outreach are campaigns in Sessionboard Marketing.
- It cannot sign on anyone's behalf or mark a contract signed.

## Tools used

- `find_event` — find the event the pipeline is for (read)
- `find_warm_opportunities` — people who know the organization and nobody is working (read)
- `find_crm_people` — search People (read)
- `add_people_to_crm_contacts` — make people Contacts so they can enter the pipeline (write)
- `find_crm_contacts` — look up ids of Contacts that already existed (read)
- `get_crm_contact` — the recipient's name, email and history (read)
- `get_crm_pipeline` — stages, entries, or one entry's history (read)
- `add_to_crm_pipeline` — put Contacts in a stage for an event (write)
- `move_crm_pipeline_entry` — move a stage with a note (write)
- `archive_crm_pipeline_entry` — take an entry off, `confirmed: true` (write)
- `list_crm_contract_templates` — published templates and starters (read)
- `add_crm_contract_starter` — add a speaker, sponsor or exhibitor starter (write)
- `send_crm_contract` — send or resend for e-signature, `confirmed: true` (sends)
- `list_crm_contracts` — contracts by status (read)
- `get_crm_contract` — signers, history and the signed PDF link (read)
- `void_crm_contract` — void a contract, `confirmed: true` (write)
