---
name: build-the-agenda
description: "Set rooms and tracks, place sessions and publish an event's agenda in Sessionboard, or work its agenda drafts and scheduling rules."
---

# Build and publish the agenda

The person gets a scheduled agenda: rooms and tracks set, accepted sessions in time slots without clashes, sponsors tagged, and the agenda and speaker wall on their website once they say so. It works for any Sessionboard organization: a self-serve Sessions workspace and a full-platform account use the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

There are two ways to schedule. Pick one per event and say which:

- **Path A, the agenda (default).** Place sessions directly with the Sessions tools. Use it for every event in `get_sessions_home`, and for any event when the person just wants sessions placed.
- **Path B, agenda drafts (full-platform events).** Plan placements in a draft, guided by written scheduling rules, preview the changes, then commit them to the real sessions. Use it when the event already has drafts (`read_agenda_drafts { action: "list" }` returns some) or the person asks for a draft, scenarios or rules.

## When to use

Use this when someone wants to set up rooms and tracks, put accepted sessions into time slots and rooms, find clashes, add a keynote or a break, tag sponsors on sessions, publish the agenda and speaker wall to their website, or (on a full-platform event) plan the schedule in an agenda draft with scheduling rules and commit it. Triggers on "build the agenda", "schedule the sessions", "put the keynote at 9 in the main hall", "add a lunch break", "rename Room B to Ballroom", "any clashes?", "who is double-booked?", "tag Acme on the AI panel", "publish the agenda to our website", "give me the agenda embed", "draft a schedule that keeps the medical track in the morning", "commit the draft".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Path A needs `read:sessions` to read and `write:sessions` to change. Any organization member who can use the event reads; changes and publishing need an organization admin. A connection limited to particular events is refused.
- Path B reads with the connection's standard access and writes with `write:events`; `list_sessions` needs `read:sessions`. Sessionboard applies the person's own event permissions.
- Path A event ids are numbers; Path B tools take the event id as a string (`"6815"`). Times are ISO 8601 with an offset, read on the event's clock.

## Guardrails (read first)

- **Confirm before every write or publish.** Before `set_rooms_and_tracks`, `manage_program_session`, `manage_event_sponsors`, `publish_event_agenda`, `manage_agenda_draft`, `manage_draft_sessions` or `manage_event_rules`, show exactly what will change (session, old and new time and room, the full room list, the rule text) and get a clear yes in this conversation. One yes can cover a list of placements you showed line by line. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Publishing waits for a person in Sessionboard.** `publish_event_agenda` answers `needs_approval` with a URL: say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again for the same event.
- **Once published, the embeds update live.** Every later change to a session shows on the website at once. Say so before changing a published agenda.
- **Committing a draft changes the real sessions** (start, end, room). Preview with `read_agenda_drafts { action: "get_changes" }` first. Commit only the sessions the person agreed to.
- Room, track and format lists are whole lists: anything left out is removed (unless a session uses it).
- Words: say "agenda", "session", "room", "track". Never name the in-product assistant or internal engines.

## The workflow — Path A: the agenda

1. **Read it.** `get_event_agenda { event_id }`: accepted sessions with time, room, track and sponsor tags; the rooms, tracks and sponsors to choose from; the event's days; `conflicts` (speaker or room overlaps); whether it is published. Lead with what is unscheduled and any clashes.
2. **Rooms and tracks.** `set_rooms_and_tracks { event_id, rooms?, tracks?, formats? }`. Keep one by `id` with its name (a new name renames it), add one with a name only. **Pause:** show each full new list and anything that will be removed.
3. **Place sessions.** Propose a grid (time, room, session). Avoid the clashes `conflicts` describes: the same speaker or room at overlapping times (back-to-back is fine; a start with no end counts as 30 minutes). **Pause:** show each placement. On yes, one call per session:
   `manage_program_session { action: "update", event_id, session_id, starts_at?, ends_at?, room_id?, track_id?, title?, description? }`. `""` clears a time, room or track.
4. **Add a keynote, panel or break.** **Pause:** title, description, speakers (each with an email). On yes: `manage_program_session { action: "add", event_id, title, description?, speakers? }` (accepted at once), then place it as in step 3. Speakers count toward the plan's speakers per event.
5. **Sponsors on sessions.** Add a sponsor to the event: `manage_event_sponsors { action: "add", event_id, name, website? }`. Tag sessions: `manage_program_session { action: "update", event_id, session_id, sponsor_ids }` with the **full** list for that session (`[]` removes all). Removing a sponsor (`manage_event_sponsors { action: "remove", event_id, sponsor_id }`) also untags its sessions: say so.
6. **Check again.** `get_event_agenda { event_id }`: confirm no `conflicts` remain and every session has a time and room.
7. **Publish.** **Pause:** show the agenda by day and which embeds (agenda and speakers by default; schedule and rooms are also available). Ask "Publish this to your website?" On yes:
   `publish_event_agenda { event_id, widgets?, asked }`. It answers `needs_approval`: say "Waiting for your OK in Sessionboard: <url>" and stop. Once approved it returns the embed snippets to paste into their pages.

## The workflow — Path B: agenda drafts and rules (full-platform events)

1. **Sessions and rooms.** `list_sessions { event_id, page?, limit? }` (up to 100 a page) for session ids; `list_metadata { event_id, entity_type: "room" }` for room ids.
2. **Rules.** `read_event_rules { action: "list", event_id }`. A rule is plain text ("Keep the medical track before lunch"). To add one: **Pause:** show the text. On yes: `manage_event_rules { action: "create", event_id, name, references?, draft_ids?, order? }` (`references` are field ids it refers to). Change or remove: `{ action: "update" | "delete", event_id, rule_id, … }`, each after a yes.
3. **The draft.** `read_agenda_drafts { action: "list", event_id }`. To start one: **Pause:** title and day hours. On yes: `manage_agenda_draft { action: "create", event_id, title?, description?, day_start_time?, day_end_time? }` (`HH:mm`).
4. **Placements.** `list_draft_sessions { event_id, draft_id }` shows what is placed. **Pause:** show the placements you propose. On yes:
   - one: `manage_draft_sessions { action: "create", event_id, draft_id, session_id, starts_at?, ends_at?, room_id?, reason? }`;
   - change or pin: `{ action: "update", event_id, draft_id, draft_session_id, starts_at?, ends_at?, room_id?, is_pinned?, reason? }`;
   - remove: `{ action: "delete", event_id, draft_id, draft_session_id }`;
   - many (up to 100): `{ action: "bulk", event_id, draft_id, operations: [{ action, session_id?, draft_session_id?, data? }] }`.
   Nothing changes on the real agenda yet.
5. **Preview the changes.** `read_agenda_drafts { action: "get_changes", event_id, draft_id }`: show each session's current and new time and room.
6. **Commit.** **Pause:** "This changes the real time and room of these N sessions: … Commit?" On yes: `manage_agenda_draft { action: "commit", event_id, draft_id, session_ids? }` (leave out `session_ids` only when the person agreed to all). Committed placements leave the draft.
7. A draft no longer needed: `manage_agenda_draft { action: "delete", event_id, draft_id }` after a yes.

## When something goes wrong

- Path A 403 "… is not part of this Sessions plan" (`enterprise_only`): e.g. more speakers than the plan includes. Nothing changed; a person with admin rights chooses a bigger plan in Sessions → Plan and billing.
- `trial_ended` / `plan_ended`: read-only; everything can still be read.
- 409 `in_use`: a session still uses that room or track. Move those sessions first (`manage_program_session`), then try again. "Partly done: the room list was saved, but the track list was not changed": read the agenda again and send only the track update.
- Path A 403 "Forbidden … read:sessions …": missing scope or not an organization admin. 404: check ids with `get_sessions_home` / `get_event_agenda`.
- Path B errors read "Error: API <status> …": 403 is a missing scope (`write:events`) or permission; 404 a wrong draft, rule or session id; 400 says what to fix. Read again before retrying.

## What this skill does not do

- No automatic scheduler: you propose placements, the person agrees.
- Publishing on the platform's Program Site is done in Sessionboard; `publish_event_agenda` gives embeds for the organizer's own website.
- Cannot unpublish the embeds.
- No speaker availability or travel constraints beyond what rules and `conflicts` show.

## Tools used

- `get_sessions_home` — Sessions events (read)
- `get_event_agenda` — the agenda, rooms, tracks, sponsors, days, clashes, published state (read)
- `set_rooms_and_tracks` — the full room, track and format lists (write)
- `manage_program_session` — add a session or change its time, room, track, sponsors (write)
- `manage_event_sponsors` — add or remove an event sponsor (write)
- `publish_event_agenda` — agenda and speaker wall embeds (write; waits in Sessionboard)
- `list_sessions` — a full-platform event's sessions and ids (read)
- `list_metadata` — a full-platform event's rooms (read)
- `read_event_rules` — scheduling rules (read)
- `manage_event_rules` — create, change or remove a rule (write)
- `read_agenda_drafts` — drafts and their pending changes (read)
- `manage_agenda_draft` — create, change, delete or commit a draft (write; commit changes real sessions)
- `list_draft_sessions` — placements in a draft (read)
- `manage_draft_sessions` — create, change, pin, remove or bulk-place sessions in a draft (write)
