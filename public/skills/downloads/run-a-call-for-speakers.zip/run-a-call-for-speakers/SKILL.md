---
name: run-a-call-for-speakers
description: Open, edit or close a Sessionboard call for speakers and its questions, and watch submissions come in.
---

# Run your call for speakers

The person gets a call for speakers (the event's submission form) that says what they want, asks the questions they need, opens on their OK, and a running view of what has come in. It works for any Sessionboard organization: a self-serve Sessions workspace and a full-platform account use the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to set up, open, edit, extend or close the call for speakers for an event, change the questions speakers answer, set the tracks and formats speakers pick from, or see what has come in. Triggers on "open our call for speakers", "set up the CFP for the summit", "change the welcome text", "add a question about audience level", "make the bio required", "extend the deadline to March 1", "close submissions", "what's the link to submit?", "how many submissions so far?", "any new proposals this week?", "enter this proposal someone emailed me".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Reading needs the `read:sessions` scope; changes need `write:sessions`. A connection limited to particular events is refused; it needs an organization-wide connection.
- Any organization member who can use the event can read. Changing the call, its questions and lists needs an organization admin. A role that sees only some contacts is refused here and uses the event's Sessions pages instead.
- Event ids here are numbers. `get_sessions_home` lists the Sessions events; on a full-platform account `find_event` or `list_events` also give the id.

## Guardrails (read first)

- **Confirm before every write.** Before `manage_sessions_event`, `manage_call_for_speakers`, `manage_call_questions`, `set_rooms_and_tracks` or `manage_program_session`, show exactly what will change (the text, the date, the question, the full list) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Opening the call waits for a person in Sessionboard.** `manage_call_for_speakers { action: "open" }` answers `needs_approval` with a URL. Say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again for the same event.
- **Question changes are live at once.** They reach the public form immediately; nothing is emailed. Removing a question keeps the answers already given: say how many (`answered`) before you remove it.
- Title, Description, First name, Last name and Email are always asked and always required (`locked`). Do not try to remove them or make them optional.
- Conditional questions (shown only after a certain answer), a second form, submission fees and committee Review (Review plans, Reviewers, Rounds) are the Sessionboard platform. Say so; do not try another way.
- Speakers who submit get a confirmation email. Decisions are emailed only through the review skill's decision emails.
- Words: say "call for speakers" or "submission form", "submission", "accept / decline". Never "evaluation", "evaluator" or "judge". Never name the in-product assistant or internal engines.

## The workflow

### 1. Find or create the event
1. `get_sessions_home {}`: the plan, every Sessions event with its counts and whether its call is open. It lists Sessions events only, so on a full-platform account an empty list is normal: `find_event { search }` finds the event by name.
2. If there is no event yet: **Pause:** show the name, start and end (date and time; if the person gives only days, propose 09:00 to 17:00 on the event's clock and ask), timezone (IANA, e.g. America/Chicago), where, and the language speakers will read (en, fr, de or es). Ask "Create this event?" On yes: `manage_sessions_event { action: "create", name, start_date?, end_date?, timezone?, location?, language? }`. `start_date` and `end_date` are ISO date-times with an offset (`2027-05-12T09:00:00-05:00`); a bare day is refused. A new event comes with a closed call, a few rooms and tracks, and an empty agenda. If the result says the language update failed, the event exists: retry only `manage_sessions_event { action: "update", event_id, language }`, never create it again.

### 2. Read the call as speakers see it
`get_sessions_event { event_id }`: the call is in `event.cfp`: `welcome_title`, `welcome_description`, `close_at`, `is_open` and `url` (the public link), plus tracks, formats, rooms and counts. Show the person the title, the welcome text and the closing date. In step 3 these are written as `title` (from `welcome_title`), `welcome_text` (from `welcome_description`) and `closes_at` (from `close_at`).

### 3. Change the wording or the closing date
**Pause:** show the new title, welcome text (plain text, blank lines between paragraphs) and closing date. On yes:
`manage_call_for_speakers { action: "update", event_id, title?, welcome_text?, closes_at? }`
- `closes_at` as a day (`2027-03-01`) closes at the end of that day on the event's clock; an ISO time with offset closes at that moment; `""` clears it.
- To extend a deadline, this is the same call with a later `closes_at`.

### 4. Set the questions
1. `get_call_questions { event_id }`: two groups in form order, `session` (About the session) and `speaker` (About the speaker). Each question has `field_id`, `label`, `kind`, `is_required`, `locked`, `answered`, and for choice questions `options` (each `{ id, label }`). `catalog` lists fields each group can still add, each with its `type` and `options`. `limits.custom_questions` is `{ max, used }`: how many questions of its own the plan allows and how many are in use (`max: null` = no limit).
2. Pick the change, show it, ask, then call `manage_call_questions` once per change. Before creating a question, look in `catalog` for a ready-made field that already asks it (for example "Level" for audience level) and offer that first: it uses none of the plan's own questions and matches the platform's reports.
   - Add a ready-made field: `{ action: "add", event_id, field_id, required? }` (field from `catalog`).
   - A new question: `{ action: "create", event_id, group, label, kind, choices?, required? }`. `kind` is short_text, long_text, single_choice, multiple_choice, yes_no, link or number; choices only for the two choice kinds.
   - Remove: `{ action: "remove", event_id, field_id }`. **Pause:** "N speakers already answered this; their answers stay stored. Remove it?"
   - Required or optional: `{ action: "set_required", event_id, field_id, required }`.
   - Reorder: `{ action: "reorder", event_id, group, field_ids }` with every question of that group exactly once.
3. Read `get_call_questions` again and show the result.

### 5. Tracks and formats speakers pick from
`set_rooms_and_tracks { event_id, tracks?, formats? }` replaces the whole list. Keep an item by passing its `id` with its name (a new name renames it); add one with a name only; anything left out is removed. Read the current lists from `get_sessions_event` first. **Pause:** show the full new list and what will be removed. If a session still uses one, nothing in that list changes and you are told which.

### 6. Open the call
**Pause:** show the final title, welcome text, closing date and the questions in order. Ask "Open the call for speakers? It becomes public." On yes:
`manage_call_for_speakers { action: "open", event_id, asked }` (pass the person's words in `asked`). It answers `needs_approval`: say "Waiting for your OK in Sessionboard: <url>" and stop. Once a person approves, `get_sessions_event` shows it open with the link to share.

### 7. Watch submissions come in
- `get_sessions_home {}` for the counts (submitted, undecided, accepted, declined).
- `list_submissions { event_id, view: "submissions", status? }` for what came through the call. `status: "pending"` keeps only the undecided ones. Lead with how many and what is new since the person last asked: titles, speakers, tracks.
- To record a proposal that arrived by email: **Pause:** show title, description and speakers (each with an email). On yes: `manage_program_session { action: "add", event_id, title, description?, speakers?, as_submission: true }`. Send each speaker as `first_name`, `last_name`, `email` and `job_title` only: Sessionboard refuses `company` here, so leave it out (add the company afterwards on the contact). It lands undecided with the rest.
- Deciding is the `review-and-decide-submissions` skill.

### 8. Close the call
**Pause:** "Close the call now? Submissions already in stay." On yes: `manage_call_for_speakers { action: "close", event_id }`.

## When something goes wrong

- 403 "… is not part of this Sessions plan" (`enterprise_only`): the plan does not include it (a second form, conditional questions, more questions of its own, another event this year). Nothing changed. A person with admin rights chooses a bigger plan in Sessions → Plan and billing. Do not work around it.
- `trial_ended` / `plan_ended`: the workspace is read-only. Everything can still be read; a person chooses a plan in Sessionboard.
- 403 "Forbidden … needs the read:sessions scope …": missing scope or not an organization admin. Reconnect the connector if scopes were added later. A 403 naming a limited connection: it needs an organization-wide one.
- 404: check the event id with `get_sessions_home`. 401 "Not signed in": reconnect the connector.
- 409 `in_use`: a session still uses that track or format. Move those sessions first, then try again.
- "That question is already on the call." / "field_ids must list every question in the … group exactly once": read `get_call_questions` again and fix the call.

## What this skill does not do

- Conditional questions, a second form, submission fees, file-upload questions of the event's own, or committee Review: the Sessionboard platform.
- No reminder emails to speakers, no speaker portal, and no notification when a submission arrives: you read the list when asked.
- No CSV export through the connector (export from the Sessions pages).
- Cannot change the call's images or branding.

## Tools used

- `get_sessions_home` — the plan, Sessions events, counts, whether each call is open (read)
- `find_event` — find a full-platform event by name (read)
- `list_events` — every event in the organization (read)
- `get_sessions_event` — the call's text, closing date, public link, tracks, formats (read)
- `manage_sessions_event` — create an event or change its details and speaker language (write)
- `manage_call_for_speakers` — change the call's text or closing date, close it, or open it (write; opening waits in Sessionboard)
- `get_call_questions` — the questions, catalog, answered counts and plan limit (read)
- `manage_call_questions` — add, create, remove, require or reorder questions (write, live at once)
- `set_rooms_and_tracks` — the full track and format lists speakers pick from (write)
- `list_submissions` — what came through the call, with decisions (read)
- `manage_program_session` — enter a submission for someone (write)
