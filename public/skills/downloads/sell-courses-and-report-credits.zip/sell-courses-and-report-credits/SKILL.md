---
name: sell-courses-and-report-credits
description: Price Sessionboard Learning courses, add coupons and course pages, and prepare CE Broker credit reports, each on your OK.
---

# Sell courses and report credits

The person gets their courses priced, discounted and described on their Learning Site, a clear view of sales, and their earned credit checked, exported or sent to CE Broker. Every change waits for their OK in Sessionboard. Sessionboard Learning is an LMS; selling and credit reporting are capabilities in it. It works the same for a self-serve Learning workspace and a full-platform organization with the Learning module. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to sell courses on their Learning Site and report earned credit to CE Broker - set a course's price and member price, make or stop coupons, write the course page description, require watching before a step counts, see sales and whether card payments are on, mark members and keep learners' license numbers, refund an order or end access, and check, export or send the CE Broker report. Triggers on "charge $49 for this course, free for members", "make a 20% off coupon", "stop the SPRING coupon", "write a description for the course page", "require watching 80%", "how are course sales?", "can learners pay by card yet?", "refund this order", "remove their access", "export my CE Broker report", "report credits to CE Broker", "set up CE Broker".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Reads need `read:learning`; changes need `write:learning`.
- Sessionboard checks the Learning module and the Lessons permissions (`ORG.LESSONS.READ` / `ORG.LESSONS.UPDATE`). Refunds and removing access also need the permission that manages plan and billing, or an organization admin.
- **CE Broker runs in practice mode** (`mode: "mock"`) until a real CE Broker provider account is connected. In practice mode nothing leaves Sessionboard and nothing is recorded as reported. Say so every time.

## Guardrails (read first)

- **Confirm before every write or send.** Before any price, coupon, description, watch requirement, learner profile, CE Broker setup, CE Broker send, refund or access change, show exactly what will change (course, amounts in dollars and cents, coupon code and dates, the learner, the order and amount) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads and dry runs need no confirmation.
- **Every write waits for a person in Sessionboard.** From an assistant each one answers `needs_approval` with a URL. Say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again.
- **Refunds only on an explicit request for that order.** Money goes back to a card. Name the learner, course, amount and whether access ends, and get a yes for that exact order.
- **Never ask for payment gateway keys or the CE Broker upload key.** A person enters them in Sessionboard.
- **Never call practice-mode results "reported".** `mode: "mock"` means rows were checked, nothing was sent.
- Amounts are in cents: 4900 = $49, 0 = free. Say dollars to the person.
- Words: Learning, course, learner, member, credit, coupon. Never "Lessons & Credits".

## The workflow

1. **Where things stand.** `read_learning_workspace { view: "courses" }` lists courses with their price. `read_course_selling { view: "payments" }` says whether card payments are on. If not, learners can get a course only with a 100% coupon or a $0 member price; a person connects a payment gateway in Sessionboard (Site › Selling › Get paid).
2. **Price a course.**
   **Pause:** "Set <course> to $<price>, members $<member price>, in <currency>?"
   `set_course_price { course_id, amount_cents, member_amount_cents?, currency? }` (USD default; CAD, EUR, GBP, AUD). Members are learners marked members or linked to the association management system. Coupons come off after the member price.
3. **Coupons.** `read_course_selling { view: "coupons", archived? }` shows each code, amount, courses, dates, uses and state.
   **Pause:** show the code, percent or amount off, which courses (empty = every course), start and end, and use limit.
   Create: `manage_coupon { action: "create", code, kind: "percent" | "amount", amount, currency?, course_ids?, starts_at?, ends_at?, max_uses? }`. Change: `{ action: "update", coupon_id, ... }`. Stop now: `{ action: "archive", coupon_id }`. Bring back: `{ action: "restore", coupon_id }`.
4. **The course page.** `read_course_page { course_id }` returns the description, or `summary_draft` (a starting point, not public) and what learners will learn.
   **Pause:** show the exact text (up to 1,000 characters).
   `set_course_description { course_id, summary }` (`""` removes it).
5. **Require watching** (off by default). A video step counts only after the learner played at least `percent` of it (10–100, skipping ahead does not count).
   **Pause:** "Require <n>% watched on every video in <course>?"
   `set_course_watch_requirement { course_id, percent }` (`null` turns it off).
6. **Sales.** `read_course_selling { view: "sales" }`: orders with learner, course, amount paid, list and member price, coupon, and totals per currency.
7. **Members and licenses.** Find the learner with `read_learners { action: "find", q }`.
   **Pause:** show the change.
   `update_learner_profile { learner_id, member?, license_number?, license_state?, license_profession? }` (two-letter state; profession code like RN).
8. **Refund or end access** (only when asked for a specific order). Find it in `read_course_selling { view: "sales" }` (status paid, amount above 0).
   **Pause:** "Refund <learner>'s <course> order of $<amount> in full to their card? They keep the course unless you want access removed."
   `refund_course_order { order_id, remove_access? }`. For an order that charged nothing, or after a refund made in the gateway: `remove_course_access { order_id }` (progress and credit stay on record).
9. **CE Broker report.** `read_ce_broker_report`: setup, `mode`, credited courses with CE Broker course numbers, and every credit's status (ready, missing, missing_license, failed, reported). Say what is missing in words.
   - **Set up** (after a yes): `set_up_ce_broker { provider_number?, default_profession?, course_numbers? }` (`course_numbers` maps a course id to its CE Broker number; `null` removes one).
   - **Export** (every plan): `export_ce_broker_report { format? }`. `xml` (default) is CE Broker's upload format with the ready rows; `csv` lists every row with its status. Hand over the file and say the person uploads the XML in CE Broker's provider portal, or downloads the same file under Credits › CE Broker reporting.
   - **Send** (Enterprise only): first `report_to_ce_broker { dry_run: true }` and say how many would go.
     **Pause:** "Send <n> learners' names and license numbers to CE Broker?" (In practice mode: "This is practice; nothing will leave Sessionboard.")
     On yes: `report_to_ce_broker { dry_run: false }`. It answers `needs_approval`: give the URL and stop. After a person approves, report `sent`, `accepted` and each `rejected` row with its message.

## When something goes wrong

- **403 "Forbidden … needs the read:learning / write:learning scopes … and a user with the Lessons permission"**: the person reconnects or asks an admin.
- **403 on a refund or removing access**: the person lacks the plan-and-billing permission. Say so; an organization admin can do it.
- **403 `enterprise_only` from `report_to_ce_broker`**: sending is Sessionboard Enterprise. Use `export_ce_broker_report` and hand over the file. Nothing changed.
- **400 from `refund_course_order`**: the order charged nothing (use `remove_course_access`) or is already refunded.
- **400 from `export_ce_broker_report`**: nothing is ready or there is no provider number. Say which.
- **"code, kind and amount are required" / "coupon_id is required"**: supply them; nothing changed.
- **404**: check ids with `read_learning_workspace { view: "courses" }` or `read_course_selling`.

## What this skill does not do

- Connect a payment gateway or enter any key. A person does that in Sessionboard.
- Make a partial refund. Refunds are in full.
- Set or grant credit, or edit a course's credit amount.
- Report to CE Broker for real while the organization has no real CE Broker provider account (practice mode only).
- Report to boards other than CE Broker (for example PARS or CPE Monitor).
- Upload a cover image for the course page.

## Tools used

- `read_learning_workspace` — courses with their prices (read)
- `read_course_selling` — coupons, sales and payment status (read)
- `set_course_price` — a course's price and member price; waits for a person's OK (write)
- `manage_coupon` — create, update, stop or restore a coupon; waits for a person's OK (write)
- `read_course_page` — a course's public page and draft description (read)
- `set_course_description` — the description on the course page; waits for a person's OK (write)
- `set_course_watch_requirement` — require watching before a step counts; waits for a person's OK (write)
- `read_learners` — find a learner (read)
- `update_learner_profile` — member status and license details; waits for a person's OK (write)
- `refund_course_order` — refund a paid order in full; waits for a person's OK (write)
- `remove_course_access` — end a buyer's access; waits for a person's OK (write)
- `read_ce_broker_report` — setup, mode and every credit's reporting status (read)
- `set_up_ce_broker` — provider number, default profession, course numbers; waits for a person's OK (write)
- `export_ce_broker_report` — the roster file as XML or CSV (read)
- `report_to_ce_broker` — dry run, then send ready credit; Enterprise only, waits for a person's OK (sends)
