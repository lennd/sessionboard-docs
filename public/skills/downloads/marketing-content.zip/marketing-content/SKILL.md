---
name: marketing-content
description: Turn event and webinar recordings into clips, reels, quote cards, post packs and recaps in Sessionboard, and run live captions.
---

# Sessionboard Marketing › Content

Recordings in, everything out. Every step is a Sessionboard MCP tool; the
Content page in the Marketing workspace shows the same library, so anything
you make here is there too.

## When to use

- "Turn last week's webinar into a reel and three posts."
- "Make everything from the keynote." / "Clip the best moments."
- "Make quote cards from what Dr. Ruiz said."
- "Write a recap of the panel." / "A recap deck for the board."
- "What's still waiting on a speaker?" / "Show me this month's clips."
- "Send the presenters their clips to approve."
- "Live captions in Spanish and French for the main room tomorrow."

## The flow

1. **Find the recording.** `list_recordings { q: "<words from the title>" }`.
   Nothing there? `list_recordings { available: true }` shows what connected
   Zoom / ON24 accounts hold that is not imported yet.
2. **Bring it in if needed.** `import_recording`:
   - `source: "link"` + `url` (YouTube / Vimeo) + `certified: true` — ask the
     person to confirm they own or may use the recording first.
   - `source: "zoom" | "on24"` + `external_id` (or `meeting_uuid`) from step 1.
   - `source: "upload"` + `media_id` of a file already uploaded to Media.
   - `source: "goldcast"` + `media_id` (Goldcast recordings sync on their own).
   - Pass `glossary` with drug names, acronyms, product and speaker names, and
     `medical: true` for clinical content (with `event_id`). Spelling in every
     clip, caption and post depends on it.
   Transcription is **audio only** and starts on its own. You do not need to
   wait: `make_content` waits for the transcript.
3. **Make it.** `make_content { media_id, kind }`:
   - `everything` → a captioned vertical reel, 3–4 clips, quote cards, a post
     pack (LinkedIn ×3, X ×3, Instagram ×2, an email blurb) and a recap.
   - one thing → `reel`, `clip`, `quote_card`, `post_pack`, `recap`,
     `recap_deck`, `key_takeaways`, `newsletter` (a draft with subject and
     sections), `audio_recap`.
   - a reel about one thing: `kind: "reel", topic: "remote monitoring"`; a
     reel of one speaker: `speaker_contact_id` (they must be tagged on the
     recording).
   - from a whole event, no recording: `event_recap` (the post-show recap,
     `event_id`) and `sponsor_recap` (`event_id` + `sponsor_id`: the sessions
     that sponsor presented). Both are written from the session recaps, so
     make recaps of the recordings first.
   Recaps, decks and quote cards credit the session's sponsor ("Presented by")
   when it has one.
   It returns at once with `run_id` and queued items.
4. **Wait for it.** `list_content { run_id }` until nothing is `queued` or
   `making` (text takes about a minute, video a few), or
   `get_content { item_id, wait_seconds: 50 }` for one item. A short recording
   can yield fewer clips or quote cards than planned; that is expected.
5. **Show it.** `get_content` for the copy and assets: post text in
   `body.linkedin / x / instagram / email`, the recap in `body.recap`, a quote
   card's `body.svg` (render it as an image), the reel's `body.segments`, the
   video download in `output.url`. Quote it back; let the person edit.
6. **Presenter approval (optional).** `send_content_kits { media_id }` without
   `confirm` is a dry run: show who gets which items, who is skipped (no email)
   and which items no presenter speaks in. Only after the person says yes, call
   it again with `confirm: true`. Items become `waiting_on_speaker`; delivery
   hands off to Campaigns. `review_content` records the organizer's own call.
7. **Library questions.** `list_content` searches and filters the library:
   `q` (words in titles, copy, quotes, the transcript, speakers, sessions,
   event names, tags), `kind` (one or a list), `status` (`approved`,
   `waiting_on_speaker`, `changes_requested`, `ready`, `failed`, or the views
   `needs_approval` / `ready_to_post`), `speaker`, `aspect` (`9:16` for
   vertical), `used` (`unused` = not in a campaign, downloaded, shared or
   posted yet), `event_id`, `media_id`, `from` / `to`, and `sort`
   (`most_used`, `duration`, `az`, …). "9:16 clips from the Chicago lab that
   haven't been posted" is `{ q: "Chicago lab", kind: ["clip"], aspect: "9:16",
   used: "unused" }`. `counts` and `facets` give totals for a one-line
   summary. An item with `stub: true` is a planned cut whose video was not
   rendered: never call it a finished video.

### Live captions in a room

1. `start_live_captions { event_id, session_id, languages: ["es", "French"],
   glossary, medical }`. Omit `session_id` when the event has one session.
2. Show `qr_svg` (attendees scan it) and `viewer_url`.
3. `capture.mode: "room_console"` starts on its own; `"device"` means open
   `capture.url` on a phone or laptop in the room and allow the microphone.
4. If the response has `needs_ok` (the attendee page is not published), ask
   the person, then call again with `publish_caption_page: true`.
5. Audience questions and live polls in that room:
   `get_room_engagement { caption_id }`, `manage_room_questions` (open / close
   Q&A, approve / answer / hide a question) and `manage_poll` (create a draft,
   then open — ask before opening — close, delete). Attendees ask and vote in
   the event app.
6. `stop_live_captions { caption_id }` when the session ends;
   `list_live_captions` shows what is live.

Captions and their translations spell the session's terms and speaker names
right on their own (the session glossary: the event's list, the abstract,
the people on the session); add to it with `glossary`.

## Examples

**"Turn last week's webinar into a reel and three posts."**

1. `list_recordings { q: "webinar", limit: 5 }` → pick the one from last week;
   confirm the title with the person if two match.
2. `make_content { media_id, kind: "reel" }` and
   `make_content { media_id, kind: "post_pack" }`.
3. `list_content { media_id }` until both are ready.
4. Reply with the reel's moments (`get_content` → `body.segments`, plus
   `output.url` once rendered) and three posts from `body.linkedin`.

**"Make everything from the keynote and get the speakers to approve their clips."**

`make_content { kind: "everything" }` → wait → summarise what was made →
`send_content_kits { media_id }` (dry run) → "Ana gets the reel and 2 clips,
Ben gets 1 clip and a quote card — send?" → on yes,
`send_content_kits { media_id, confirm: true }`.

**"Write the post-show recap and one for our sponsor Acme."**

Check there are recaps (`list_content { kind: "recap" }`; make them first if
not) → `make_content { kind: "event_recap", event_id }` and
`make_content { kind: "sponsor_recap", event_id, sponsor_id }` → show the
headline, highlights and quotes.

**"Captions in Spanish for the main room, it's a cardiology session."**

`start_live_captions { event_id, session_id, languages: ["es"], medical: true,
glossary: ["sacubitril", "SGLT2", "HFrEF"] }` → show the QR → if `needs_ok`,
ask before publishing the caption page.

## Guardrails

- **Ask before anything leaves Sessionboard or goes public.** Sending kits
  (`confirm: true`) and publishing the caption page (`publish_caption_page:
  true`) need a clear yes in this conversation, every time. Nothing in this
  skill posts to social networks; the person copies or schedules posts.
- **Credits.** Making content spends AI credits; transcription and live
  captions spend transcript minutes; each caption language spends AI credits
  (translation). An `audio_recap` and `voice_languages` (captions read aloud)
  are voiced with AI and spend noticeably more: say so, and pass
  `accept_credits: true` only after the person agrees. Live voice ("Listen")
  is read only to attendees who turn it on, and credits are spent only when a
  line is read aloud. Where it is not switched on for the account the
  response says `voice.status: "not_available"`; tell the person rather than
  implying it works.
- **Audio only.** Transcription and live captions capture audio. Never say
  Sessionboard streams or broadcasts video.
- **Grounded.** Quotes and posts come from what was said. Do not add facts,
  numbers or quotes of your own to them; if the person wants a claim that is
  not in the recording, write it as their words, not the speaker's.
- **Rights.** Import a link only after the person confirms they own or may
  use the recording (`certified: true`).
- **Accuracy.** For medical, scientific or technical sessions always pass a
  `glossary` (and `medical: true` for clinical) — on import and on captions.
- **Failures are information.** An item with `status: "failed"` carries an
  `error` sentence; relay it and offer to try again or make something else.

## Tools used

- `get_content` — Get content (read)
- `get_room_engagement` — Room questions and polls (read)
- `import_recording` — Import a recording (write)
- `list_content` — List content (read)
- `list_live_captions` — List live captions (read)
- `list_recordings` — List recordings (read)
- `make_content` — Make content from a recording (write)
- `manage_poll` — Manage a live poll (write)
- `manage_room_questions` — Manage room questions (write)
- `review_content` — Review content (write)
- `send_content_kits` — Send presenters their kits (write)
- `start_live_captions` — Start live captions (write)
- `stop_live_captions` — Stop live captions (write)
