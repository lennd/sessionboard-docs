---
name: run-the-awards-review
description: Run a Sessionboard Awards review: invite and assign Reviewers, send reminders, read standings and announce Winners on your OK.
---

# Run the Awards review

The person gets their Reviewers invited and assigned, scoring chased until it is done, a clear view of how Submissions score, and the Winners and Finalists announced once they have picked them in Sessionboard. It works the same for a self-serve Awards workspace and a full-platform organization. Self-serve Awards has one review Round per program; more Rounds are Enterprise Awards. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to run the review of an Awards program - invite Reviewers, give every Submission its Reviewers, remind Reviewers who have scorecards to finish, see how scoring is going and how Submissions stand, and announce the Winners and Finalists once a person has picked them. Triggers on "invite these people as Reviewers", "assign the nominations to Reviewers", "three Reviewers per Submission", "who hasn't finished scoring?", "remind the Reviewers", "how is the review going?", "show me the top-scored nominations", "compare the finalists", "hide nominee names from Reviewers", "announce the winners", "send the winner emails".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person, with an organization-wide connection (a key restricted to events is refused).
- Reads need `read:awards`; invites, assignments, reminders and announcements need `write:awards`.
- Sessionboard checks `ORG.AWARDS.READ` to read and `ORG.AWARDS.UPDATE` plus being a manager of the program to change it. Lists and totals only show programs the person manages or can see.

## Guardrails (read first)

- **Confirm before every write or send.** Before `invite_awards_reviewers`, `assign_awards_reviews`, `update_awards_program`, `remind_awards` with `preview: false` or `announce_awards_winners`, show exactly what will happen (names and emails, how many Reviewers per Submission, who gets which email) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Some actions wait for a person in Sessionboard.** Inviting Reviewers, sending reminders and announcing answer `needs_approval` with a URL. Say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again for the same program.
- **Choosing Winners is a person's job in Sessionboard** (Awards → the program → Winners). There is no tool for it and Sessionboard refuses an assistant. You may help compare Submissions with their scores; never say who won, and never mark anyone.
- Pass the person's request in their own words as `asked` on the invite, reminder and announcement.
- Words: Reviewer, Round, Scorecard, Submission (nomination), Nominee, Winner, Finalist. Never "judge", "jury", "entry" or "evaluation".

## The workflow

1. **Find the program.** `list_awards_programs { offset? }` for status (draft, open, reviewing, closed), Round dates and counts. Then `get_awards_program { program_id, submissions_offset? }`: the program under `program` (status, `counts.submitted`), and beside it at the top level the Submissions with average scores (50 at a time), `review.reviewers` (each with `assigned`, `done` and `not_started`), the Scorecard and the Winner types.
2. **Invite Reviewers.** Collect each Reviewer's email and ask for their first and last name too, since the invitation greets them by name; if the person does not have names, invite by email alone (up to 50 per call). Each gets an account and an invitation email to the review portal.
   **Pause:** list every name and email. Ask "Send these invitations?"
   On yes: `invite_awards_reviewers { program_id, reviewers, asked? }`. It answers `needs_approval`: give the URL and stop. The invitations go once a person approves.
3. **Blind review (optional).** If the person wants Reviewers not to see nominator or Nominee names:
   **Pause:** "Turn on blind review for <program>?"
   `update_awards_program { program_id, blind_review: true }`.
4. **Assign reviews.** It spreads submitted Submissions across the Reviewers, least busy first. Default 3 Reviewers per Submission. It keeps every assignment already made and only fills gaps, and it emails no one: Reviewers see their list in the review portal.
   - Read `get_awards_program` first. When `review.reviewers` is empty (invitations still waiting for an OK in Sessionboard, or none sent) or `counts.submitted` is 0 (a draft, or nominations still open with nothing submitted), there is nothing to assign yet: say which, and offer to assign once Reviewers are on the program and Submissions are in, usually when nominations close and the review Round starts. Calling again later only fills gaps.
   - Each Submission can get at most as many Reviewers as the program has. With fewer Reviewers than `per_submission` (2 Reviewers and the default 3), say so and propose `per_submission` equal to the Reviewer count, or inviting more Reviewers first.
   **Pause:** say how many Submissions and Reviewers there are and how many Reviewers each Submission gets. Ask for a yes.
   `assign_awards_reviews { program_id, per_submission? }`.
5. **Chase unfinished scorecards** (while the review Round is open). `remind_awards { program_id, audience: "reviewers", preview: true }` lists who would get it and who is skipped (nobody gets the same reminder twice in 24 hours). Nothing is sent.
   **Pause:** show the count, the names and who is skipped. Ask "Send this reminder?"
   On yes: `remind_awards { program_id, audience: "reviewers", preview: false, asked? }`. It answers `needs_approval`: give the URL and stop.
6. **Read how it is going.** `get_awards_results` for every program: Submissions submitted and still in draft, Reviewers, Scorecards filled in, Winners and the completion rate. `get_awards_program` for one program's Reviewer progress and Submissions by average score. Present scores as information for the person's decision, not a recommendation of Winners.
7. **Hand the choice to the person.** When scoring is done, say: "Pick the Winners and Finalists in Sessionboard: Awards → <program> → Winners." Do not continue until they say they have.
8. **Announce.** Check `get_awards_program` shows Winners. Whoever submitted each Winner's and Finalist's nomination (the Nominee, when people nominate themselves) gets the news by email; everyone else who submitted gets a thank-you unless `notify_others` is false. It is sent once per program.
   **Pause:** say which program, how many Winners and Finalists, whether the thank-you goes out, and any `note` line. Ask "Announce now?"
   On yes: `announce_awards_winners { program_id, note?, notify_others?, asked? }`. It answers `needs_approval`: give the URL and stop.

## When something goes wrong

- **403 "Forbidden … needs the read:awards scope … and a user who can manage Awards"**: missing scope, or the person is not a manager of this program. They reconnect, or ask an admin.
- **403 with `plan_ended` / `trial_ended`** in the message: the self-serve plan is read-only. A person chooses a plan in Sessionboard (Awards → Plan and billing).
- **`choose_plan`** on announce: the organization is past the trial's 50 nominations (counted across all its programs). A person chooses a plan in Sessionboard; nothing was sent; nominations still come in.
- **`enterprise_only`** (`review_rounds`): a second review Round is Enterprise Awards. An admin upgrades in Sessionboard (Awards → Enterprise). Nothing changed.
- **"A person does this in Sessionboard, not an assistant."** (`HUMAN_ONLY`): say so and point to the page.
- **Announce errors mentioning `no_winners` or `reviews_incomplete`**: no Winners are picked yet, or scorecards are unfinished. Say which, and offer step 5 or step 7.
- **Reminder errors mentioning `review_not_open` / `review_closed` / `no_site`**: the review Round is not open now, or the program is not on an Awards Site. Say so.
- **404**: check the id with `list_awards_programs`.
- **429 "Too many requests"**: Sessionboard is rate-limiting this connection. Nothing changed. Wait a minute and retry once; if it happens again, tell the person and try later.

## What this skill does not do

- Pick, change or remove Winners or Finalists. A person does that in Sessionboard.
- Preview exactly who gets the announcement email before asking. Say who receives it in general terms instead.
- Remove a Reviewer, move an assignment from one Reviewer to another, or set Reviewer tags.
- Show one Reviewer's individual scorecard answers.
- Run more than one review Round, public voting or a Call for Reviewers.
- Report the delivery progress of a reminder or announcement after it is sent.

## Tools used

- `list_awards_programs` — programs, status, Round dates, counts (read)
- `get_awards_program` — Submissions with average scores, Reviewer progress (`review.reviewers`), Winners (read)
- `get_awards_results` — totals and completion per program (read)
- `invite_awards_reviewers` — invite Reviewers by email; waits for a person's OK (sends)
- `update_awards_program` — turn blind review on or off (write)
- `assign_awards_reviews` — give each Submission its Reviewers; emails no one (write)
- `remind_awards` — preview, then remind Reviewers with scorecards to finish; the send waits for a person's OK (read / sends)
- `announce_awards_winners` — email the Winners and Finalists and thank the rest; waits for a person's OK (sends)
