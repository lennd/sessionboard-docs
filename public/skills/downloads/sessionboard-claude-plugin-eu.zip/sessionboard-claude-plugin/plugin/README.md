# Sessionboard for Claude Code (Europe)

Connects Claude Code to Sessionboard (https://mcp-eu.sessionboard.com/mcp) and adds 27 workflow skills for event teams. You sign in to Sessionboard the first time a tool runs; every action runs as you, with your Sessionboard role, and each skill asks before it creates, changes, publishes or sends anything. Actions that reach people outside your team also wait for a person's approval in Sessionboard.

Use this plugin if you sign in to Sessionboard at appv2-eu.sessionboard.com.

## Skills

- **Answers about any attendee, order or payment** (`answer-registration-questions`): Ask who is registered, what they bought and paid, who owes money, who is waiting and how many seats are left, and get a straight answer from your event's registrations.
- **Build a dashboard or saved report** (`build-a-dashboard`): Describe the questions you care about and get an event or organization dashboard of tested charts, numbers and tables, created only after you approve the plan.
- **Build your agenda and put it on your website** (`build-the-agenda`): Rooms and tracks set, accepted sessions placed without clashes, sponsors tagged, and the agenda and speaker wall published to your website on your OK.
- **Check your members against your AMS** (`check-members-against-your-ams`): How your members engage across events, webinars, learning and awards, whether your AMS fields are mapped right, and engagement written back to your AMS on your OK.
- **A sourced briefing on how an event is doing** (`event-performance-briefing`): A structured brief on one event or session, from the program, registrations, your saved reports and dashboards, sharing and what speakers said, with every number labelled with where it came from.
- **See what's missing for every speaker and fix it** (`get-speakers-ready`): Your speaker list with what is still missing per speaker and per session, and the fixes you confirm made in Sessionboard.
- **Import your program, speakers and sponsors** (`import-an-event-program`): Your sessions, speakers and sponsors brought in from a list you already have, with a row-by-row preview first and no duplicates.
- **Keep learners on track and due dates met** (`keep-learners-on-track`): A plain read of how learning is going, who needs a nudge and why, and the next course for each person, with assignments and reminders sent on your OK.
- **Launch an Awards program and open nominations** (`launch-an-awards-program`): An Awards program drafted from one sentence, with Categories, deadline and Scorecard, opened on your Awards Site once you approve.
- **Get speakers and your team sharing your event** (`marketing-campaigns`): A campaign that gets speakers, guests or your team sharing an event, collects short videos or follows up afterwards, with results per person.
- **Turn recordings into clips, posts and recaps** (`marketing-content`): From a recording: a captioned reel, clips, quote cards, a post pack, a recap or recap deck, and presenter kits for approval.
- **Bring events and apps into Marketing** (`marketing-events-and-apps`): Import an event from its link, set up a webinar series, and connect, sync or disconnect the apps your events run on.
- **Hit your registration number by a date** (`marketing-goals`): A plan to reach a number by a date across sharing, email and ads, with pacing, a turnout estimate and ads on your own account with a spend cap.
- **Publish an event page in your brand** (`marketing-pages`): An event or webinar page in your Brand Kit, an on-demand library of recordings, website embeds and your own domain.
- **See who promoted, registered and watched** (`marketing-people`): Everyone your events and campaigns name, with what each did: shared, clicked, brought registrations, registered, watched.
- **Report what an event's marketing achieved** (`marketing-results`): Registrations, attendance, posts and what each drove, explained in plain words, with a shareable read-only report.
- **Push your agenda to your event app** (`push-the-agenda-to-your-event-app`): Your accepted sessions, speakers, tracks and rooms sent one way into your event app, previewed first, with a history of every push.
- **Find out if registrations are on pace** (`registration-pacing-check`): A short pacing brief for your event: registrations so far, an estimate of where they will land, the goal, funnel leaks, capacity, the waitlist and three next moves, with nothing sent.
- **Decide on submissions and tell your speakers** (`review-and-decide-submissions`): Every submission with your team's picks, your accept, waitlist and decline decisions recorded, and the decision emails previewed before they go.
- **Open your call for speakers and watch it fill** (`run-a-call-for-speakers`): A call for speakers with your wording, questions, tracks and deadline, opened on your OK, with a running view of what has come in.
- **Run the Awards review and announce the Winners** (`run-the-awards-review`): Reviewers invited and assigned, scoring chased to the finish, and your Winners and Finalists announced once you have picked them.
- **Sell courses and report credit to CE Broker** (`sell-courses-and-report-credits`): Courses priced, discounted and described on your Learning Site, sales at a glance, and earned credit checked, exported or sent to CE Broker.
- **Send a sponsor their results** (`send-a-sponsor-their-results`): A sponsor's counts-only report and a safe link to hand it over, plus, when you choose, a private link to the people who opted in to hear from sponsors.
- **Build and publish a Site by chat** (`sites`): Pages, blocks, menu, theme and Brand Kit on a Learning, Marketing or Awards Site, previewed by role and device, published on your OK.
- **Keep your people and companies tidy** (`tidy-your-people-and-companies`): Clean names and titles, the right tags, people linked to their companies, new lists brought in without duplicates, and an export when you need one.
- **Turn your sessions and recordings into courses** (`turn-sessions-into-courses`): Draft courses made from your meeting's sessions, webinars or videos, reviewed with you and published to learners once you approve.
- **Work your pipeline and send contracts** (`work-the-pipeline-and-contracts`): Warm people found, the right Contacts in the right stage for each event, and agreements sent for e-signature and tracked to the signed PDF.

Every skill, its steps, permissions and example prompts: https://learn.sessionboard.com/skills

Privacy policy: https://www.sessionboard.com/legal/privacy-policy
