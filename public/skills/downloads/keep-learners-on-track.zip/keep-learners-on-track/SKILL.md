---
name: keep-learners-on-track
description: See who is behind or due to recertify in Sessionboard Learning, why, and nudge or assign courses after you confirm.
---

# Keep learners on track

The person gets a plain read of how learning is going, the people who need a nudge and why, the next course for each person with a reason, and, on their OK, a course assigned or a Keep learning email sent. Sessionboard Learning is an LMS; certifications and credits are capabilities in it. It works the same for a self-serve Learning workspace and a full-platform organization with the Learning module. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to see how learning is going and keep people moving - completions, certifications and credit, who is due for recertification, who has stalled or owes credit, what to recommend to people who came to an event, why one learner is engaged or not, and assigning a course or nudging people with a Keep learning email on their OK. Triggers on "how is learning going?", "who's due for recertification this month?", "who should we nudge?", "who stalled?", "who still owes credit?", "recommend courses for people who came to the Chicago lab", "why is Dana so engaged?", "look up a learner", "assign the onboarding course to the team", "send them their next course".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Learning reads need `read:learning`; `assign_course` needs `write:learning`. Keep learning emails use `manage_campaign`, which needs `read:marketing` / `write:marketing`. Finding an event needs `read:events`.
- Sessionboard checks the Learning module and the Lessons permissions (`ORG.LESSONS.READ` to read, `ORG.LESSONS.UPDATE` / `CREATE` to assign). Writing a campaign needs an organization admin.

## Guardrails (read first)

- **Confirm before every write or send.** Before `assign_course` or any `manage_campaign` draft, update or launch, show exactly what will happen (the course or certification, who is assigned and the due date, who gets the email and what it says) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Some actions wait for a person in Sessionboard.** A campaign launch from an assistant answers `needs_approval` with a URL. Say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again.
- **Every tool that finds people only reads.** Nothing here sends on its own. Nudging is a Keep learning campaign, on the person's OK.
- **Results are aggregates.** `get_learning_results` and `learning_engagement_results` never list learners. Name a learner only from `read_learners`, `learners_to_nudge`, `due_for_recertification` or `recommend_courses`.
- **One engagement score.** `explain_learner_engagement` returns Learning's view (`score`, band, `why`) and `overall` (the same score across Platform, Marketing and Learning). Quote Learning's `score` and `why` when the question is about learning; quote `overall` only when the person asks about engagement across everything, and say it is the same score seen across all products, never a second score. The two numbers can differ (for example 38 in Learning, 52 overall). When `credit_owed` is null, the organization set no credit goal and nobody owes anything.
- **You never set or grant credit.** The transcript PDF is downloaded by a person in Sessionboard (Learners → the learner); do not send it anywhere.
- The association management system shows as coming in `learning_signal_sources`. Never offer to connect it.
- Words: Learning, course, certification, credit, learner, campaign. Never "Lessons & Credits", "evaluation", or the names of internal engines.

## The workflow

1. **How is it going?** `get_learning_results` answers in the organization's own terms: companies see completions and certifications held and expiring; associations see credit issued, claims and transcripts. Its `claude_prompt` is a ready-made prompt for building a dashboard: do not show or echo it. Add `learning_engagement_results` for engagement bands now against 30 days ago, what moved people, and 30-day outcomes. Lead with one sentence, then the numbers.
2. **Who needs a nudge?** `learners_to_nudge { limit? }` (default 8), most urgent first. Each reason: `renewal` (a certification within 90 days or lapsed), `stalled` (a course untouched 14+ days), `credit_owed`, or `earn_credit` (attended a session and has not taken its course), with the next lesson. Say the reason in words. `next_lesson` is the person's best next step, which may be a different course from the one they stalled in: name the stalled course from the reason and the next lesson separately, never as one.
3. **Who is due for recertification?** `due_for_recertification { within_days? }` (default 30), soonest first, with `days_left`, whether it has expired, and the course that counts toward renewal. Say the summary, then the names.
4. **One learner.** `read_learners { action: "find", q }` (a name or email, at least 2 characters), then `read_learners { action: "get", person_id }` for courses with percent, certifications with expiry, assignments (assigned, overdue, completed) and the credit ledger. For why they are or are not engaged: `explain_learner_engagement { person_id }`; quote its `why` line.
5. **What should people take next?** For an event's people: find it with `list_events`, then `recommend_courses { event_id, limit? }`. For named people: `recommend_courses { emails }`. Each person gets their next courses with a because; `courses` ranks courses by how many people they fit.
6. **Assign a course** (teammates). Find the target: `read_learning_library` for courses and lessons, `list_certifications` for certifications.
   **Pause:** name the course or certification, who (the whole team, or the named teammates), the due date, whether it is required, and that each assignee gets a Slack DM or email. Ask for a yes.
   `assign_course { target_kind: "certification" | "series" | "lesson", target_id, assign: { all_team? | user_ids?, due_in_days?, required? }, slack_channel_id? }`. `series` is a course. If it answers `needs_approval`, give the URL and stop.
7. **Nudge with a Keep learning email.** Draft it: `manage_campaign { action: "draft", kind: "keep_learning", prompt, event_id? }` (event defaults to the latest meeting with published courses). It sends nothing.
   The draft's Who is the meeting's people ("Everyone at the meeting"), not the `learners_to_nudge` list. Say the difference out loud: who on the nudge list is not in the draft (for example people who owe credit but were not at that meeting) and who in the draft is not on the nudge list. To keep it to the nudge list, ask, and on the person's OK narrow it: `manage_campaign { action: "update", campaign_id, who: { only: [<emails from learners_to_nudge>] } }`, then read the Who count again. Anyone still missing is outside this campaign's audience: name them, and offer `assign_course` for teammates.
   **Pause:** show the draft's Who (count and sample names), What, the link and its label, When and `approval.summary`. If the link does not fit a Keep learning email (for example "Save your seat" pointing at a past event's page), propose a course link and label and change it with `manage_campaign { action: "update", campaign_id, link: { url, label } }` on the person's OK. Ask "Send this?"
   Edits: `manage_campaign { action: "update", campaign_id, ... }` (the version goes up; show it again).
   On yes: `manage_campaign { action: "launch", campaign_id, draft_version, approved: true }` with the version the person saw. It answers `needs_approval`: give the URL and stop. Later rounds (credit owed, renewals, new on their topics) each wait for the person's OK too.
8. **Where the signals come from.** `learning_signal_sources` shows which sources feed Learning, what each turns on, and what to connect next. Connecting happens on the Apps page in Sessionboard.

## When something goes wrong

- **403 "Forbidden … needs the read:learning / write:learning scopes … the organization's Learning feature, and a user with the Lessons permission"**: say which is likely missing; the person reconnects or asks an admin.
- **403 from `manage_campaign`**: the connection lacks the Marketing scopes, or the person is not an organization admin.
- **409 on launch**: the draft changed. `manage_campaign { action: "get", campaign_id }`, show the new version, ask again.
- **"Pass q …" / "Pass person_id …"**: call `read_learners` with the missing value.
- **404**: check ids with `read_learning_library`, `list_certifications` or `read_learners`.

## What this skill does not do

- Assign a course to people who are not teammates (Learning Site members, event attendees). Use a Keep learning campaign to reach them.
- Look up a teammate's user id by name. If you cannot match the person to a user id, ask them to assign it in Sessionboard.
- Set or grant credit, sign an attestation or send a transcript.
- Give a learner extra time on timed quizzes. A person does that in Sessionboard.
- Connect a data source or the association management system.

## Tools used

- `get_learning_results` — completions, certifications or credit, in the organization's terms (read)
- `learning_engagement_results` — engagement bands now and 30 days ago, outcomes (read)
- `learners_to_nudge` — who to nudge and why, with the next lesson (read)
- `due_for_recertification` — certifications expiring or lapsed, with the renewal course (read)
- `read_learners` — find a learner; one learner's courses, certifications, assignments and credit (read)
- `explain_learner_engagement` — why one person is engaged, across products (read)
- `list_events` — find the event for recommendations (read)
- `recommend_courses` — next courses for an event's people or named emails (read)
- `read_learning_library` — published courses and lessons to assign (read)
- `list_certifications` — the organization's certifications (read)
- `assign_course` — assign a published course, lesson or certification; messages each assignee (sends)
- `manage_campaign` — draft, update and launch a Keep learning email; launch waits for a person's OK (write / sends)
- `learning_signal_sources` — which sources feed Learning (read)
