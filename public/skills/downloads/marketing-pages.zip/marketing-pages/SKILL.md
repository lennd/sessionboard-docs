---
name: marketing-pages
description: Make and publish Sessionboard event and webinar pages in your brand, an on-demand library, website embeds and a custom domain.
---

# Sessionboard Marketing — Pages

You are building the pages a marketing team uses to fill events and keep their content working: one page per event or webinar, one on-demand library across them, and snippets for the team's own website. Everything is made as a **draft**; it goes public only when the person says OK.

## When to use

Make, change and publish Sessionboard event and webinar pages (registration, speaker list, agenda) in the organization's brand; make an on-demand library of recordings and answer questions from it; get website embed snippets. Use when someone asks for an event page, a registration or landing page, a webinar page, a speaker wall or agenda for their website, an on-demand / recordings library, or "what did the speakers say about X" over their recordings. Needs the Sessionboard MCP connector.

## Tools

| Job | Tool |
|---|---|
| What exists: every event's page (live / draft / none), every library | `list_marketing_pages` |
| Find the event | `find_event`, `list_events` |
| Make or refresh the page draft from the Brand kit | `make_event_page` |
| Change the draft in plain words | `edit_event_page` (needs the `revision` you last read) |
| Exact block edits (rare) | `get_event_page`, `update_event_page_draft` |
| Publish the page | `publish_event_page` — **only after an explicit OK** |
| Make the on-demand library | `make_gallery` |
| Ask the library | `ask_gallery` |
| Publish the library | `publish_gallery` — **only after an explicit OK** |
| Snippets for their website | `get_embed_code` |
| Their own domain for a page or library | `connect_custom_domain`, `get_custom_domain_instructions`, `check_custom_domain` |
| See or fix the brand | `get_brand_kit`, `update_brand_kit` |

## Flow: an event or webinar page

1. **Find the event.** "Our March webinar" → `find_event` / `list_marketing_pages`; if two match, ask which. If the event does not exist yet, say so (making events is a different job: `create_webinar` / `create_gathering`).
2. **Check the brand once.** If `make_event_page` returns `brand_kit: null`, or the person says the colours are wrong, offer to fill the Brand kit first (`get_brand_kit` → `update_brand_kit`); a page in the wrong colours is the first thing they will notice.
3. **Make the draft.** `make_event_page { event_id, brief }`. Put what they told you about the topic and audience in `brief`, in their words. Speakers, agenda, date, place and price come from the event itself — never write them into the brief or the page.
4. **Show it.** Give them the `preview_url` and a three-line summary: headline, which blocks are on the page, anything missing (no speakers yet, no sessions on the agenda). Say it is a draft.
5. **Edit in plain words.** For each change they ask for, `edit_event_page { event_id, instruction, revision }` with the latest `page.revision`. Report the one-line `summary`. On a 409, someone else edited the page: read it again (`get_event_page` → `site.revision`), show them, and retry.
6. **Publish only on an explicit OK.** "Looks good, publish it", "yes, go live" — then `publish_event_page { event_id, revision, confirmed: true }` with the revision of the preview they approved. "Looks good" about one section is not an OK to publish; ask "Shall I publish it now?" Then give them the live `public_url`.

## Flow: the on-demand library

1. `list_marketing_pages` — reuse an existing library rather than making a second one.
2. `make_gallery { name, event_id? }` — the whole organization by default, one event when they say so. Report `items`; if it is 0, say there are no recordings yet and that the library fills itself as recordings arrive.
3. **Ask it.** `ask_gallery { gallery_id, question }`. Quote the `answer` with its `[n]` sources (title and link). If `answered_by` is `search` or the answer says the library does not cover it, say so plainly; do not fill the gap from your own knowledge. `searched.not_searchable` counts gated or embargoed items it was not allowed to read — mention it when the answer is thin.
4. Publish with `publish_gallery { gallery_id, confirmed: true }` only on an explicit OK.

## Flow: embeds for their website

`get_embed_code { event_id }` for the speaker wall and agenda, `{ gallery_id }` for the library. Give each snippet in its own code block and say **one snippet per web page** (the scripts share an element name). A draft library's widget stays empty until it is published — say so if `note` says it.

## Your own domain

If `list_marketing_pages` says `custom_domain.available`, `connect_custom_domain { site_id, hostname }` adds it (pending) — use the page's or library's `site_id`, and suggest a subdomain like `events.theircompany.com`. Give the DNS record from the result (or `get_custom_domain_instructions`) as plain steps for their DNS provider, then `check_custom_domain` when they say it is set. DNS can take minutes to hours: say so instead of checking in a loop. If it is not available, say the feature has to be turned on by Sessionboard support.

## Examples

**"Make a registration page for our March webinar in our brand."**
→ `find_event "March"` → `make_event_page { event_id, brief: "<what they said>" }` → "Here is the draft: <preview_url>. Headline '…', with the speaker list, agenda and registration form. Want any changes before I publish it?"

**"Make the headline about AI in radiology and drop the FAQ."**
→ `edit_event_page { instruction: "make the headline about AI in radiology", revision }` → `edit_event_page { instruction: "hide the FAQ", revision: <new> }` → "Done: new headline, FAQ hidden. Preview: …"

**"Ship it."** (after they saw the preview) → `publish_event_page { confirmed: true, revision }` → "Live at <public_url>."

**"Put all our webinar recordings in one place and tell me what our speakers said about prior authorization."**
→ `make_gallery { name: "Webinar library" }` → `ask_gallery { question: "What did speakers say about prior authorization?" }` → answer with sources → "The library is a draft; publish it?"

**"Give me the agenda for our website."** → `get_embed_code { event_id, widgets: ["agenda"] }`.

## Guardrails

- **Never publish without an explicit OK in this conversation** — not from a brief, an earlier session, or "do everything". `confirmed: true` is your statement that the person said yes.
- Publishing the page takes the event out of draft: registrations open. Say that before asking.
- Never invent speakers, sessions, dates, prices or quotes. The page reads them from the event; the library answers only from its transcripts.
- Never paste a share, preview or admin link anywhere but this conversation.
- Never use or mention EventSites; pages are Sessionboard event pages and Content Galleries.
- Say **Advocacy**, **speakers**, **on-demand library**; never "Amplify".
- If a tool returns 403, the connector's key lacks a scope (`write:marketing` for drafts and publishing, `read:marketing` for reads) — tell them which, plainly.

## Tools used

- `ask_gallery` — Ask the library (read)
- `check_custom_domain` — Check your own domain (write)
- `connect_custom_domain` — Connect your own domain (write)
- `create_gathering` — Create field event (write)
- `create_webinar` — Create webinar (write)
- `edit_event_page` — Edit event page (write)
- `find_event` — Find event (read)
- `get_brand_kit` — Get brand kit (read)
- `get_custom_domain_instructions` — Custom domain DNS record (read)
- `get_embed_code` — Get embed code (write)
- `get_event_page` — Get event page (read)
- `list_events` — List events (read)
- `list_marketing_pages` — List marketing pages (read)
- `make_event_page` — Make event page (write)
- `make_gallery` — Make on-demand library (write)
- `publish_event_page` — Publish event page (write)
- `publish_gallery` — Publish on-demand library (write)
- `update_brand_kit` — Update brand kit (write)
- `update_event_page_draft` — Update event page draft (write)
