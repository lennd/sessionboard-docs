---
name: sites
description: "Build and edit a Sessionboard Site (Learning, Marketing or Awards) by chat, preview it by role and device, publish on your OK."
---

# Sessionboard Sites by chat

One Site builder serves Learning Sites, Marketing event pages and Awards Sites. These tools edit the same draft the builder in Sessionboard shows, so the person sees your edits appear in an open builder, and you read theirs.

## When to use

Build and edit a Sessionboard Site (Learning, Marketing or Awards) by chat — pages, blocks, menu, light/dark and Brand Kit, preview as a role on a device, see what changes, publish on the person's OK, restore an earlier version.

## The loop

1. **Find the Site**: `list_sites` (filter by `product`). If there is none, `make_site`: from the org's own data (`product`), from a page (`url` → `source_page`), or for an event (`event_id`, Marketing).
2. **Read it**: `get_site`. Note `revision`, the page `ref`s, block `id`s, `roles` and `block_catalog` (each kind's config schema and an example).
3. **Edit the draft**: `edit_site { site_id, base_revision, ops }`. Each op is an object whose `op` key names it. Batch related changes into one call. On a 409, read again and redo. **Pause:** say what you will add or change, then edit on their yes (it changes the draft only; nothing goes live).
   - "Add an FAQ about parking" → `ops: [{ op: "block.add", block: { kind: "faq", config: { heading: "Parking", items: [{ question, answer }] } } }]`
   - "Make the hero shorter" → `ops: [{ op: "block.update", block: { id, config: { intro: "…" } } }]` (config merges)
   - "Add a Parking page and put it in the menu" → `{ op: "page.add", … }`, then after publishing `{ op: "nav.set", … }` (a menu item needs a published page id; until then the menu follows the pages).
   - "Dark mode, our green" → `ops: [{ op: "theme.set", theme: { mode: "dark", primary: "#14653A" } }]`
4. **Show it**: `preview_site` for the role and device that matter ("as a learner on a phone") and give the person `preview_url`; `get_site_diff` for `summary`.
5. **Publish only on their OK**: `publish_site { revision, confirmed: true }` with the revision of the diff they approved. From a connected assistant this answers *needs_approval*: tell them "Waiting for your OK in Sessionboard: <url>" and stop.
6. **Undo**: `list_site_versions` → `restore_site_version` (into the draft) → show the diff → publish on their OK.

## Rules

- Never publish without an explicit OK in this conversation. Never infer it.
- Speakers, dates, places and course lists come from Sessionboard data. Do not type them into text blocks yourself. Details the person gives you in this conversation ("parking is in Lot B") are fine to write; ask for any you would otherwise have to guess.
- Marketing event pages are one page (`page: "home"`) and keep their hero and Register blocks.
- Words: Review (Reviewer, Round), never "judge" or "evaluation"; Nominee for people who submit to Awards.

## Tools used

- `edit_site` — Edit Site draft (write)
- `get_site` — Get Site (read)
- `get_site_diff` — What would change (read)
- `list_site_versions` — List Site versions (read)
- `list_sites` — List Sites (read)
- `make_site` — Make a Site (write)
- `preview_site` — Preview Site (read)
- `publish_site` — Publish Site (write)
- `restore_site_version` — Restore Site version to draft (write)
