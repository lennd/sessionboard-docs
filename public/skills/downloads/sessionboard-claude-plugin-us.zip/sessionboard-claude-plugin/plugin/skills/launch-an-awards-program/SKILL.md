---
name: launch-an-awards-program
description: Draft a Sessionboard Awards program from a sentence: categories, eligibility and scorecard, then open nominations on your OK.
---

# Launch an Awards program

The person gets an Awards program drafted from a sentence, with its Categories, deadline, nomination form and Scorecard, and then opened on their Awards Site once they approve it in Sessionboard. It works the same for a self-serve Awards workspace and a full-platform organization. Plan limits (one review Round on self-serve, no fees or single sign-on outside Enterprise Awards) and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to set up an Awards program and open it for nominations - draft a program from one sentence, set its Categories, deadline and who can nominate, shape the Scorecard Reviewers fill in, and put the nomination form on their Awards Site. Triggers on "set up our 2027 awards", "create an awards program for young professionals", "add a Category for Innovation", "change the nomination deadline", "let people nominate themselves", "make the scorecard 1 to 10", "open nominations", "where is the nomination link?", "remind people who started a nomination".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Reads need the `read:awards` scope; changes need `write:awards`. If scopes were added after connecting, the person disconnects and reconnects the connector.
- Sessionboard checks the person's own Awards permissions: `ORG.AWARDS.READ` to read programs, `ORG.AWARDS.CREATE` to draft one, `ORG.AWARDS.UPDATE` plus being a manager of that program to change or open it.
- A key restricted to particular events is refused: Awards needs an organization-wide connection.

## Guardrails (read first)

- **Confirm before every write or send.** Before `draft_awards_program`, `update_awards_program`, `update_awards_scorecard`, `open_awards_nominations` or `remind_awards` with `preview: false`, show exactly what will change (program name, Categories in order, deadline with time zone, who can nominate, each scorecard criterion, recipient counts) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Some actions wait for a person in Sessionboard.** Opening nominations and sending reminders answer `needs_approval` with a URL. Say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again for the same program.
- Nothing is public while the program is a draft. Opening it puts a public nomination form on the Awards Site.
- Pass the person's request in their own words as `asked` on `open_awards_nominations` and `remind_awards`; it is shown on the approval.
- Enterprise-only answers (`enterprise_only`: more than one review Round, fees and payments, single sign-on) change nothing. Say what needs Enterprise Awards and that an admin upgrades in Sessionboard (Awards → Enterprise). Do not look for a way around it.
- Words: Awards program, Category, Submission (a nomination when someone nominates someone else), Nominee, Reviewer, Round, Scorecard, Winner. Never "judge", "entry" or "evaluation".

## The workflow

1. **See where they are.** `get_awards_home` returns the profile (who the awards are for, what is awarded), the plan (`tier`), counts and every program. If a similar program is already there, ask whether to change it instead of drafting a new one. (`list_awards_programs { offset? }` is needed only to page past the programs the home read returns.)
2. **Draft from their sentence.** Turn "Awards for young professionals in our field, nominations close March 1" into a name, an optional description, Categories, a deadline (ISO 8601 with offset, for example `2027-03-01T23:59:00-05:00`; `Z` is UTC) and who can nominate (`nominate_others` or `self_only`). Leave Categories out to let Sessionboard suggest them from the organization's audience.
   An Awards program has no time zone of its own: the deadline is exactly the moment you send. When the person gives only a date ("close March 1"), ask which time zone, or propose 23:59 in the time zone they work in and say so; never send a bare date or silently use UTC.
   **Pause:** show the name, description, Categories, deadline with its time and time zone ("March 1, 2027, 23:59 Chicago time") and nomination mode. Ask "Create this as a draft? Nothing is public yet."
   On yes: `draft_awards_program { name, description?, categories?, deadline?, nomination_mode? }`. It comes with a nomination form, a Scorecard on the one review Round, and the Winner types Winner and Finalist.
3. **Read it back.** `get_awards_program { program_id }`. The program is under `program` (with `program.categories` and `program.categories_revision`); `form`, `scorecard` and `winner_types` sit beside it at the top level. Show the Categories, the nomination form's questions, the review Round dates (the Round starts when nominations close and runs three weeks) and the Scorecard. Keep `program.categories_revision` for step 4.
4. **Change the program.** For a new name, description, deadline, nomination mode, blind review (Reviewers don't see nominator or Nominee names), or Categories:
   - The Category list is replaced whole. Keep a Category by passing `{ id, name }` from the read; add one with a name; a Category left out is removed. Say which ones would be removed.
   **Pause:** show the before and after. Ask for a yes.
   `update_awards_program { program_id, name?, description?, deadline?, nomination_mode?, blind_review?, categories?, categories_revision? }`. `categories_revision` is required with `categories`. Not safe to repeat: after any error, read the program again before retrying.
5. **Shape the Scorecard.** Each criterion is `scale_1_5`, `scale_1_10` or `free_text` (a comment), with optional `required` and `weight`. Keep a criterion by passing its `id`; one left out is removed. Up to 12.
   **Pause:** show every criterion in order with its type and weight. Ask for a yes.
   `update_awards_scorecard { program_id, criteria }`. Refused once any Reviewer has scored.
6. **Open nominations.** Only after the person has seen the program as it stands.
   **Pause:** "Opening puts a public nomination form on your Awards Site, starting now, until <deadline>. Open it?"
   On yes: `open_awards_nominations { program_id, deadline?, asked? }`. It answers `needs_approval`: give the person the URL and stop.
   During a trial, the organization takes up to 50 nominations across all its programs (`trial_cap`: `limit` and `submitted` so far) before a person is asked to choose a plan; nobody is turned away. A new program can start with some of that used by other programs: say how many are left. A trial opens without a card.
7. **Share the link.** After the person approved it, `list_awards_programs` shows the public nomination link on the program. The Awards Site itself is in `list_sites { product: "awards" }` (its `url`). Give the link; do not guess one.
8. **Nudge unfinished nominations** (while nominations are open). `remind_awards { program_id, audience: "drafts", preview: true }` lists who would get it and who is skipped (nobody gets the same reminder twice in 24 hours).
   **Pause:** show the count and who is skipped. Ask "Send this reminder?"
   On yes: `remind_awards { program_id, audience: "drafts", preview: false, asked? }`. It answers `needs_approval`: give the URL and stop.

## When something goes wrong

- **403 "Forbidden … needs the read:awards scope … and a user who can manage Awards"**: missing scope or permission. The person reconnects, or asks an admin for Awards access or to be made a program manager.
- **403 with an organization-wide message**: the key is restricted to events. Connect with an organization-wide connection.
- **403 `plan_ended` / `trial_ended`** in the message: the self-serve plan is read-only. A person chooses a plan in Sessionboard (Awards → Plan and billing).
- **402 / `card_required`** (older servers): a person chooses a plan in Sessionboard. Nothing was opened.
- **`enterprise_only`**: see the guardrail. Nothing changed.
- **409 Conflict** on Categories: someone changed them since your read. `get_awards_program` again, rebuild the list from the new read, confirm again.
- **"Partly done"** from `update_awards_program`: the fields saved, the Categories did not. Read again and send only the Category change.
- **404**: check the id with `list_awards_programs`.
- **429 "Too many requests"**: Sessionboard is rate-limiting this connection. Nothing changed. Wait a minute and retry once; if it happens again, tell the person and try later.
- **422 `nominations_closed` / `no_site`** from a drafts reminder: nominations are not open, or the program is not on an Awards Site yet. Say so.

## What this skill does not do

- Edit the nomination form's questions. A person does that in Sessionboard.
- Close nominations early. They close at the deadline; a person can close them in Sessionboard.
- Change the setup answers (who the awards are for). A person does that in Sessionboard.
- Add fees, payments, promo codes, more review Rounds or single sign-on. Those are Enterprise Awards.
- Design the Awards Site pages. Use the Sites tools for that.

## Tools used

- `get_awards_home` — the profile, plan, counts and programs (read)
- `list_awards_programs` — every program, its status and public nomination link (read)
- `get_awards_program` — one program: Categories with `categories_revision`, form, Scorecard, Round dates (read)
- `draft_awards_program` — create a draft program (write)
- `update_awards_program` — name, description, deadline, nomination mode, blind review, Categories (write)
- `update_awards_scorecard` — replace the Scorecard (write)
- `open_awards_nominations` — put the nomination form on the Awards Site; waits for a person's OK (write)
- `remind_awards` — preview, then remind people with unfinished nominations; the send waits for a person's OK (read / sends)
- `list_sites` — the Awards Site's URL (read)
