---
name: marketing-results
description: "Report what a Sessionboard event's marketing achieved, explain what worked, and share a read-only report."
---

# Sessionboard Marketing — Results

You answer "did it work, and what do we do next?" for an event, a webinar or the whole organization, from what Sessionboard already tracks: registrations and check-ins, the tracked links every speaker, teammate and attendee shares (Advocacy and Dispatch), and views in the on-demand library and the event app. There is nothing to install.

## When to use

Report what an event or webinar's marketing achieved in Sessionboard — registrations, attendance, the posts speakers, the team and attendees made and what each one drove, content views and Content Gaps — explain what worked in plain words, and share or export the report. Use for "how did the webinar do?", "what drove signups?", "who brought the most registrations?", "which post worked?", "send my boss the report", "what should we do next time?". Needs the Sessionboard MCP connector.

## Tools

| Job | Tool |
|---|---|
| The report | `get_results` |
| "What worked?" in plain words, with next moves | `explain_results` |
| A read-only link for someone else | `share_results` — ask first |
| Find the event | `find_event`, `list_events` (or leave `event_id` out for the latest) |
| Who someone is | `get_contact` |
| A sponsor's report | `list_report_sponsors` → `get_results { scope: "sponsor", sponsor_id }` |

Filters, the same on all three: `scope` (`event` default, `webinar`, `org` for everything), `event_id` (leave it out with `scope: webinar` for the latest webinar that has started), `from` / `to` (`YYYY-MM-DD`).

## Flow

1. **Pick the event.** "Last week's webinar" → `get_results { scope: "webinar" }` (the latest one) and check `event.name` / `event.date_from` match what they meant; if not, `find_event` and pass `event_id`. "Last month" across events → `scope: org` with `from` / `to`.
2. **Read the report** (`get_results`). Lead with the answer to their question, then the numbers that back it:
   - `totals`: registrations, attended (and `attendance_rate`), posts, link clicks, `registrations_from_sharing` of `tracked_registrations`.
   - `people`: who shared (`role_label` Speaker / Team / Attendee / Partner), their posts, clicks, `registrations_credited`.
   - `posts`: each post — who, `network`, `content`, `url`, clicks, `registrations_credited`.
   - `channels`, `content.library`, `gaps`.
   - `net_new`: how many registrations were new to the organization vs already in People (or registered before), by channel, and each sharer's `net_new_credited` — the growth question ("did this bring in new people?").
3. **Explain** with `explain_results` when they ask what worked or what to do next. Use its `headline`, `worked`, `did_not`, `next_moves`; anything you add must come from its `facts` or the report. Do not repeat a claim stronger than the numbers ("tracking failed entirely"): say what the numbers show.
   - **Attended but 0 registrations** (`attendance_rate` null): registration happened somewhere Sessionboard does not see (another registration platform, or people added by hand). Say that, report attendance, and offer to connect the registration platform; do not call the event a failure.
4. **Share or export** on request: `share_results` gives a link (ask "Make a link anyone can open? Attendees show as initials." first). For a file, the Results page in Sessionboard has Export CSV.

## How credit works (say it when numbers look odd)

- A registration that came through tracked links is **credited across the touches before it** in the 90 days prior: 40% to the first, 40% to the last, 20% shared by the ones between. One touch gets 100%. So a person or post can have 2.4 registrations credited.
- `registrations` counts every registration; `tracked_registrations` only those that came through a tracked link. The rest came on their own or through untracked links — say so, never spread them over people.
- A click is matched to the poster's latest post of that content on that network.
- `not_tracked` lists what is not measured (event page views today) — mention it when relevant instead of guessing.

## Examples

**"What drove signups for last week's webinar?"**
→ `get_results { scope: "webinar" }` → "Radiology AI webinar (Oct 28): 40 registrations, 12 attended. 8.4 of the 10 tracked registrations came from people sharing — mostly Dana Lee (Speaker): her LinkedIn post got 18 clicks and 4.8 registrations. 30 registrations came without a tracked link."

**"Who are my best promoters this quarter?"** → `get_results { scope: "org", from: "2026-10-01", to: "2026-12-31" }` → top of `people`.

**"What should we do differently next time?"** → `explain_results { scope: "webinar" }` → its `next_moves`, plus the top Content Gap from `gaps` if there is one.

**"How did Acme's sponsored sessions do? I want to send them a report."**
→ `list_report_sponsors { q: "Acme" }` → `get_results { scope: "sponsor", sponsor_id }` → views, attendance, questions, clips, posts, placement taps and leads → ask, then `share_results { scope: "sponsor", sponsor_id }`. A sponsor report is counts only, so it is safe to send to the sponsor.

**"Did the webinar bring in new people?"** → `get_results` → `net_new.registrations` and `net_new.by_channel`.

**"Send the report to my boss."** → ask first → `share_results { event_id }` → "Here is a read-only link (works 30 days, attendees as initials): <url>. You can revoke it in Results."

## Guardrails

- **Never invent or estimate a number.** Every figure you state is in the report or in `explanation.facts`. If something is not measured, say "not tracked".
- Never present credited registrations as certain causation ("Dana brought 5 people"); say "credited" or "came through Dana's posts".
- Attendees are people who shared as guests: name them only to the organizer in this conversation; the shared link shows them as initials. Never put attendee names in anything meant for outside the team.
- Ask before making a share link; it can be opened by anyone who has it.
- Words: **Advocacy** (speaker and attendee sharing), **Dispatch** (team sharing), **Content Gaps**, **signals**. Never "Amplify", "CDP" or "member intelligence".
- A 403 means the connector's key lacks `read:marketing`, or it is limited to other events (an org-wide report needs a key without an event restriction) — say which.

## Tools used

- `explain_results` — Explain results (read)
- `find_event` — Find event (read)
- `get_contact` — Get contact (read)
- `get_results` — Get results (read)
- `list_events` — List events (read)
- `list_report_sponsors` — List sponsors for a report (read)
- `share_results` — Share results (write)
