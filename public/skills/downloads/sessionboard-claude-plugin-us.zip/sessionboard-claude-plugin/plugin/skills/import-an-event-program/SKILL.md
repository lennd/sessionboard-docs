---
name: import-an-event-program
description: "Import an event's program, speakers or sponsors into Sessionboard from a file or a link, with a preview before anything is written."
---

# Import an event program

The person gets their sessions, speakers and sponsors into an event from a list they already have, with a row-by-row preview first and nothing duplicated if they import twice. It works for any Sessionboard organization: a self-serve Sessions workspace and a full-platform account use the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to bring an existing program, speaker list or sponsor list into an event from a spreadsheet, a pasted table, a file or a link they share, seeing exactly what will happen row by row before anything is added. Triggers on "import our program from this spreadsheet", "load last year's sessions", "here's the agenda as a CSV", "add these 40 speakers", "import the speaker list from this sheet", "add our sponsors: Acme, Globex…", "bring this program in as submissions", "what would this import do?", "remove the Initech sponsor".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Scopes: `read:sessions` and `write:sessions`. A connection limited to particular events is refused.
- Previewing and importing need an organization admin (the preview writes nothing but is an admin action). A role that sees only some contacts is refused here.
- Event ids are numbers from `get_sessions_home`; on a full-platform account `find_event { search }` also finds one. `get_sessions_event { event_id }` shows its timezone, tracks, rooms, formats and sponsors.
- **You read the file.** No Sessionboard tool opens a file or a link. Read what the person shares (an attachment, a pasted table, or a page or sheet you can open yourself), turn it into rows, and say which columns you mapped to what.

## Guardrails (read first)

- **Preview before every import.** Run `preview_event_import` on exactly the rows you will send, show the result, and get a clear yes in this conversation before `import_event_program`, `import_event_speakers`, `import_event_sponsors` or `manage_event_sponsors`. Never infer a yes from an earlier answer or a plan. Reads and previews need no confirmation.
- **Never guess data.** Leave a field out rather than invent it. Every speaker needs a real email; rows without one are skipped.
- **Accepted by default.** Imported sessions are accepted (on the agenda, speakers count toward the plan) unless the person says they are submissions: then send `status: "pending"` so they arrive undecided. Rows marked declined are skipped. Ask which, once.
- **Existing contacts may be updated.** Speakers are matched by email across the whole organization; an existing contact gets the details the row fills in. Ask whether to update existing contacts. Only `import_event_speakers` can keep them as they are (`update_existing: false`); `import_event_program` always updates them. If the person wants existing contacts left alone, do not run the program import with speakers: import the sessions without speakers, then the speakers with `import_event_speakers { update_existing: false }`, or stop and say so.
- **Removing a sponsor also untags its sessions.** Say so first.
- Nothing here emails anyone.
- Words: "session", "speaker", "sponsor", "submission". Never name the in-product assistant or internal engines.

## The workflow

### 1. Map the file
1. Read the file and list its columns. Map them to: title, description, track, format, room, status, start, end or duration (minutes), sponsors (names), speakers (first name, last name, email, job title, company).
2. Times are on the event's clock (`"2027-03-10 09:00"`) or ISO with an offset. Check the event's timezone in `get_sessions_event`.
3. **Pause:** show the mapping and three sample rows. Ask accepted or submissions, and whether existing contacts may be updated.

### 2. Preview
`preview_event_import { event_id, kind, rows, status? }` writes nothing. **Its rows use the import's own keys (camelCase):**
- `kind: "sessions"`: `{ title, description, track, format, room, status, startsAt, endsAt, duration, sponsors: ["Acme"], speakers: [{ firstName, lastName, email, title, company }] }`
- `kind: "speakers"`: `{ firstName, lastName, email, title, company }`
- `kind: "sponsors"`: `{ name, website }`
Up to 500 rows per preview. It returns each row's outcome (new, already there, skipped) and why, the counts, the tracks, rooms and formats it would create, and whether the plan's speaker limit would refuse it. Typical reasons: `title_exists`, `duplicate_in_file`, `declined`, `missing_email`, `bad_email`, `bad_time`, `end_before_start`, `unknown_sponsor`, `will_update`, `over_limit`.

**Pause:** show the counts, every skipped row with its reason, the new tracks, rooms and formats, and any limit refusal. Offer to fix rows (e.g. add the sponsor first, correct a time) and preview again. Ask "Import these N sessions?"

### 3. Import
**Sponsors first** if sessions name sponsors not yet on the event (sessions can only tag sponsors already there):
- A list: `import_event_sponsors { event_id, sponsors: [{ name, website? }] }` (up to 50; names already on the event are skipped).
- One: `manage_event_sponsors { action: "add", event_id, name, website? }`.

**Sessions with their speakers:** `import_event_program { event_id, rows, status? }`. Its rows use **snake_case** keys:
`{ title, description?, track?, format?, room?, row_status?, starts_at?, ends_at?, duration_minutes?, sponsors?, speakers?: [{ first_name?, last_name?, email?, job_title?, company? }] }`.
Up to 300 rows per call; send larger files in batches of 300. Titles already on the event are skipped, so a retry makes no duplicates.

**Speakers without sessions:** `import_event_speakers { event_id, speakers: [{ email, first_name?, last_name?, job_title?, company? }], update_existing? }` (up to 500). Everyone is linked to the event as a speaker.

### 4. Report and tidy up
1. Say what was added, skipped and updated, from the result.
2. `get_event_agenda { event_id }` or `list_submissions { event_id }` to show the result.
3. A sponsor added by mistake: **Pause**, then `manage_event_sponsors { action: "remove", event_id, sponsor_id }` (sponsor ids from `get_event_agenda`).
4. Next steps: scheduling is the `build-the-agenda` skill; missing bios and titles are `get-speakers-ready`.

## When something goes wrong

- 403 "More speakers on this event is not part of this Sessions plan" (`enterprise_only`): the accepted speakers would pass the plan. Nothing changed. Import as submissions (`status: "pending"`), import fewer, or a person with admin rights chooses a bigger plan in Sessions → Plan and billing.
- `trial_ended` / `plan_ended`: read-only. Everything can still be read.
- 403 "Forbidden … read:sessions …": missing scope or not an organization admin. Reconnect if scopes were added later.
- 404: check the event id with `get_sessions_home`.
- 400 "Invalid request: …": say the message; fix the rows and preview again.

## What this skill does not do

- No server-side file or link reading: the assistant reads the file.
- No sponsor logos, tiers, contacts or portals (the platform's sponsor tools).
- No session custom fields, sub-sessions, or speaker bios and headshots in the import.
- Does not create the event from its public web page; create it first (`run-a-call-for-speakers`).
- No undo of an import; sessions added are removed one by one in Sessionboard.

## Tools used

- `get_sessions_home` — Sessions events (read)
- `find_event` — find a full-platform event by name (read)
- `get_sessions_event` — timezone, tracks, rooms, formats, sponsors (read)
- `preview_event_import` — what an import would do, row by row; writes nothing (read)
- `import_event_sponsors` — add a sponsor list (write)
- `manage_event_sponsors` — add or remove one sponsor (write)
- `import_event_program` — add sessions with their speakers (write)
- `import_event_speakers` — add a speaker list, matched by email (write)
- `get_event_agenda` — the result, and sponsor ids (read)
- `list_submissions` — the result when imported as submissions (read)
