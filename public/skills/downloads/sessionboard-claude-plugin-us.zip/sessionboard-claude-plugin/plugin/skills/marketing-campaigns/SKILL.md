---
name: marketing-campaigns
description: "Run Sessionboard Marketing campaigns: speakers and the team sharing an event, video collection, follow-ups, results per person."
---

# Sessionboard: Marketing campaigns

A campaign is **one noun picked by intent**. It is a one-page draft — **Who / What / Link / When** — that the person reviews once, then you launch it. Everything goes through one tool, `manage_campaign`.

| Intent (`kind`) | Say it as | Who | What each person gets |
|---|---|---|---|
| `speakers_share` | Speakers and guests share | the event's speakers and guests | a personal kit: their card, a short video card, a post in their voice, a tracked link. Optional reward line: personal promo code, a prize for the top sharers, a leaderboard |
| `team_share` | Your team shares | your org's teammates | a kit by Slack (if connected) or email, posted in one tap, with a team leaderboard |
| `collect_videos` | Collect videos | the event's speakers (or anyone named) | a link to record a 30-second video in the browser, with a prompt from their own session. Consent is captured; nothing is used until you approve it |
| `follow_up` | Follow up with everyone who came | the event's attendees (confirmed / checked in) | a recap made for them (their clips and moments when the event has a recording) |
| `attendees_share` | Attendees share they're going | everyone registered (and, from launch on, every new registrant via their confirmation email) | an "I'm attending" card, a post and their own tracked link |
| `email_series` | Email until they register | past attendees (default), attendees, speakers, sponsors or exhibitors | a short series (`what.steps`: `[{ delay_days, subject, message }]`); each person stops getting it the moment they register |
| `win_back` | Win back last year's people | people registered for your past events who haven't registered for this one | the same series, written to bring them back |

**Who** can be changed with `who.source`: `speakers_share` takes `speakers`, `sponsors` or `exhibitors` (sponsor and exhibitor contacts get their own kit link; the speaker campaign stays speakers-only); `collect_videos` also takes `attendees`. A source the intent can't reach comes back as a plain sentence — show it and pick another.

**Words.** To the person, say "campaign" and the intent names above. Never say Advocacy, Dispatch or Voices — those are internal engine names.

## When to use

Run marketing campaigns in Sessionboard from Claude (any account — a Marketing workspace or the full platform) — get speakers and guests sharing an event, send the team a share kit, collect 30-second videos, follow up with everyone who came, and read results per person. Use when someone asks to promote an event or episode through its speakers, guests or team, to "get people sharing", to collect videos or testimonials, to send recaps or a follow-up after an event, or asks how a campaign is doing ("who shared", "who brought registrations", "leaderboard"). Needs the Sessionboard MCP server's manage_campaign tool.

## The flow: draft → show → launch on their OK

1. **Draft from their sentence.** Pass their words as `prompt`; the intent and the event are picked from it.
   ```json
   { "action": "draft", "prompt": "get our presenters promoting episode 7" }
   ```
   Add `kind` or `event_id` only when the sentence is ambiguous (several events match, or "share" could be speakers or team). If you cannot tell which event, call `list_events` / `find_event` first and ask.
2. **Show the person the draft.** Present it as one short page, in this order:
   - **Who** — `who.count` and a few names from `who.sample` ("3 speakers: Ada Lovelace, Grace Hopper, Alan Turing")
   - **What** — the subject, the message, and the post (`{link}` becomes each person's own tracked link)
   - **Link** — `link.url`
   - **When** — now
   - **Reward** (speakers sharing only) — promo code / prize / leaderboard, if on
   - then `approval.summary`, word for word, and ask: "Launch it?"
   **Stop here and wait.** Do not launch in the same turn as the draft.
3. **Edit if they ask.** `{ "action": "update", "campaign_id": "…", "what": { "message": "…" } }`. Sections merge. Every edit raises `draft_version`, so show the changed part again and ask again.
4. **Launch only on an explicit yes** to that exact draft, passing `approval.launch_with` as the `manage_campaign` arguments:
   ```json
   { "action": "launch", "campaign_id": "…", "draft_version": 2, "approved": true }
   ```
   A 409 means the draft changed after they saw it: `get` it, show it, ask again.
5. **If it answers `needs_approval`** (the usual answer from a connected assistant): nobody has been emailed yet. Tell the person "Waiting for your OK in Sessionboard: <url>" and stop; do not call `launch` again. Once a person approves it there, it runs as them. Report recipients only after a later `manage_campaign { action: "get", campaign_id }` shows it launched.
6. **When it ran**, report what happened from `launch_summary` (who was reached, who was skipped and why) and offer to check results later.

## Rewards and invites (speakers and attendees sharing)

The reward line (`reward`) turns on a personal promo code (`promo_code: { enabled, prefix }`), a prize for the top sharers (`prize: { enabled, text, top }`) and a leaderboard. Each sharer's kit page shows the prize, the leaderboard and where they stand, and lets them invite up to 25 of their own contacts: those emails go out in the sharer's name, replies go to them, and every click and registration is credited to them (`invites` in results).

## Videos

Speakers recording a video see talking points pulled from their own session abstract, as a teleprompter. For the venue, `{ "action": "kiosk", "campaign_id": "…", "on": true }` returns a link for an iPad (shown once — tell the person to open it on the iPad now); guests type their name, agree, and record. Every recording waits for approval; approving one (`review_video`) puts it in the Media library (transcript and captions follow, galleries and reels can use it) and on the speaker's kit. Every video carries the exact consent text and when it was given — mention it when the person asks whether they may use a video. `{ "action": "montage" }` lists the approved videos as a reel hand-off.

## Results

`{ "action": "results", "campaign_id": "…" }` → `totals` (people, reached, opened, shares, clicks, registrations, invites, videos, registered after a series email) and per person: status, tracked link, promo code, shares, clicks, registrations, invites, video. It also returns `feed`: what happened, newest first (shared, clicked, registered, invited, video, opened). For "what's happening now", call again with `since` set to the previous `feed.cursor` and tell the person only what's new. `leaderboard` is the top 10 by registrations, then clicks, then shares. Lead with what matters: "Ada's link brought 4 registrations; Grace shared twice; Alan hasn't opened his kit yet."

Other actions: `list` (filters `status`, `kind`, `event_id`), `get`, `pause` (tracked links stop working), `resume`, `videos` (a Collect videos campaign's recordings, with consent), `review_video` (`video_id`, `decision` approved | rejected — only after the person has watched it).

## Examples

- "Get our presenters promoting episode 7" → draft `speakers_share` for the event named "… Episode 7" → show → launch on yes.
- "Give speakers a 20% code and a prize for the top three" → `update` with `reward: { promo_code: { enabled: true, prefix: "EP7" }, prize: { enabled: true, text: "Front-row seats", top: 3 } }`.
- "Leave Alan out" → `update` with `who: { exclude: ["alan@example.com"] }` (emails or contact ids from the draft).
- "Have the team post about the summit" → `team_share`.
- "Collect short videos from our panelists" → `collect_videos`; tell them videos wait for their approval.
- "Send everyone who came a recap" → `follow_up`.
- "Get our sponsors posting" → `speakers_share` with `who: { source: "sponsors" }`.
- "Let attendees tell people they're going" → `attendees_share`.
- "Email last year's people until they sign up" → `win_back`; "email our list until they register" → `email_series`. Show the steps and their timing as part of the draft.
- "Set up a video booth at the venue" → a `collect_videos` draft, launch on yes, then `kiosk` on.
- "How's the episode 7 campaign doing?" → `list` → `results`.

## Guardrails

- **Never launch without a yes to the draft you showed.** Approval of an earlier version does not carry over. "Go ahead and set it up" means draft, not launch.
- Launching emails real people in the organization's name; one launch per campaign. Do not launch to "test" — draft instead.
- Scheduled one-off sends are not available: if they want it later, keep it as a draft and say so. A series spaces its own steps once launched.
- Video approval is a person's decision: never `review_video` approved on your own judgement.
- Attendees are never added to the CRM; don't offer to.
- A 403 about scopes means the connection lacks `read:marketing` / `write:marketing`; any other 403 means the person lacks access to the organization or, to draft and launch, is not an org admin. Say so plainly. Campaigns work on every kind of Sessionboard account.

## Tools used

- `find_event` — Find event (read)
- `list_events` — List events (read)
- `manage_campaign` — Manage marketing campaign (write)
