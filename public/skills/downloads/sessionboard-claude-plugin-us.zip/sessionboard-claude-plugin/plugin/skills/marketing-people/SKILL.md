---
name: marketing-people
description: "See who your Sessionboard events and campaigns reached and what each person did: shared, clicked, registered, watched."
---

# Sessionboard: People

One list that builds itself from every event and campaign. Nothing to import: a person appears because a session, a sponsor, a registration, the team or a campaign names them. One row per email.

- **Roles:** speaker (on a session or a speaker campaign), sponsor (contact at a sponsoring company), attendee (registered), team (org member). One person can hold several.
- **Activity:** `shared`, `clicks` (on their tracked links), `brought` (registrations their links produced), `registered`, `watched` (sessions attended / watched, content viewed), `campaigns` (that reached them), `videos` (recorded).
- **CRM:** per connected system (HubSpot, Salesforce): `synced` with the external id, `not_synced`, or `not_in_crm`. Attendees and teammates are never written into the CRM.

## When to use

Look up people in Sessionboard (any account) — everyone the organization's events and campaigns name (speakers, guests, sponsors, attendees, the team) with what they did: shared, clicked, brought registrations, registered, watched, recorded videos; who brought whom; their timeline; and their HubSpot / Salesforce sync status. Use when someone asks "who are our best promoters", "who brought the most people", "what has Ada done", "who registered through Grace's link", "is she in HubSpot", or wants a list of speakers / attendees with their activity. Needs the Sessionboard MCP server's find_people and get_person tools.

## Tools

- `find_people` — `q` (name / email / company words), `role`, `event_id`, `limit` (≤ 50, default 50), `offset` for the next page. Busiest first. Returns `total`, `counts` per role and `people[]` with a `key`.
- `get_person` — `key` from `find_people` (`c_…`, `a_…`, `u_…`), or `email`. Returns roles, events, activity, `brought` (who registered through their links), `brought_by`, the `campaigns` that reached them, a newest-first `timeline` and CRM status.

## How to answer

- "Who are our best promoters?" → `find_people` (role speaker, or no role) → the top rows by `brought`, then `clicks`, then `shared`. Name people and numbers: "Ada's link brought 4 registrations from 11 clicks."
- "What has Grace done?" → `find_people { q: "grace" }` → `get_person { key }` → summarise the timeline in a few lines, newest first.
- "Who did Ada bring?" → `get_person` → `brought`.
- "Is Ada in HubSpot?" → `get_person` → `crm.systems`.
- "Speakers on episode 7 who haven't shared" → `find_people { role: "speaker", event_id }` and filter `activity.shared == 0`. Offer to draft a nudge as a campaign (marketing-campaigns skill) — don't send anything from here.

## Guardrails

- Read-only. These tools change nothing; acting on people (emails, kits) is a campaign, drafted and approved first.
- Show emails only when the person asks for them; names and numbers usually answer the question.
- `brought_by` can be empty even when someone registered through a link: registrations keep only a hashed email, so the link is credited but the registrant is matched only when they also have a Sessionboard profile.
- Lists are paged; say how many there are (`total`) when you show a slice.

## Engagement (Pathways in Marketing)

Every person has an engagement score (0–100) from what they did at field events, webinars, campaigns and content, explained by its parts and fading over time. Bands: warming up, engaged, highly engaged (the org's lines, default 50 and 80).

- "Who's most engaged after the Chicago lab?" → find the event, then `engaged_people { event_id }`. Quote each `why` as given ("85 = 2 events · 1 webinar · 4 clips · 5/5 opens").
- "Why is Ada at 85?" → `find_people { q: "ada" }` → `explain_engagement { key }`: the parts, the signals, milestones, next best thing and the ask she would get.
- "Who should I invite to the next stop?" → `suggest_invites`. Inviting is a campaign; draft it, don't send.
- "Draft the week-1 round for webinar attendees" → `manage_campaign { action: "list" }` for a running `keep_engaged` campaign (or draft one with `kind: "keep_engaged"`), then `engagement_round { action: "preview", round: "week_1" }`. Send only after the person says yes: `engagement_round { action: "send", approved: true }`.
- Someone highly engaged: their owner hears first (`engagement_pings { action: "list" }`). "Let it offer" emails the person — `confirmed: true` only on the person's yes.
- Results: `engagement_results`. Counts, never lift: Marketing has no holdout. Pipeline appears only when a CRM is connected.
- "How connected am I? What should I connect next?" → `how_connected`. Say `connected_pct`, the `next_best` connection and why, and which superpowers are off and what turns each on. An estimate with `per_month: null` is "more signals", never a number. To connect, `connect_app` returns a link for the person.
- Say engagement score, recap, rounds, signals. Never "member intelligence", "digital twin" or "CDP".

## Tools used

- `connect_app` — Connect app (write)
- `engaged_people` — Most engaged people (read)
- `engagement_pings` — Owner pings (write)
- `engagement_results` — Engaged people results (read)
- `engagement_round` — Engagement rounds (write)
- `explain_engagement` — Explain an engagement score (read)
- `find_people` — Find people (read)
- `get_person` — Get person (read)
- `how_connected` — How connected am I (read)
- `manage_campaign` — Manage marketing campaign (write)
- `suggest_invites` — Who to invite next (read)
