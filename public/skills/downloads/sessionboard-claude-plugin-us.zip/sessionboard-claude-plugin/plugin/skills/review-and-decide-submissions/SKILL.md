---
name: review-and-decide-submissions
description: Work through a Sessionboard call's submissions: team picks, accept, decline or waitlist, and decision emails on your OK.
---

# Review submissions and decide

The person gets a clear view of every submission with their team's picks, records their own decisions (accept, waitlist, decline), and tells declined and waitlisted speakers with an email they have seen first. It works for any Sessionboard organization: a self-serve Sessions workspace and a full-platform account use the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to go through an event's submissions, see what their team thinks, record their own pick, accept, waitlist or decline sessions, and tell speakers the outcome with the decision emails (preview, edit, send). Triggers on "what came in for the summit?", "show me the undecided submissions", "what did the team think of this one?", "put me down as a yes on the AI panel", "accept these five", "waitlist the workshop", "decline the rest", "how many speakers can we still accept?", "show me the decline email", "make the waitlist email warmer", "tell the declined speakers".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Reading needs `read:sessions`; picks, decisions and email changes need `write:sessions`. A connection limited to particular events is refused.
- Any organization member who can use the event reads. Picks, decisions, and editing or sending emails need an organization admin. A role that sees only some contacts is refused here.
- Event ids are numbers from `get_sessions_home` (or `find_event` on a full-platform account). Session ids come from `list_submissions`.

## Guardrails (read first)

- **Confirm before every write or send.** Before `set_my_pick`, `decide_submission`, `update_decision_email` or `send_decision_emails`, show exactly what will change (each session title and its new decision, the email text, how many speakers) and get a clear yes in this conversation. One yes can cover a list you showed item by item; anything not on that list needs its own yes. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **The person decides.** Summarize submissions and picks; do not pick or decide on your own judgement. When the person asks for "the strongest" or "the best few" and there are no team picks to go on, show the candidates and ask which ones. A teammate's pick is never yours to set: `set_my_pick` sets only the signed-in person's own pick.
- **Picks never change a decision.** Only `decide_submission` does.
- **Deciding sends no email.** Accepted speakers hear through Sessionboard's Speaker emails invite. Declined and waitlisted speakers are told only with `send_decision_emails`.
- **Sending waits for a person in Sessionboard.** `send_decision_emails` answers `needs_approval` with a URL: say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again for the same event and kind.
- Always preview the email with `preview_decision_email` before asking to send.
- Words: committee scoring is **Review** (Review plan, Reviewer, Round). Never say "evaluation", "evaluator" or "judge". Say accept / decline, never approve / reject. Never name the in-product assistant or internal engines.
- Committee Review with Review plans, Reviewers and Rounds is the Sessionboard platform; these tools do not run it. Team picks are the lightweight team signal.

## The workflow

### 1. See what came in
1. `get_sessions_home {}`: each event's counts (submitted, undecided, accepted, declined).
2. `list_submissions { event_id, view?, status? }`. `view: "submissions"` keeps what came through the call; `status` is pending (undecided), accepted, waitlisted or declined. Each session has its speakers, description, decision, `track_id`, the team's tally (`picks`: yes, maybe, no, and the person's own pick), and `answers` to the call's own questions, per session and per speaker.
3. The list gives only `track_id`: read the track names once from `get_sessions_event { event_id }` (its tracks list) and show names, never ids.
4. Show a short table: title, speakers, track, tally, decision. Offer to go one by one or by track, and quote a submission's answers when the person asks about one.

### 2. Read the team's picks on one submission
`get_team_picks { event_id, session_id }`: each teammate's Yes / Maybe / No with their comment, and the tally. Quote comments as written.

### 3. Record the person's own pick
**Pause:** "Put you down as <yes|maybe|no> on '<title>'<, with the comment '…'>?" On yes:
`set_my_pick { event_id, session_id, pick, comment? }`. `pick: "clear"` removes it; an empty comment clears the comment.

### 4. Decide
1. Before accepting, check room: `list_event_speakers { event_id }` gives the event's speakers with their `sessions` and the plan's `limit` for the event. It also lists speakers linked to the event with no accepted session (`sessions: []`, for example on undecided submissions): count only speakers with at least one session against `limit`. Accepting past it is refused.
2. **Pause:** list each session title with its new decision (accept, waitlist, decline or undecided) and say "No email goes out from this step." Ask for a yes.
3. One call per session: `decide_submission { event_id, session_id, decision }`. Accepted sessions go on the agenda and their speakers onto Speakers.
4. Report what changed and anything refused.

### 5. Decision emails
1. `get_decision_emails { event_id }`: the accepted email (Sessionboard's Speaker emails invite), the declined and waitlisted templates, the merge fields (`{first_name}`, `{session_title}`, `{event_name}`, `{event_dates}`, `{organization}` …) and how many speakers in each decision have not been told yet. `waiting.accepted` stays 0 after accepting: accepted speakers are told through the Speaker emails invite in Sessionboard, not counted here.
2. Preview: `preview_decision_email { event_id, kind, subject?, body?, session_id? }` shows the email exactly as a speaker gets it. Pass `subject` / `body` to preview a draft before saving. `kind` is accepted, declined or waitlisted.
3. To change the declined or waitlisted email: draft the text, preview it, then **Pause:** show subject and body. On yes: `update_decision_email { event_id, kind, subject, body }`. Both are required and both are replaced: send the current value of the one you keep. Empty subject and body put the default back. The accepted email is edited in Sessionboard (Speakers), not here.
4. To send: **Pause:** show the preview and say "This emails N <declined|waitlisted> speakers who have not been told (or only the sessions you named). Each gets it once. Send?" On yes:
   `send_decision_emails { event_id, kind, session_ids?, asked }`. Leave out `session_ids` for everyone not yet told; never send an empty list.
   - `needs_approval`: "Waiting for your OK in Sessionboard: <url>". Stop.
   - `nothing_to_send`: everyone in that decision has already had it; nothing was sent.
5. Unsubscribed and bounced addresses are skipped.

## When something goes wrong

- 403 "More speakers on this event is not part of this Sessions plan" (`enterprise_only`): accepting would pass the plan's speakers. Nothing changed. A person with admin rights can choose a bigger plan in Sessions → Plan and billing.
- 403 about committee review (`review_plans`): Review plans are the platform.
- `trial_ended` / `plan_ended`: read-only. Everything can still be read.
- 403 "Forbidden … needs the read:sessions scope …": missing scope or not an organization admin. Reconnect if scopes were added later.
- 404: check the event id (`get_sessions_home`) and session ids (`list_submissions`). Team picks exist only on Sessions events.
- 400 / 409 with a message: say the message; read the list again before retrying.

## What this skill does not do

- No committee Review: no Review plans, Reviewer assignments, Rounds or scores.
- No pick or comment on a teammate's behalf.
- Cannot edit or send the accepted email (Sessionboard's Speaker emails invite, edited and sent there).
- No scheduled sends; no email to accepted speakers from here.

## Tools used

- `get_sessions_home` — events and their decision counts (read)
- `find_event` — find a full-platform event by name (read)
- `list_submissions` — submissions with speakers, decision, team tally and answers (read)
- `get_sessions_event` — the event's track names for the table (read)
- `get_team_picks` — each teammate's pick and comment on one submission (read)
- `set_my_pick` — the person's own Yes / Maybe / No and comment (write)
- `list_event_speakers` — accepted speakers and the plan's speaker limit (read)
- `decide_submission` — accept, waitlist, decline or undecided; sends nothing (write)
- `get_decision_emails` — the three emails, merge fields, who has not been told (read)
- `preview_decision_email` — one email exactly as a speaker gets it (read)
- `update_decision_email` — save the declined or waitlisted email (write)
- `send_decision_emails` — email declined or waitlisted speakers (sends; waits in Sessionboard)
