---
name: registration-pacing-check
description: "Check whether a Sessionboard event's registration is on pace: funnel, capacity, waitlist and a turnout estimate. Read-only."
---

# Registration pacing check

The person gets one short pacing brief for an event: where registrations stand, an estimate of where they will land, how that compares with the goal or last time, where the funnel leaks, capacity and waitlist pressure, and up to three next moves. On the day, it adds check-in progress. It works for any Sessionboard organization, full-platform or self-serve, with the same tools; parts the org's plan or event does not have are skipped and said. Plan limits and role permissions are enforced by Sessionboard, not by you. Nothing is changed or sent.

## When to use

Use this when someone wants to know whether an event's registrations are on pace — registrations so far, the estimate at the event date, pace against the goal, where the registration funnel leaks, what is selling out, how long the waitlist is, and on the day who has checked in — with a few suggested next moves. Read-only; sends nothing. Triggers on "are we on pace?", "how are registrations tracking?", "will we hit 600?", "how many will show up?", "where are people dropping off in checkout?", "what's selling out?", "how long is the waitlist?", "who's checked in so far?", "give me the door list".

## Before you start

- The person is connected to the Sessionboard connector, signed in with OAuth as themselves.
- Scopes: `read:registrations` (a preview scope, granted only when named) for the Registration reads; `read:marketing` for the estimate (`get_turnout`) and the in-person door list (`whos_coming`, `check_in_list`); `read:events` for Advocacy pacing.
- Sessionboard checks the event: Registration must be switched on for it (Early Access, per event); the estimate needs an org plan that includes Marketing; the door list is for in-person (field) events. The person must reach the event: an OAuth connection reaches events where their role has AI Access ("Can access AI tools").

## Guardrails (read first)

- **Read-only. Suggest, never act.** Every tool here reads. Offer next moves in words. Acting on one (an email, a campaign, ads, a price change) is a separate request that needs its own clear yes in this conversation, through tools that are not part of this skill.
- **Confirm before every write or send.** There are none here. Never infer a yes for a later write from this check.
- **Some actions wait for a person in Sessionboard.** No tool here answers `needs_approval`. If one ever returns "Waiting for your OK in Sessionboard: <url>", pass it on and stop.
- **Estimates are estimates.** Every number in `get_turnout`'s `prediction` is an estimate: say "about" and "estimate", give the `range` and `confidence`, and quote `prediction.how` when asked. With `insufficient_history` or `too_early` there is no number: say so and never make one up.
- **Label every number with where it came from** (registration summary, estimate, funnel, capacity, waitlist, Advocacy, door list).
- **Personal data is real and unmasked.** Ask before listing names or emails (for example, who has not checked in).
- **Money is in cents.** Divide by 100 and give the currency.
- **Words.** Say **attendee**, **waitlist**, **check-in**, **Advocacy** (people sharing the event). Never name internal engines or the in-product assistant.

## The workflow

### 1. Pick the event
1. `find_event { search }` (or `list_events {}`). **Pause:** if several match, ask which one.
2. Note whether it is a conference with Registration or an in-person field event. A field event's id also works for `whos_coming` and `check_in_list`.

### 2. Where registrations stand
1. `read_registration_summary { event_id }`. Take registrations by status (confirmed, pending approval, waitlisted, checked in; canceled is never counted as registered), registrations per day, per ticket type, revenue and invoices owed.
2. A 403 "not enabled for this event" means Registration is off: skip steps 2, 4, 5 and 6 and say so. Continue with the estimate.

### 3. The estimate and the goal
1. `get_turnout { event_id }`. Here `event_id` is a number. Without it, the next upcoming event is used: confirm that is the one.
2. Lead with `summary`. Then `prediction` (estimate, range, confidence), `pace.line` (ahead, on track, behind, reached, missed) and `last_edition`.
3. `goal.default: true` means nobody set a goal and it is last time's numbers: say "against last time's numbers".
4. Keep up to three `suggestions`; each `ask` is the request that would act on it. Do not run it.
5. A 403 that mentions Marketing means the org's plan does not include it. Leave the estimate out and say why. Do not compute your own.

### 4. Where the funnel leaks
- `read_registration_funnel { event_id }`. Per form: views → checkouts started → completed → registered, with conversion and abandonment rates. Name the weakest form, abandoned checkouts and their value, and abandonment over the last 7 and 30 days. Read `definitions` before explaining a count.

### 5. Capacity
- `read_registration_capacity { event_id }`. Name what is sold out or above 90% full, and shared pools with percent full.

### 6. Waitlist
- `read_registration_waitlist { event_id }`. Total waiting, the oldest wait, open and expired offers, and whether each form auto-promotes.

### 7. Optional: sharing pace against last year
- If the event uses Advocacy: `find_event { search }` for last year's edition, then `get_advocacy_pacing { event_id, compare_event_id }`. Give `to_date` and `change_vs_compare`.

### 8. On the day: check-in
- Conference with Registration: the checked-in count is in `read_registration_summary`. **Pause:** ask before listing people. For names: `find_registrations { action: "search", event_id, status: ["confirmed"] }` (confirmed, not yet checked in).
- In-person field event: `whos_coming { eventId }` for counts (registered, approved, waitlisted, checked in, plus-ones, seats left); `check_in_list { eventId }` for the door list A–Z. `eventId` is the number.

### 9. Write the brief

```
<Event> — pacing on <date>
Headline: <on pace / behind / ahead>, in one sentence (estimate)
Registered so far: N confirmed, N pending, N waitlisted (registration summary)
Estimate at the event date: about N (range A–B, confidence) (estimate)
Against the goal: <pace line> (estimate)
Funnel: weakest form, abandonment (funnel)
Capacity: sold out / nearly full (capacity)
Waitlist: N waiting, oldest N days (waitlist)
Next moves: up to 3, each one line, each "not done"
```

**Pause:** end by asking which next move, if any, they want to take on. Do not start it here.

## When something goes wrong

- 403 "… is not enabled for this event": Registration is off for the event. Skip those parts; do not retry.
- 403 "… needs the read:registrations scope": reconnect with the scope, or get AI Access on the event.
- 403 "This token cannot use Marketing …": no `read:marketing` scope, or the plan has no Marketing. Skip the estimate and door list.
- 403 "Reading Advocacy results needs the read:events scope": skip Advocacy pacing.
- 404 "Not found …": check the event id with `find_event`.
- `prediction.status` `insufficient_history`, `too_early` or `no_date`: no estimate. Say it in the person's terms.

## What this skill does not do

- Send reminders, launch campaigns or ads, change prices, capacity or the goal.
- Check anyone in or promote from the waitlist.
- Forecast without `get_turnout`: there is no other estimate, and you must not make one.
- Day-of check-in times per person for conferences (no check-in list tool for Registration).

## Tools used

- `find_event` — find the event and last year's edition (read)
- `list_events` — list events when none is named (read)
- `read_registration_summary` — registrations by status, day, ticket; revenue (read)
- `get_turnout` — the estimate, pace against the goal, suggestions (read)
- `read_registration_funnel` — conversion and abandonment per form (read)
- `read_registration_capacity` — sold out and nearly full (read)
- `read_registration_waitlist` — waitlist size and offers (read)
- `get_advocacy_pacing` — sharing activity against another edition (read)
- `find_registrations` — confirmed attendees not yet checked in (read)
- `whos_coming` — in-person event counts and guest list (read)
- `check_in_list` — in-person event door list (read)
