---
name: marketing-goals
description: Plan and pace a registration goal for a Sessionboard event across sharing, email and ads on your own account, with a spend cap.
---

# Marketing: goals

These tools run **Goals** for any Sessionboard organization whose plan includes Marketing: a Marketing workspace or a full-platform account, the same tools either way. They back the **Goals** page in Sessionboard Marketing. They need the `read:marketing` / `write:marketing` scopes (preview scopes, granted explicitly on the token). A 403 that says Goals are "part of Sessionboard Marketing" means the org's plan does not include them; tell the person to ask their Sessionboard contact. Do not suggest workarounds.

## When to use

Use this when someone wants to hit a number for an event (registrations, abstracts, members, seats) by a date, plan how to get there across speakers sharing, email and ads, run ads on their own Meta or Google account with a spend cap, build an ad audience from their people (past attendees who haven't registered, speakers, identified website visitors), see how a goal is pacing and which channels brought registrations, or see what topic audiences they could sell to sponsors. Triggers on "how's it doing?", "will we hit our number?", "how many will show up?", "600 registrations by March 14", "make a plan to fill the event", "run ads for the summit", "how is my goal doing", "are we on pace", "what drove registrations for this goal", "build an audience of past attendees", "export this audience to Meta", "sponsored reach".

## Guardrails (read first)

- **Nothing spends without `approve_ads`, and you call it only after the person says yes to the cap in this conversation.** Show the cap in dollars (cents ÷ 100) and the readiness checklist first. Send exactly the draft's `approval.approve_with` (`draft_version` and `approved: true`). Never call `approve_ads` because a plan, a goal approval or an earlier "go ahead" seemed to cover it. Each ad draft needs its own yes.
- **Approving a goal plan starts tracking only.** `manage_goal { action: "approve", approved: true }` sends no email and starts no ads. Say so when you ask.
- **Ask before** `manage_goal` (any action), `export_audience` and `approve_ads`.
- **Ads run on the customer's own account.** Sessionboard does not buy media for them. Ads run on Meta or Google. For LinkedIn, say that LinkedIn ads wait on LinkedIn's API approval, and offer Meta or Google.
- **Be honest about launch.** An approved ad draft waits at `launch.state: "waiting_for_account"` until the ad account connection ships, and nothing spends meanwhile. The audience can be exported now as a CSV to upload by hand. Never say the ads are live.
- **Do not promise** pixel retargeting, geofencing, managed display, or lookalike audiences. None of them are offered. "Website visitors" means people the site snippet identified by email, not cookie retargeting.
- **People stay private.** Audiences come back as counts only. Sponsored reach is aggregate only: sponsors get results, never names.
- **Numbers are a plan, not a forecast.** The split across channels is a starting point. An ads budget without a figure from the person is labelled as an assumption ($40 per registration). Say so.

## Jobs, and the tools for each, in order

### 1. "600 registrations by March 14": plan a goal
1. **One registration goal per event.** If the event already has one (see `list_goals`), `plan_goal` edits it: tell the person "<event> already has a goal of N; this changes it to M" and ask before calling.
2. `plan_goal { sentence, event_id? }`. Pass the person's words. Add `event_id` if you already know the event, else the sentence or the next event is used. If it returns `questions`, say them (one of them names an edit when `updated_existing` is true).
3. Show `goal.name`, `goal.current_value` (registrations so far) and each `plan.steps` entry: channel, target, what happens. Show the `weekly_target`.
4. If `approval.required`, ask: "Approve this plan? It starts tracking; it sends nothing and spends nothing." On yes: `manage_goal { goal_id, action: "approve", approved: true }`. A running goal that was edited needs no new approval.
5. Offer the next steps the plan lists. For ads, go to job 2. People sharing and email are campaigns: if this connection has Campaigns tools, use them with the step's `next.ask`. If it doesn't, tell the person to start them from **Campaigns** in Sessionboard Marketing (or by asking Ask there with the same words). Don't call a tool you don't have.

### 2. Run ads for the goal
1. Optional: `build_audience { sentence, goal_id, save: true }` if the person describes who to reach. Otherwise `launch_ads` builds "past attendees who have not registered".
2. `launch_ads { goal_id, platform: "meta" | "google", total_cap_cents?, daily_cap_cents?, audience_id? }`. This returns a **draft**.
3. Show `spend_cap`, dates, `audience.exportable`, the creatives (and which speakers still need to approve theirs), and each `readiness` item that is not `ok`, with its `fix`.
4. If `can_approve` is false, stop and say what is missing:
   - `card_on_file`: add a card in Billing. During the trial, ads stay off until a card is on file.
   - `creative_approved`: speakers approve their clips in their Creator console.
   - `audience_ready`: build a bigger audience.
5. If `can_approve` is true, ask: "Approve up to $X on your Meta account?" Only on a clear yes: `approve_ads { ad_id, draft_version, approved: true }`.
6. On 409, the draft changed. Read it again (`get_goal`), show the new version, and ask again.

### 3. "How is my goal doing?"
- `list_goals` for all goals (each has a one-line `pace`). Use `get_goal { goal_id }` for one.
- `get_goal` returns `view`, the same thing the Goals page shows. Lead with `view.pace.line` (an estimate: say "about"), then `view.next_move.text` (the one next move, quantified). Then each of `view.lanes` (Speakers and guests sharing, Email to past attendees, Your newsletter, Automatic emails, Ads on your own accounts, Your event page): its status, what it is planned to bring (`projected`) and what it has brought.
- Newsletter lane not started: offer `draft_newsletter_issue { event_id, promote: true, goal_id }` (a draft announcement; a person schedules it). Automatic emails off: say who each would reach and, on a yes, `update_journey { journey_id, enabled: true }` for each — it waits for a person's OK in Sessionboard. The welcome covers every event, so say that.
- Without `view` (an older server): lead with `pace.line`. Then give `current_value` / `target_value` and `needed_per_day`.
- Then give the channels: `channels.channels[]` with `label` and `conversions_credited`. These are the same numbers as Results, credited across touches. When `spend_note` is set, say that cost per registration shows once ads run.

### 3b. "How's it doing?" — an event's turnout
- `get_turnout { event_id? }` (default: the next upcoming event). Lead with `summary`.
- Every number in `prediction` is an **estimate**: say "about" and "estimate", give the `range` and the `confidence` (low, medium or high). When asked how it was worked out, quote `prediction.how`.
- `prediction.status` `insufficient_history` or `too_early` means there is no number. Say so in the person's terms ("not enough past webinars to estimate from yet"). Never make one up.
- The goal: `goal.default: true` means nobody set one and it is last time's numbers (`goal.source: "last_edition"`). Say "same as last time" and offer to change it.
- Then give `pace.registrations.line` and up to three `suggestions`. A suggestion's `ask` is the request that acts on it. Offer it; do not run sends from here.
- Cancelled registrations are never counted.
- To set or change the goal, ask first, then call `set_turnout_goal { event_id, registrations_goal?, attendance_goal? }`. Send `null` to clear one; a cleared goal goes back to last time's numbers.

### 4. Change a goal
- `manage_goal { goal_id, action: "update", target_value? | deadline? | ad_budget_cents? | name? }`.
- `manage_goal { goal_id, action: "pause" | "resume" | "finish" }`.
- Ask first each time.

### 5. Build or export an audience
- `build_audience { sentence | definition, goal_id?, save? }`. Report `counts.exportable` (what an ad platform can match), `counts.suppressed_total` (unsubscribed, opted out, or no consent) and any `notes`. Meta and Google need about 100 matched people.
- To upload by hand: ask first, then `export_audience { audience_id, platform }`. The person downloads the hashed CSV from the Goals page.

### 6. Sponsored reach
- `get_sponsored_reach { q?, event_id? }`: topic audiences by size, plus existing packages.
- Revenue share is not built, and selling packages is staff Early Access. Say so. Do not offer to sell a package.

## Examples

| Person says | You do | Expected result |
|---|---|---|
| "Get 600 registrations for Summit 2027 by March 14" | `plan_goal`, show the steps, ask, then `manage_goal approve` | A goal, active, with a plan across sharing, email and (if asked) ads |
| "Run $3k of Meta ads for it" | `launch_ads { goal_id, platform: "meta", total_cap_cents: 300000 }`, show the checklist | A draft; nothing spends |
| "Yes, approve the $3,000" | `approve_ads` with `approval.approve_with` | Approved; waiting for the ad account (say so) |
| "Are we on pace?" | `get_goal` | The pace line, the number needed per day, and the channels |
| "How's the Austin field lab doing?" | `get_turnout { event_id }` | The summary, the estimate with range and confidence, how it was estimated, 2–3 suggestions |
| "Make the goal 300" | Ask, then `set_turnout_goal { event_id, registrations_goal: 300 }` | The goal is saved; pace is shown against it |
| "Past attendees who haven't registered — how many?" | `build_audience { sentence, goal_id }` | A count, no names |
| "Run LinkedIn ads" | Explain that LinkedIn is waiting on API approval; offer Meta or Google | No call |

## Tools used

- `approve_ads` — Approve ad spend (write)
- `build_audience` — Build audience (write)
- `draft_newsletter_issue` — Draft a newsletter issue (write)
- `export_audience` — Export audience (write)
- `get_goal` — Get goal status (read)
- `get_sponsored_reach` — Sponsored reach (read)
- `get_turnout` — How an event is doing (read)
- `launch_ads` — Draft ads (no spend) (write)
- `list_goals` — List goals (read)
- `manage_goal` — Manage goal (write)
- `plan_goal` — Plan a goal (write)
- `set_turnout_goal` — Set an event's goal (write)
- `update_journey` — Update a journey (write)
