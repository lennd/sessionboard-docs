---
name: marketing-events-and-apps
description: Bring events and webinars into Sessionboard Marketing and connect, sync or disconnect the apps they run on.
---

# Marketing: events, webinars and apps

These tools run events, webinars and app connections for **any** Sessionboard organization: a Marketing workspace or a full-platform account, the same tools either way. They back the Marketing workspace's **Events and webinars** and **Apps** pages. They need the `read:marketing` / `write:marketing` scopes (preview scopes, granted explicitly on the token). If a call returns a 403 that names those scopes, tell the person their connection needs them.

## When to use

Use this when someone wants to bring an event or webinar into Sessionboard Marketing, set up a webinar series, connect or disconnect Zoom / Goldcast / ON24 / Cvent / Swoogo / RainFocus / Eventbrite / Bizzabo / HubSpot / Salesforce / iMIS / Nimble AMS / Canva, see which apps are connected, see what each event is doing (campaigns, clips, registrations), pull speakers, sessions and attendees from a registration platform, sync people and campaign outcomes with a CRM or AMS, or list Canva designs. Triggers on "import this event from its link", "create a webinar series", "bring in my Zoom series", "connect Cvent", "sync HubSpot", "what are my events doing", "which apps are connected", "show my Canva designs".

## Guardrails (read first)

- **Ask the person before** `connect_app`, `disconnect_app`, `import_event_from_url` (the real run), `import_webinar_series`, `import_from_app` and `sync_app`. Say what will happen, then call.
- **Writing to someone's CRM needs its own yes.** `sync_app` writes campaign outcomes to the app only with `write_back: true`. Never send it on the first call: sync People first, and when `outcome.outcomes` is `needs_ok`, say exactly what will be written (for HubSpot: `sb_*` properties on their contacts — sessions and events attended, topics, engagement) and call again with `write_back: true` only after the person says yes. A "sync HubSpot" request is not that yes.
- **Never switch an app's settings on.** `not_enabled` means a switch on the app's own page is off; give the person `settings_url` and let them decide.
- **Say what an app cannot do.** `list_apps` gives each app's `limits`, and `import_from_app` / `sync_app` give `reasons` per kind. Repeat them in plain words — for example, Eventbrite has no speakers or sessions, iMIS and Nimble AMS do not read members yet.
- **Never ask for, accept or type a password, API key or token.** `connect_app` takes only `app_id` and returns a `connect_url`. Give the person the link; they sign in or paste their key on the Sessionboard page.
- **Preview imports.** Call `import_event_from_url` with `dry_run: true` first and show the event, speakers and warnings. Run it for real only after the person agrees.
- **Every app is on every plan.** Don't mention upgrades.
- **Sending the agenda back to a registration platform is platform-only.** It is part of the Sessionboard platform, not Marketing. If asked, say so. `import_from_app` only pulls data in.
- **Nothing is published or sent.** No tool here publishes to Zoom, Goldcast or ON24, invites anyone, or emails anyone. New webinars are drafts until an admin publishes them. The only write to another app is `sync_app` with `write_back: true`.

## Jobs, and the tools for each, in order

### 1. Import an event from its link
1. `import_event_from_url { url, dry_run: true }`: show `event`, `speakers`, `warnings`.
2. Once the person agrees: `import_event_from_url { url }`, then share `created.admin_url`.
   - `already_imported: true` means the event already exists. Use the existing `created.event_id`. Don't create a duplicate.
   - No dates on the page: pass `timezone` if you know it, and tell the person to add the dates.

### 2. Create a webinar or a series
- One webinar: `create_webinar` (event configuration tools).
- A series of 2–26 episodes: `create_webinar_series { name, timezone, provider?, duration_minutes?, registration?, episodes: [{ name?, starts_at }] }`.
- Return each `admin_url`, and repeat the `note`: these are drafts, and nothing is created in the provider until the webinars are published.

### 3. Connect Zoom / Goldcast / ON24 and bring in a series
1. `list_webinar_sources`: is the provider `connected`, or does it have `needs_reauth`?
2. If it is not connected, ask the person, call `connect_app { app_id }`, and give them `connect_url`. Wait for them to say they're done.
3. `list_webinar_series { provider, scope? }`: show each series with its past and upcoming episodes, `has_recording` and `registrants`.
4. Ask which series or episodes to import, then call `import_webinar_series { provider, series_ids? , external_ids? }` (pass at least one).
   - Past episodes bring their recording and attendance. Upcoming ones bring registrants as they sign up. Episodes that were already imported are skipped.

### 4. List events with what each is doing
- `list_events_with_status { q?, limit? }`: use `doing` for the one-liner, and `counts` for the totals (upcoming, past, webinars).

### 5. Connect or disconnect apps, and see what is connected
- `list_apps` shows each app's `category` (webinar, registration, crm, ams, design), `connected`, `needs_reauth`, `brings_in`, `pulls`, `limits`, `actions` and `sends`.
- HubSpot and Canva connect by signing in; Salesforce, iMIS and Nimble AMS by keys the person pastes on the page. Either way `connect_app` returns the link.
- Connect: ask the person, call `connect_app`, and give them the link.
- Disconnect: ask the person, then call `disconnect_app`. Data that was already imported stays.

### 6. Bring in speakers, sessions and attendees from Cvent, Swoogo, RainFocus, Eventbrite or Bizzabo
1. `list_apps`: is the app connected? If not, follow job 5 to connect it.
2. `list_events_with_status`: find the Sessionboard `event_id` to import into.
3. `list_app_events { app_id }`: the person picks the remote event.
4. Ask, then call `import_from_app { app_id, event_id, remote_event_id, include? }`.
   - `queued` means the import is running.
   - `not_connected` means you should go back to connecting the app.
   - `needs_remote_event` means you should go back to step 3.
   - `outcome` says per kind what was queued and what the platform cannot give, with `reasons`. Today Cvent, Swoogo and Bizzabo bring speakers, sessions and attendees; RainFocus and Eventbrite bring none of them (say why). Tell the person both halves.
   - Sessions arrive as Sessions (Cvent with their times; Swoogo and Bizzabo without times). Speakers arrive as event contacts matched by email; speakers without an email are skipped. Speakers are not put on their sessions yet. Running it again adds only what is new and keeps edits made in Sessionboard.
   - `managed_on_platform` (for the whole import, or for one kind in `outcome`) means the event still sends that kind to the platform on every sync, so it is not pulled back. The person can turn that push off on the event's Apps page.

### 7. Sync people and campaign outcomes with HubSpot, Salesforce, iMIS or Nimble AMS
1. `list_apps`: is it connected, and what does its `sync` say per kind?
2. Ask, then call `sync_app { app_id }` (no `write_back`).
   - `people: queued`: value for people already in Attendees is coming in (HubSpot lifecycle, company, open deals; Salesforce pipeline or membership). Contacts are not copied in as new people.
   - `outcomes: needs_ok`: explain what would be written, ask, and only on a yes call `sync_app { app_id, write_back: true }`.
   - `not_enabled`: give the person `settings_url`; the switch is on the app's page.
   - `not_available`: repeat the reason (Salesforce has no outcome write-back yet; iMIS writes CE credits and Nimble AMS writes awards payments, neither reads members).

### 8. Canva designs
- `list_app_designs { app_id: "canva" }` lists designs to use as templates. If `connected` is false, give the person `connect_url`. Brand Kit colors, fonts and logos are not read from Canva yet.

## Examples

| Person says | You do | Expected result |
| --- | --- | --- |
| "Import https://example.org/summit-2027" | `import_event_from_url` with `dry_run: true`, show the preview, ask, then run it for real | "Created Audience Summit 2027 (Mar 4–5, Austin) with 4 speakers: /event/6901" |
| "Set up a 4-part Zoom series, Tuesdays at noon ET starting Dec 1" | `create_webinar_series` with `provider: "zoom"` and 4 episodes | 4 draft webinars and their admin links, plus "Nothing is created in Zoom until you publish." |
| "Bring in our Growth Series from Zoom" | `list_webinar_sources`, then `connect_app` if needed, then `list_webinar_series`, ask, then `import_webinar_series` | "Imported 5 episodes: 3 past with recordings, 2 upcoming collecting registrants." |
| "Pull speakers and sessions from Cvent into the Summit, and push the agenda back" | `list_app_events` for cvent, ask, then `import_from_app` with `include: ["speakers","sessions"]` | Import queued. "Sending the agenda back to Cvent is part of the Sessionboard platform, not Marketing." |
| "Sync HubSpot" | Ask, `sync_app { app_id: "hubspot" }`; on `outcomes: needs_ok`, explain the sb_* properties and ask again | "People are coming in from HubSpot. Want me to write session attendance and topics back to their HubSpot contacts too?" |
| "Bring speakers in from Eventbrite" | `list_apps` (Eventbrite `limits`) | "Eventbrite's API has no speakers, so there are none to bring in." |

## AI assistants: what is connected, what it may do, what it did

`list_ai_connections`, `list_ai_activity` and `disconnect_ai_connection` back **Apps › AI assistants**: the AI assistants (Claude, ChatGPT, Cursor, others) connected to the organization over MCP or the API.

- **What is connected:** `list_ai_connections`. For each connection, say its `name`, `assistant`, who connected it (`connected_by.name`), `last_used_at`, and what it may do. Use `may` with `reads` / `drafts` ("reads events and sessions, drafts event pages") and read out any `notes`. `send`, `post` and `spend` are always `needs_person`: an assistant can prepare an email, a post or a purchase, but a person in Sessionboard finishes it. Repeat `policy_note` when someone asks whether an assistant can act on its own.
- **What it did:** `list_ai_activity { assistant?, limit? }` returns rows newest first. Each row has `what`, the `event`, `who` it ran as and `when`. `scope: "mine"` means the person sees only what assistants did as them. Admins who manage app connections or API tokens see the whole organization.
- **Disconnect:** this is destructive, so **ask first**. Name the assistant and who connected it, then call `disconnect_ai_connection { connection_id }` with the `id` from the list. It revokes the OAuth tokens or deletes the API token, and the assistant stops working at once. What it already did stays. If the connection is the one you are using, say so before you call: you will lose access. Only `can_disconnect: true` rows can be disconnected by this person. For other rows, tell them who can.
- Nothing here shows a key or token, and nothing creates a connection. A person connects an assistant from the assistant's own settings, or from Settings → API Tokens.

| Person says | You do | Expected result |
| --- | --- | --- |
| "Which AI tools are connected to our account?" | `list_ai_connections` | "Claude (Ada, last used today): reads events and sessions, drafts event pages. Cursor key (Bo): read-only. Neither can send, post or spend without a person." |
| "What has ChatGPT changed this week?" | `list_ai_activity { assistant: "chatgpt" }` | "3 changes as Ada: rewrote the Summit page hero, drafted the reminder email…" |
| "Cut off Bo's Cursor key" | Ask, then `disconnect_ai_connection { connection_id: "token:…" }` | "Disconnected. It can no longer reach Sessionboard; its activity stays." |

## Tools used

- `connect_app` — Connect app (write)
- `create_webinar` — Create webinar (write)
- `create_webinar_series` — Create webinar series (write)
- `disconnect_ai_connection` — Disconnect AI connection (write)
- `disconnect_app` — Disconnect app (write)
- `import_event_from_url` — Import event from URL (write)
- `import_from_app` — Import from app (write)
- `import_webinar_series` — Import webinar series (write)
- `list_ai_activity` — List AI activity (read)
- `list_ai_connections` — List AI connections (read)
- `list_app_designs` — List app designs (read)
- `list_app_events` — List app events (read)
- `list_apps` — List apps (read)
- `list_events_with_status` — List events with status (read)
- `list_webinar_series` — List webinar series (read)
- `list_webinar_sources` — List webinar sources (read)
- `sync_app` — Sync app (write)
