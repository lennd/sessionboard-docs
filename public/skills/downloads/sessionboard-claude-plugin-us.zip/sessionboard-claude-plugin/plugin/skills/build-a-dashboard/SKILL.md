---
name: build-a-dashboard
description: "Build or change a Sessionboard event or organization dashboard, its widgets and saved reports, after showing you each change."
---

# Build a dashboard

The person gets a working dashboard (or saved report) in Sessionboard: the widgets they asked for, each backed by a query that was run and checked first, placed on the grid, created only after they approve the plan. It works for event dashboards and organization dashboards, on any Sessionboard organization, full-platform or self-serve, with the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants a dashboard or saved report built or changed in Sessionboard — for one event or across the organization — with charts, numbers and tables on the questions they care about, each query tested before anything is saved. Triggers on "build me a dashboard for Summit 2027", "add a chart of sessions by track", "make an org dashboard of all our events", "save this as a report", "add a KPI tile for confirmed speakers", "move that chart to the top", "rename the dashboard", "delete the old dashboard", "what widget types are there?".

## Before you start

- The person is connected to the Sessionboard connector, signed in with OAuth as themselves.
- Scopes: `read:insights` (schema, suggestions, test queries), `read:dashboards`, `read:reports`, and `write:events` to create, change, delete or run dashboards, widgets and saved reports.
- Sessionboard checks that the organization's "Enable AI features" setting is on and that the person's role has AI Access ("Can access AI tools"). Organization dashboards, organization widgets and saved reports belong to the whole organization: a connection that reaches only particular events is refused them and can build event dashboards only.

## Guardrails (read first)

- **Confirm before every write.** Before `manage_event_dashboard`, `manage_org_dashboard`, `manage_event_widget`, `manage_org_widget`, `manage_event_report` or `manage_org_report` with `create`, `create_from_nl`, `update` or `delete`, show exactly what will change (dashboard name, each widget's name, type and position, report names and their queries in words) and get a clear yes in this conversation. Never infer a yes from an earlier answer or from the plan.
- **Deletes are permanent here.** Name the dashboard, widget or report and say it cannot be restored from this connection. Ask separately for each delete.
- **Test every query before saving it.** A widget or report is only created from a query you ran with `execute_sbql` and showed sample rows from.
- **Some actions wait for a person in Sessionboard.** These tools save directly. If one ever returns "Waiting for your OK in Sessionboard: <url>", pass it on and stop. Do not call it again.
- **Results are not masked.** Widgets show names and emails as stored, to everyone who can open the dashboard. Say so when a table lists people.
- **Words.** A **widget** is a dashboard tile; a **saved report** is a saved query. Committee scoring is **Review** (Reviewer, Round); attendee feedback is **Surveys** — never "evaluation", "evaluator" or "judge" in names or what you tell the person. Do not show raw query text unless asked. Never name the in-product assistant or internal engines.

## The workflow

### 1. Event or organization?
1. Event dashboard: `find_event { search }` (or `list_events {}`) for `event_id`. Organization dashboard: no event id; queries can span events.
2. See what exists: `read_event_dashboards { action: "list", event_id }` or `read_org_dashboards { action: "list" }`. Saved reports: `list_event_reports { event_id }` or `list_org_reports {}` (both show the organization's saved reports).
3. **Pause:** if a dashboard with a similar name exists, ask: change it, or make a new one?

### 2. Learn the shapes
1. `get_widget_schema {}`: widget types (table, number, bar_chart, pie_chart, donut, line_chart, stacked_bar, area_chart, stacked_area, radar, treemap, funnel, scatter, radial_bar, progress, list, heatmap), the config shape for each, and the 6-column grid (each widget's `position` is `{ x, y, w, h }`).
2. `get_schema { event_id? }`: entities and fields queries may use. `get_suggestions { event_id? }` for ready-made questions. Run a suggestion before you use it: one can return no rows and no error (a by-track grouping did on a test event); if so, write the query yourself from `get_schema`. Alias related fields (`track.name AS track_name`) so the column matches the widget's chart config.

### 3. Draft and test each widget
1. For each question the person named, pick a type: one number → `number`; a share → `pie_chart` or `donut`; per category → `bar_chart`; over time → `line_chart`; people or rows → `table`.
2. Write the query from schema fields, or draft it with `query_data { prompt, event_id? }` and take its `query`.
3. Run it: `execute_sbql { query, event_id?, limit: 10 }`. Check the columns match the config keys (`x_axis`, `y_axis`, `category`, `value`, `label`). Fix and rerun on an error.
4. An existing saved report can back a widget by `queryId` instead of `queryText`; run it first with `manage_event_report { action: "run", event_id, query_id }` (changes nothing).

### 4. Show the plan
**Pause:** show a table — widget name, type, what it shows in words, sample numbers, position (x, y, w, h on 6 columns) — plus the dashboard name and description. Ask: "Create this dashboard?" Wait for a yes.

### 5. Create
- Event: `manage_event_dashboard { action: "create", event_id, name, description?, layout: { columns: 6 }, widgets? }`, where each widget is `{ name, widgetType, queryText? | queryId?, config?, position? }`.
- Organization: `manage_org_dashboard { action: "create", name, description?, layout?, widgets? }`.
- Or create the dashboard empty and add widgets one by one: `manage_event_widget { action: "create", event_id, dashboard_id, name, widgetType, queryText?, queryId?, config?, position? }` (org: `manage_org_widget { action: "create", dashboard_id, … }`).
- Report back the dashboard id and each widget created. Then `read_event_dashboards { action: "get", event_id, dashboard_id }` (or `read_org_dashboards`) to confirm.

### 6. Save a report
1. Test the query with `execute_sbql` or `query_data` first and show sample rows.
2. **Pause:** show the report name, what it answers, and tags. Ask for a yes.
3. `manage_event_report { action: "create", event_id, name, queryText, description?, tags? }` or `manage_org_report { action: "create", name, queryText, description?, tags? }`.
4. Prefer `create` with a tested query over `manage_event_report { action: "create_from_nl", event_id, name, prompt }`, which saves whatever query it generates without a preview. If you use it, describe the returned `generatedSbql` in words and offer to fix it.

### 7. Change or remove
- Move, resize, retitle or re-query one widget: `manage_event_widget { action: "update", event_id, widget_id, name?, widgetType?, queryText?, queryId?, config?, position? }` (org: `manage_org_widget`). Test a new query first.
- Rename or re-describe a dashboard: `manage_event_dashboard { action: "update", event_id, dashboard_id, name?, description?, layout? }` (org: `manage_org_dashboard`). Change widgets with the widget tool, not by resending `widgets`.
- Report: `manage_event_report { action: "update", event_id, query_id, name?, queryText?, description?, tags? }`.
- Delete: `manage_event_widget { action: "delete", event_id, widget_id }`, `manage_event_dashboard { action: "delete", event_id, dashboard_id }`, `manage_event_report { action: "delete", event_id, query_id }` (org equivalents). **Pause** before each: name it, say it is permanent, ask.

## When something goes wrong

- **500 from `query_data`**: the plain-language translation failed. Write the SbQL yourself from `get_schema` and test it with `execute_sbql`; do not retry the same prompt.

- "dashboard_id is required for create." / "widget_id is required for update." / "query_id is required for run.": read the list again and pass the id.
- "prompt is required for create_from_nl." or "AI did not return a SbQL query. Try rephrasing.": rephrase, or write the query and use `create`.
- "Error: API 401 …": the organization's AI features are off or the connection is not allowed AI tools. An org admin turns on "Enable AI features".
- "Error: API 403 …": a missing scope (`write:events` for any save), `EVENT_NOT_ALLOWED`, or an event-only connection asking for an organization dashboard or saved report.
- "Error: API 400 …" on a query: fix the fields against `get_schema`.
- "Error: API 404 …": the dashboard, widget or report no longer exists; list again.
- "Error: API 429 …": rate limited; wait before more calls.

## What this skill does not do

- Share a dashboard, schedule it by email or export it as a file.
- Set who can see a dashboard; Sessionboard's own permissions decide.
- Restore a deleted dashboard, widget or report.
- Undo a change; update it back instead.

## Tools used

- `find_event` — find the event (read)
- `list_events` — list events (read)
- `read_event_dashboards` — list or get event dashboards (read)
- `read_org_dashboards` — list or get organization dashboards (read)
- `list_event_reports` — saved reports, from an event (read)
- `list_org_reports` — saved reports for the organization (read)
- `get_widget_schema` — widget types, configs, grid (read)
- `get_schema` — fields queries may use (read)
- `get_suggestions` — suggested queries (read)
- `query_data` — draft a query from plain words and run it (read)
- `execute_sbql` — test a query and see sample rows (read)
- `manage_event_dashboard` — create, update, delete an event dashboard (write)
- `manage_org_dashboard` — create, update, delete an organization dashboard (write)
- `manage_event_widget` — create, update, delete an event widget (write)
- `manage_org_widget` — create, update, delete an organization widget (write)
- `manage_event_report` — run (changes nothing), create, update, delete a saved report (write)
- `manage_org_report` — run, create, update, delete an organization saved report (write)
