---
name: send-a-sponsor-their-results
description: Prepare a sponsor's results from Sessionboard event data and share a read-only report or link on your OK.
---

# Send a sponsor their results

The person gets a sponsor's report from what Sessionboard already tracks, and a safe way to hand it over: a read-only link to the counts, and, when they choose, a private link to the people who opted in to hear from sponsors. It works for any organization with Sessionboard Marketing, a Marketing workspace or a full-platform account, with the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

**Sponsors get aggregates, never attendee names.** The sponsor report is counts only. The only people a sponsor can ever see are those who subscribed to hear from sponsors, through `share_with_sponsor`, and only after a person approves it in Sessionboard.

## When to use

Use this when someone wants to show a sponsor what their sponsorship delivered — pick the sponsor, read their counts-only report (session views and watches, attendance, questions, clips, posts, link clicks, credited registrations, app placement views and taps, booth leads), send them a read-only link to it, give them a private link to the people who opted in to hear from sponsors, see who opened the links, and stop a link working. Triggers on "how did Acme's sponsorship do?", "send Acme their report", "make a sponsor report for Globex", "share the results with our sponsor", "give Acme the opted-in list", "which sponsor links were opened?", "revoke Acme's link", "kill that sponsor link".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Scopes: `read:marketing` to read reports and links; `write:marketing` to make or revoke a link. Adding a sponsor to an event also needs `write:sponsors`.
- Sessionboard checks that the person belongs to the organization. Reading results and making a results link need an org **Contacts** permission (read, update or manage). Making or revoking a private sponsor link needs an org admin. A connection limited to particular events cannot read an org-wide report.

## Guardrails (read first)

- **Confirm before every write or share.** Before `share_results`, `share_with_sponsor`, `revoke_sponsor_share` or `manage_sponsor`, say exactly what happens: which sponsor, which report or audience, how many people (a count), how long the link works. Get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Some actions wait for a person in Sessionboard.** `share_results` and `share_with_sponsor` from an assistant can answer `needs_approval` with a URL. Tell the person "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again.
- **Pass `asked`** (the person's request in their own words, one sentence) on `share_results`, `share_with_sponsor` and `revoke_sponsor_share`, so the approval in Sessionboard shows what they asked for.
- **Never put a name in front of a sponsor.** Read the report with `scope: "sponsor"` only. Never paste rows from an event or org report (people, posts by attendees) into anything meant for the sponsor.
- **A link can be opened by anyone who has it.** Say so before making one. A results link works 30 days unless `days` says otherwise.
- **Never invent a number.** Every figure you state is in the report. Credited registrations are shared across touches over 90 days (40% first, 40% last, 20% between), so they can be fractions; say "credited", never "brought".
- Words: **sponsor** (never "partner"), **Advocacy** for sharing, **Surveys** for attendee feedback. Never name the in-product assistant or internal engines.

## The workflow

1. **Pick the sponsor.** `list_report_sponsors { q? }` (up to 50; sponsors on the organization's events and company records). If several match, show the names and ask which. It returns names only: for "our top sponsor", ask the person which one, or read two or three reports (step 2) and compare them before choosing.
   - Not listed because they are not on the event yet: ask, then `manage_sponsor { action: "create", event_id, name, level?, website?, contact_email?, description? }`. Sessions must still be tagged with the sponsor in Sessionboard before the report has numbers.
2. **Read the report.** `get_results { scope: "sponsor", sponsor_id, event_id?, from?, to? }`. `event_id` narrows to one event; `from` / `to` are `YYYY-MM-DD`. Lead with the answer, then the counts: their sessions' views, watches and attendance, questions, clips, posts, link clicks and credited registrations, app placement views and taps, and booth leads. If a list says `truncated`, say the totals still cover everything.
3. **Explain it if asked.** `explain_results { scope: "sponsor", sponsor_id, event_id? }`: use its `headline`, `worked`, `did_not` and `next_moves`. Anything you add must come from its `facts` or the report.
4. **Send the report.**
   **Before you offer a link:** if every count in the report is zero, do not share it. Say so: usually no sessions, clips or placements are tagged with this sponsor yet. Offer to look at what to tag instead.

   **Pause:** "Make a read-only link to Acme's sponsor report (counts only, no attendee names) that anyone with it can open for 30 days?"
   On yes: `share_results { scope: "sponsor", sponsor_id, event_id?, from?, to?, title?, days?, asked }`. Give the `url` (it is returned once) and `expires_at`. If it answers `needs_approval`, say "Waiting for your OK in Sessionboard: <url>" and stop.
5. **Give the sponsor the opted-in list (optional, only when asked).** First count who would be on it, without saving: `build_audience { definition: { roles, eventId?, attended? } }` (roles: speaker, attendee, contact, visitor). Only people who opted in to hear from sponsors appear on the sponsor's list; counts under 10 show as "Fewer than 10" on the sponsor's page.
   **Pause:** "Create a private link for Acme to the attendees of Summit 2027 who opted in to hear from sponsors, for 30 days? They see counts, a profile of the audience and their report totals, and can download only the opted-in people."
   On yes: `share_with_sponsor { sponsor_account_id, definition: { roles?, event_id?, attended? }, audience_name?, days?, asked }`. `sponsor_account_id` is the sponsor's id from `list_report_sponsors`; use `sponsor_name` only for a sponsor with no record. A saved audience can go in as `audience_id` instead of `definition`. It answers `needs_approval`: say "Waiting for your OK in Sessionboard: <url>" and stop.
6. **See what was opened.** `list_sponsor_shares {}`: each link's sponsor, audience, created, expires, active, views and downloads.
7. **Stop a link.**
   **Pause:** "Stop Acme's link now? Views and downloads so far stay on record."
   `revoke_sponsor_share { share_id, asked }`. A results link from `share_results` is revoked by the person in Results in Sessionboard.

## When something goes wrong

- **`needs_approval`**: not an error. "Waiting for your OK in Sessionboard: <url>"; do not call again.
- **403 "This token cannot use Marketing"**: the connection lacks `read:marketing` / `write:marketing`, or the person is not an org admin (for sponsor links). Reports need a connection not limited to particular events.
- **409**: the link or report changed; read it again before retrying.
- **400 / 422 "Invalid request"**: say the message; usually a missing `sponsor_id` with `scope: "sponsor"`, or neither a sponsor nor an audience on `share_with_sponsor`.
- **404 "Not found"**: check the sponsor with `list_report_sponsors` and the link with `list_sponsor_shares`.

## What this skill does not do

- No sponsor report for exhibitors, and no PDF or CSV export of the report from here (the Results page in Sessionboard has Export CSV).
- It cannot list or revoke results links; a person revokes those in Results.
- It cannot email the link to the sponsor; the person sends it.
- It cannot tag sessions with a sponsor, or change an existing event sponsor's details; do those in Sessionboard.
- No revenue share or sponsored-reach packages.

## Tools used

- `list_report_sponsors` — pick the sponsor (read)
- `manage_sponsor` — add a missing sponsor to an event (write)
- `get_results` — the sponsor's counts-only report with `scope: "sponsor"` (read)
- `explain_results` — what worked, in plain words (read)
- `share_results` — a read-only link to the report; may wait for approval (write)
- `build_audience` — count who a sponsor link would cover, counts only; used here without `save`, so nothing is stored (write tool, no change)
- `share_with_sponsor` — a private link to the opted-in people; waits for approval (sends)
- `list_sponsor_shares` — sponsor links with views and downloads (read)
- `revoke_sponsor_share` — stop a sponsor link (write)
