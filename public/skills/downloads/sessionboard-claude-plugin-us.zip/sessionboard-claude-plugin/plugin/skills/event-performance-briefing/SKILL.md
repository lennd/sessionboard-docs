---
name: event-performance-briefing
description: Write a performance briefing for a Sessionboard event or session, from its overview, queries, saved reports, dashboards and sharing.
---

# Event performance briefing

The person gets a structured brief on one event, or one session in it: the headline, the program, registrations, saved reports and dashboards, Advocacy (people sharing the event), what was said in sessions, watch-outs and next moves. Every number is labelled with the tool, report or query it came from, so it can be checked. It works for any Sessionboard organization, full-platform or self-serve, with the same tools; parts an event does not use are skipped and said. Plan limits and role permissions are enforced by Sessionboard, not by you. Nothing is changed.

## When to use

Use this when someone wants a briefing on how an event, or one session, is doing — program size and mix, registrations, what saved reports and dashboards say, how speakers and sponsors are sharing it, and what speakers said — written as a structured brief where every number says where it came from. Triggers on "brief me on Summit 2027", "how is the event doing?", "prep me for the board meeting", "give me a one-pager on the keynote", "what do our dashboards say?", "run our saved reports", "how many sessions per track?", "which speakers haven't shared yet?", "what did speakers say about AI?".

## Before you start

- The person is connected to the Sessionboard connector, signed in with OAuth as themselves.
- Scopes: `read:insights` (queries, schema, suggestions, overview), `read:reports` and `read:dashboards`, `read:events` (Advocacy), `read:sessions`, `read:ask` (event Q&A, granted explicitly), and optionally `read:registrations` (a preview scope). Running a saved report goes through `manage_event_report`, which Sessionboard files under `write:events` even though it changes nothing.
- Sessionboard checks that the organization's "Enable AI features" setting is on and that the person's role has AI Access ("Can access AI tools"). Saved reports, suggestions and cross-event queries belong to the whole organization: a connection that reaches only particular events is refused them.

## Guardrails (read first)

- **Read and run only.** Do not create, update or delete reports or dashboards here. If the person wants the brief saved as a report or dashboard, that is the build-a-dashboard workflow, with its own confirmation.
- **Confirm before every write or send.** None happen here. Running a saved report changes nothing, but some clients show a permission prompt for it; say so.
- **Some actions wait for a person in Sessionboard.** No tool here answers `needs_approval`. If one ever returns "Waiting for your OK in Sessionboard: <url>", pass it on and stop.
- **Label every number** with its source in brackets: (event overview), (registration summary), (report "<name>"), (dashboard "<name>" → widget "<name>"), (query), (Advocacy). Estimates are labelled "estimate". Never round a source's number into a different claim.
- **Exact numbers come from queries, not from event Q&A.** `ask_event` is for synthesis and quotes; it is slow. Counts and lists come from `execute_sbql` / `query_data` / reports.
- **Results are not masked.** Names and emails come back as stored. Never say otherwise. Leave attendee names out of a brief meant for sharing unless the person asks.
- **Words.** Committee scoring is **Review** (Reviewer, Round); attendee feedback is **Surveys** — never "evaluation", "evaluator" or "judge". Say **Advocacy**, **attendee**, **widget** (a dashboard tile). Do not show raw query text unless asked. Never name the in-product assistant or internal engines.

## The workflow

### 1. Scope the brief
1. `find_event { search }` or `list_events {}`. Event ids come back as numbers; the tools in this skill take `event_id` as a **string** ("6", not 6). For a session: `list_sessions { event_id, page?, limit? }`, then `get_session { event_id, session_id }`.
2. **Pause:** confirm the event (or session), who the brief is for and anything it must answer ("are we ahead of last year?"). One question, then go.

### 2. The program
- `get_event_overview { event_id }`: total and accepted sessions, speakers, sessions by track. Counts arrive as rows of strings (`[{ total: "0" }]`); read them as numbers. A part that is missing or null is "not available", not zero.

### 3. Registrations, if the event uses them
- `read_registration_summary { event_id }`. A 403 "not enabled for this event" means it does not: say "Registration not used" and move on.

### 4. Saved reports
1. `list_event_reports { event_id }`. These are the organization's saved reports; the list can include reports about other events.
2. Pick the ones that fit the brief by name and description. **Pause** if more than five fit: list them and ask which to run.
3. `manage_event_report { action: "run", event_id, query_id }` for each. Quote rows as (report "<name>").

### 5. Dashboards
1. `read_event_dashboards { action: "list", event_id }`, then `read_event_dashboards { action: "get", event_id, dashboard_id }` for the relevant one.
2. A widget carries `queryText` or a `queryId`. For its current numbers run the text with `execute_sbql { query, event_id }`, or the saved report with `manage_event_report { action: "run", event_id, query_id }`. Label (dashboard "<name>" → widget "<name>").

### 6. Fill the gaps with queries
1. `get_schema { event_id }` before writing any query. `get_suggestions { event_id }` for ready-made questions.
2. Exact numbers: `execute_sbql { query, event_id, limit? }`. Name a related field's column yourself (`track.name AS track_name`); otherwise it comes back as a bare `name`. A query that returns no rows and no error answered nothing: rewrite it from `get_schema` rather than report zero. The pattern is `FIND <Entity> WHERE … GROUP BY … COMPUTE COUNT(*) AS n`; use only fields `get_schema` lists.
3. Plain-language questions: `query_data { prompt, event_id }`. Keep the returned `query` and `explanation` in your notes as the source.
4. For one session, filter by the session's id or title using fields from the schema.

### 7. Advocacy
- `get_advocacy_results { event_id }`: `dashboard.kpis` and `funnel` match the Advocacy screen; `by_role`, `by_network`, `top_assets`. Read `notes` first.
- Who has not shared: `list_advocacy_advocates { event_id, status: "not_shared", role? }`. Attendees are counts only; never try to name them.
- Against last year: `get_advocacy_pacing { event_id, compare_event_id }`.
- Advocacy registrations are those on a tracked link; other attribution can differ. Say so if both appear.

### 8. What was said
- `ask_event { event_id, question, conversation_id?, lang? }` for themes and quotes ("what did speakers say about pricing?"). Keep its `[n]` sources and cite them in the brief. Pass `conversation_id` back for a follow-up.

### 9. Write the brief

```
<Event or session> — briefing, <date>
Headline: 2–3 sentences
Program: sessions, accepted, speakers, by track (event overview)
Registrations: by status, revenue (registration summary)
What the reports say: one line per report (report "<name>")
Dashboards: the 3–5 numbers that matter (dashboard → widget)
Advocacy: activated, shares, clicks, registrations; top network (Advocacy)
What people said: 2–4 themes with citations (event Q&A [n])
Watch-outs: what is behind or missing
Next moves: up to 3, not done
Sources: each number → tool, report or query
```

**Pause:** offer to go deeper on any section, or to save a query as a report or dashboard (a separate, confirmed step).


## When sources disagree

The overview, the session list, registration and Advocacy are counted differently (the overview counts accepted, scheduled work; the session list includes pending submissions; Advocacy counts invitations). When two numbers for the same thing differ, give both with their sources and one line on why they can differ. Never pick one silently, and never average them.

## When something goes wrong

- "Error: API 401 …" on queries, schema or suggestions: the organization's AI features are off, or the connection is not allowed AI tools. An org admin turns on "Enable AI features".
- "Error: API 403 …" with `EVENT_NOT_ALLOWED`: the connection cannot reach that event. On saved reports, suggestions or cross-event queries: the connection reaches only particular events; these need org-wide AI Access. A missing scope names the scope.
- A query error ("Error: API 400 …"): fix the field or syntax against `get_schema` and retry once.
- `ask_event`: "Ask is turned off for this event" (an organizer turns event Q&A on in the event's settings), "AI is disabled for this organization", "Ask quota exceeded" (do not retry), "rate limited. Retry after N seconds", "timed out after 90 seconds" (narrow the question).
- Advocacy: "This connection is limited to particular events …", "request limit … Wait a few minutes".
- "Error: API 429 …": rate limited; wait before more queries.

## What this skill does not do

- Survey results and Review scores beyond what queries over the schema return; there is no dedicated tool for either here.
- Export the brief to a file or send it; the person copies it.
- Save reports or dashboards (build-a-dashboard does, with a confirmation).
- Compare many events in one call; run the steps per event.

## Tools used

- `find_event` — find the event (read)
- `list_events` — list events (read)
- `list_sessions` — find a session in the event (read)
- `get_session` — one session's details (read)
- `get_event_overview` — sessions, speakers, sessions by track (read)
- `read_registration_summary` — registrations and revenue (read)
- `list_event_reports` — saved reports (read)
- `manage_event_report` — `run` only: run a saved report (changes nothing; filed under write:events)
- `read_event_dashboards` — dashboards and their widgets (read)
- `get_schema` — fields available to queries (read)
- `get_suggestions` — suggested queries (read)
- `execute_sbql` — exact counts and lists (read)
- `query_data` — a plain-language question answered by a query (read)
- `get_advocacy_results` — Advocacy totals, funnel, networks (read)
- `list_advocacy_advocates` — who has and has not shared (read)
- `get_advocacy_pacing` — Advocacy against another edition (read)
- `ask_event` — themes and quotes from the program and transcripts, with sources (read)
