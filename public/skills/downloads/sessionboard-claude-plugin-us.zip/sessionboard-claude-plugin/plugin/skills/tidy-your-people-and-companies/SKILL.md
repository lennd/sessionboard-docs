---
name: tidy-your-people-and-companies
description: "Find, fix, tag and link people and companies in Sessionboard CRM, and import a list with a preview first."
---

# Keep your people and companies tidy

The person gets a clean People list in Sessionboard CRM: the right names and titles, the right tags, people linked to the companies they work at, new lists brought in without duplicates, and an export when they need one. It works the same for a self-serve CRM workspace and a full-platform organization. Plan limits and role permissions are enforced by Sessionboard, not by you.

Two records, never one: a **person** (People, one per email) and a **Contact** (the record behind a speaker or a company's person, which the pipeline and contracts use) stay separate and are linked by email. Never tell the person they are the same record or that one was merged into the other. In the app, companies are shown as **Groups** (companies, sponsors, exhibitors, chapters); the tools say `company`.

## When to use

Use this when someone wants to clean up the people and companies (Groups) in Sessionboard CRM — find someone, fix a name or title, tag people as speakers, members, customers or prospects, tag companies as sponsors or exhibitors, link people to the company they work at, bring in a spreadsheet or a connected CRM's contacts with a preview first, export a list, or delete records. Triggers on "clean up my contacts", "find everyone at Acme", "tag these 40 people as speakers", "mark Acme as a sponsor", "link Dana to Acme", "import this spreadsheet", "bring in our HubSpot contacts", "who is a member?", "export our speakers", "fix Dana's title", "delete these duplicates".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Scopes: `read:crm` to read, discover, preview and export; `write:crm` to change anything. They are preview scopes, so they must be named explicitly when the connector or key is set up. Adding a sponsor or exhibitor to an event's own list also needs `write:sponsors` / `write:exhibitors`.
- Sessionboard checks the person's org **Contacts** permissions, the same as the Contacts pages: READ to look, UPDATE to add, edit, tag, link or import, DELETE to delete, EXPORT to export. Bringing in an event platform's attendees needs an org admin. A role limited to some portfolios is refused here; that person uses Contacts in Sessionboard.

## Guardrails (read first)

- **Confirm before every write.** Before any tool that creates, changes or deletes, show exactly what will change (names, emails, tags, counts, the company) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Updates replace lists.** On `manage_crm_person` update, `roles` and `company_ids` replace the whole list; on `manage_crm_company` update, `tags` replaces. To add or remove one tag on many records use `tag_crm_people` / `tag_crm_companies`, which leave other tags alone. Read the record first and show before and after.
- **Tags have side effects; say them.** Tagging someone `speaker` makes them a Contact. `member` sets their membership. `customer` or `prospect` records a lifecycle change. Linking a person to a company makes them a Contact of that company. A `sponsor` or `exhibitor` tag on a company also shows it on the platform's sponsor or exhibitor pages.
- **Deletes need `confirmed: true`,** passed only after the person said yes to the named list. Stored people are free (the plan counts active contacts only), so never suggest deleting to save money. Deleting a person keeps their Contact, contracts and pipeline entries; deleted companies go to the platform's Trash and their people stay.
- **Only standard fields.** Name, title, email, company, website and tags. Custom fields are part of the Sessionboard platform (an upgrade); say so instead of guessing a field.
- **Never ask for app keys.** Connecting a CRM, AMS or event platform is done by the person in Sessionboard CRM → Connections.
- Nothing here emails anyone. Words: say **prospect** (never "lead"), **sponsor** (never "partner"), **Groups** for companies in the app. Never name the in-product assistant or internal engines.

## The workflow

1. **Get the lay of the land.** `get_crm_home {}`: counts per tag, active contacts used against the plan's limit, setup steps, the newest people.
2. **Find people.** `find_crm_people { q?, roles?, all_roles?, company_id?, member?, lifecycle?, in_pipeline?, attended?, event_id?, active?, linked?, warm?, sort?, page?, per_page? }`. `roles` matches any of the tags; add `all_roles: true` for all of them. Use `facets` to give counts. One person: `get_crm_person { key }` (CRM view, signals timeline, linked Contact).
   - `q` matches name, email and the linked company, so `q: "acme.com"` finds people by their email domain. `company_id` finds only people already linked to that company: before anyone is linked, "everyone at Acme" is found by the email domain, not by the company.
   - Keys can change: once a person becomes a Contact (a `speaker` tag, a company link) their key goes from `p_…` to `c_…`. Old keys still resolve in `get_crm_person`, but read the people again before a follow-up write and use the keys you get back.
   - **Nothing found:** when the named company or its people are not here, say so plainly. Offer to look by email domain (`find_crm_people { q: "<domain>" }`), to create the company (step 5), and, if people turn up by domain, to create the company and link them (step 7). Do not create a company unless the person says yes.
3. **Find companies.** `find_crm_companies { q?, tags?, sort?, page?, per_page? }`, or `find_crm_companies { company_id }` for one company with its people, contracts and pipeline.
4. **Fix a person.** `manage_crm_person { action: "update", key, first_name?, last_name?, title?, roles?, company_ids? }`. Add someone new: `manage_crm_person { action: "create", email, first_name?, last_name?, title?, company?, company_id?, roles? }`. An email already here is not added twice.
   **Pause:** show the current record and the change, field by field; ask "Save this?"
5. **Fix a company.** `manage_crm_company { action: "update", company_id, name?, website?, tags? }`, or `action: "create"` with `name`. A name already here is not added twice.
   **Pause:** show the current company (or the new one) and the change; ask "Save this?"
6. **Tag in bulk.** `tag_crm_people { keys, add?, remove? }` (up to 500; `contacts_created` says how many became Contacts through `speaker`). `tag_crm_companies { company_ids, add?, remove? }` (sponsor, exhibitor; up to 500).
   **Pause:** "Tag 40 people as speaker? That also makes them Contacts." Name the count and a few names.
7. **Link people to a company.** `link_crm_company_people { action: "link", company_id, keys? }`, or someone new with `email, first_name?, last_name?, title?`. Remove one: `link_crm_company_people { action: "unlink", company_id, keys: [one key] }`; the person stays.
   **Pause:** "Link these 5 people to Acme? Each becomes a Contact of Acme." Name the people and the company.
   Show before and after from the person's `companies` list (a link shows there; the `company` text field can stay empty). Read the people again afterwards: their keys may now start with `c_`.
8. **The organization's own lists.** `list_crm_tags {}` shows them with counts; `manage_crm_tag { action: "create" | "rename" | "delete", tag_id?, name? }`. Deleting a list keeps every Contact on it.
9. **Import a spreadsheet.** Read the file the person shared and turn each row into `{ email, first_name?, last_name?, company?, title?, roles? }` (or `{ name, website?, tags? }` with `target: "companies"`).
   - `import_crm_people { action: "preview", target?, rows }` writes nothing. Report `total`, `new`, `existing`, `duplicates_in_file` and each `invalid` line with its reason.
   - **Pause:** "40 new, 12 already here, 3 invalid (lines 7, 19, 33: no email). Import the 40 new? Fill in details for the 12 already here?" Only pass `update_existing: true` if they say yes to that part.
   - `import_crm_people { action: "import", target?, rows, update_existing? }` with only the rows they agreed to. If the answer has `stopped_at_row`, say which rows went in and which did not.
10. **Bring people in from a connected app.** `list_crm_sources {}` shows what is connected. `discover_crm_people { app_id, kinds?, default_type? }` reads the app and writes nothing (event platforms: `action: "list_events"` first, then `remote_event_id`). Tell the person what was found ("40 subject-matter experts, 12 new"), then preview and import as in step 9 with `source: app_id`.
    An event platform's attendees: tell the person how many `discover_crm_people` found and ask, then `start_crm_attendee_sync { app_id, remote_event_id, event_id? }`. They land in People, never as Contacts. Nothing is written to the event platform.
11. **Export.** `export_crm_contacts { q?, type?, tag_id?, source?, event_id?, active? }` returns the Contacts as CSV, up to 1,000 rows. If `truncated`, say the full list exports from the Contacts page in Sessionboard CRM (up to 25,000).
12. **Delete.** Name every record first. **Pause:** "Delete these 3 people? Their Contacts, contracts and pipeline entries stay." Then `delete_crm_people { keys, confirmed: true }` or `delete_crm_companies { company_ids, confirmed: true }`.
13. **Put a company on an event's sponsor or exhibitor list.** Ask first, then `manage_sponsor { action: "create", event_id, name, level?, website?, contact_email?, description? }` or `manage_exhibitor { action: "create", event_id, name, booth_number?, website?, contact_email?, description? }`.

## When something goes wrong

- **403 "This connection cannot use Sessionboard CRM"**: the connector lacks `read:crm` / `write:crm`, or the person's role lacks the Contacts permission. If scopes were added after connecting, disconnect and reconnect. A portfolio-limited role is told to use Contacts in Sessionboard.
- **Read-only** (`trial_ended`, `plan_ended`, `paused`, `payment_due`, `read_only`): everything can still be read; a person with admin rights chooses a plan or updates billing in CRM → Plan and billing. Nothing was changed.
- **`exists`**: the email or company name is already here; nothing was added. Offer an update instead.
- **`platform_customer`**: the organization's contacts live in the platform's CRM, not the self-serve workspace.
- **404**: check keys with `find_crm_people`, company ids with `find_crm_companies`, tag ids with `list_crm_tags`, app ids with `list_crm_sources`.
- **`sync_disabled`** on keeping a source in sync: not turned on for this organization; people can still be brought in once.

## What this skill does not do

- It cannot add a Contact to one of the organization's own lists (tags from `list_crm_tags`); that is done in Sessionboard.
- No People or Groups export (only the Contacts export, 1,000 rows); no custom fields; no notes on a person.
- It cannot connect an app or change an existing event sponsor's or exhibitor's details (an update needs a version these tools do not read); do those in Sessionboard.
- It does not merge two people into one.

## Tools used

- `get_crm_home` — counts, plan meter, setup steps (read)
- `find_crm_people` — search and filter People (read)
- `get_crm_person` — one person with the linked Contact (read)
- `find_crm_companies` — search companies (Groups), or one with its people (read)
- `manage_crm_person` — add or change a person (write)
- `manage_crm_company` — add or change a company (write)
- `tag_crm_people` — add or remove person tags in bulk (write)
- `tag_crm_companies` — add or remove sponsor / exhibitor tags in bulk (write)
- `link_crm_company_people` — link or unlink people and a company (write)
- `list_crm_tags` — the organization's lists with counts (read)
- `manage_crm_tag` — create, rename or delete a list (write)
- `import_crm_people` — preview (read), then import (write)
- `list_crm_sources` — connected CRMs, AMSs and event platforms (read)
- `discover_crm_people` — who a connected app holds, writes nothing (read)
- `start_crm_attendee_sync` — bring an event platform's attendees into People (write)
- `export_crm_contacts` — Contacts as CSV (read)
- `delete_crm_people` — delete people, `confirmed: true` (write)
- `delete_crm_companies` — delete companies to Trash, `confirmed: true` (write)
- `manage_sponsor` — add a sponsor to an event (write)
- `manage_exhibitor` — add an exhibitor to an event (write)
