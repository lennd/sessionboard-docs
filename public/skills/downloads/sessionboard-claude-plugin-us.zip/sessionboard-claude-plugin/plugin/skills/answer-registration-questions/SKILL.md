---
name: answer-registration-questions
description: Answer who registered, what they ordered and paid, waitlist and capacity, from Sessionboard registration data. Read-only.
---

# Answer registration questions

The person gets a direct, sourced answer about one event's registrations: a person, an order, a payment, the waitlist, capacity or membership. It works for any Sessionboard organization whose event has Registration switched on, full-platform or self-serve, with the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you. Every tool here reads; nothing is changed, sent or refunded.

## When to use

Use this when someone wants a straight answer about an event's registrations — whether a person is registered, what they bought and paid, who still owes money, failed card payments, who is on the waitlist, how many seats are left, member versus non-member pricing, fee groups, donation funds, workshop rules or the badge print queue. Read-only. Triggers on "is Jane Smith registered?", "did ada@example.com pay?", "look up order 1-1001", "which invoices are still owed?", "any failed payments?", "who's on the waitlist?", "how many seats are left?", "what's sold out?", "is this email a member?", "how much has the scholarship fund raised?", "how many badges failed to print?".

## Before you start

- The person is connected to the Sessionboard connector, signed in with OAuth as themselves. The connection acts as them.
- Scope: `read:registrations`. It is a preview scope: it is granted only when the connection asks for it by name. Without it every tool answers 403.
- Registration is an Early Access feature switched on per event. If it is off, the tools say "… is not enabled for this event".
- Sessionboard checks that the person can reach the event: an OAuth connection reaches the events where their role has AI Access ("Can access AI tools"), on the organization role or on that event.

## Guardrails (read first)

- **Read-only.** No tool here creates, changes, cancels, refunds, checks in or emails anyone. If the person asks for one of those, say it is done in Sessionboard (see "What this skill does not do").
- **Confirm before every write or send.** There are none in this skill. If the person moves on to work that writes, that work needs its own clear yes in this conversation.
- **Some actions wait for a person in Sessionboard.** No tool here answers `needs_approval`. If any tool ever returns "Waiting for your OK in Sessionboard: <url>", pass that on and stop. Do not call it again.
- **Personal data is real and unmasked.** Results include names, emails, answers and payment details as stored. Never say they are masked or anonymized. Show only what the question needs; ask before listing many people's emails.
- **Payments never include card numbers or tokens.** A card brand and last four appear only when stored. Never claim more.
- **Money is in cents.** Divide by 100 and give the currency.
- **Words.** Say **attendee**, not registrant or delegate. Say **waitlist**, **order**, **invoice**, **ticket type**, **attendee type**. Never name internal engines or the in-product assistant.

## The workflow

### 1. Find the event
1. `find_event { search }` with words from the event name. Use `list_events {}` if they name none.
2. **Pause:** if more than one event matches, list them (name, dates) and ask which one.

### 2. "Is Jane registered?"
1. `find_registrations { action: "search", event_id, q }` with the name, email or company fragment. Use `email` instead of `q` for an exact address.
2. Zero results: say no registration matches those words on this event. Offer to try the email or another spelling. Do not conclude they are absent from other events.
3. Several matches: **Pause:** show name, company, status and ticket type for each, and ask which one.
4. One match: `find_registrations { action: "get", event_id, registration_id }` for answers, sessions picked, membership, badge and approval state.
5. Lead with the status in plain words: confirmed, pending approval, waitlisted, checked in, canceled, transferred, declined, no show, or incomplete (started but not finished). A canceled registration is not "registered"; say so.

### 3. Orders and money owed
- One person's order: take `order_id` from the registration, then `read_registration_orders { action: "get", event_id, order_id }`.
- By receipt number or buyer: `read_registration_orders { action: "list", event_id, number?, email? }`.
- Still owed: `read_registration_orders { action: "list", event_id, status: ["awaiting_invoice", "partially_paid"] }`. Give count, total balance and the oldest.
- Report lines, discounts, tax, total, paid and balance. Mention the invoice when there is one.

### 4. Payments
- One order: `read_registration_payments { action: "list", event_id, order_id }`.
- Failed card attempts: `read_registration_payments { action: "list", event_id, status: ["failed"] }`. Give the failure reason for each.
- Refunds: `type: ["refund"]`. Each refund names the charge it refunds.
- One record: `read_registration_payments { action: "get", event_id, payment_id }`.

### 5. Waitlist
1. `read_registration_waitlist { event_id }` for totals, the oldest wait, offers (open, expired, taken) and each form's waitlist settings.
2. For names: `find_registrations { action: "search", event_id, status: ["waitlisted"] }`.

### 6. Seats and sold out
- `read_registration_capacity { event_id, include_archived? }`. Name each ticket type, add-on or workshop that is sold out or nearly full, and shared capacity pools with percent full.

### 7. Members
- One email: `read_registration_members { action: "lookup", event_id, email }` → member, lapsed or none, the status value that decided it, and the attendee type (price) that applies.
- Recorded at checkout: `read_registration_members { action: "list", event_id, membership: ["lapsed"] }`.
- `membership_enabled: false` means the event does not use member pricing. Say so.

### 8. Setup questions
- `read_registration_setup { event_id, section }` with `fee_groups` (and their promo codes), `donation_funds` (raised and pledged per fund), `workshop_rules`, or `badge_print_jobs` (add `status: "failed"` for failed prints).

### 9. Totals
- For "how many" questions start with `read_registration_summary { event_id }` before listing people.

## Paging

Lists return up to 50 per page with `pagination` and a `hint`. Pass `page` for more. **Pause** before pulling more than three pages: say how many there are and ask whether they want all of them or a count.

## When something goes wrong

- 403 "… is not enabled for this event": Registration is off for that event. An organizer asks Sessionboard to enable it. Do not retry.
- 403 "Forbidden … needs the read:registrations scope": the connection lacks the scope or cannot reach this event. The person reconnects with the scope, or asks an admin for AI Access on the event.
- 404 "Not found …": check `event_id` with `find_event` and the id you passed.
- 400 "Invalid request: …": fix the parameter it names.
- "registration_id is required for get." (or `order_id`, `payment_id`, `email`): pass the id.

## What this skill does not do

- Register, edit, cancel, transfer or approve a registration.
- Check someone in at the door, or list check-ins one by one (counts are in the summary; `checked_in` is a status filter).
- Refund, take a payment, issue or resend an invoice or confirmation.
- Promote someone from the waitlist or send a waitlist offer.
- Change capacity, prices, fee groups or promo codes.

## Tools used

- `find_event` — find the event by name (read)
- `list_events` — list the organization's events (read)
- `find_registrations` — look up attendees and one registration (read)
- `read_registration_orders` — orders, balances, invoices (read)
- `read_registration_payments` — payment and refund records, failed attempts (read)
- `read_registration_waitlist` — waitlist counts, offers, settings (read)
- `read_registration_capacity` — ticket types sold and left, capacity pools (read)
- `read_registration_members` — membership lookup and recorded membership (read)
- `read_registration_setup` — fee groups, donation funds, workshop rules, badge print queue (read)
- `read_registration_summary` — totals by status, day, ticket, form, revenue (read)
