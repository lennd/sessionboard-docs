---
name: push-the-agenda-to-your-event-app
description: "Send a Sessionboard event's agenda to its connected event app: preview what changes, link, push on your OK, check history."
---

# Push the agenda to your event app

The person gets their accepted sessions, speakers, tracks and rooms in their event app, with a preview of exactly what goes before it goes and a history of every push. It works for any Sessionboard organization: a self-serve Sessions workspace and a full-platform account use the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to send an event's accepted sessions, speakers, tracks and rooms one way into their registration or event app (Swoogo today), choose which of the app's events it goes into, see what a push would send, push it, or check past pushes and errors. Triggers on "push the agenda to Swoogo", "send our sessions to Swoogo", "sync speakers to our event app", "which Swoogo event is this linked to?", "link it to the 2027 Swoogo event", "what would the push send?", "did the last push work?", "why was this session skipped?", "push history".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Scopes: `read:sessions` to read connections, previews and history; `write:sessions` to link and push. A connection limited to particular events is refused.
- Any organization member who can use the event reads; linking and pushing need an organization admin.
- Event ids are numbers from `get_sessions_home` (or `find_event` on a full-platform account). The app id is `swoogo`, the one app available today.
- **Connecting the app is a person's job.** They paste the app's keys on the event's Agenda page (Connections) in Sessionboard. Never ask for keys or passwords.
- Plan: Sessions Starter has no push (Growth adds one app); Growth has one app; more apps and two-way sync are the platform.

## Guardrails (read first)

- **Confirm before every write or push.** Before `link_event_connection { action: "link" }` or `push_event_agenda`, show exactly what will happen (the app's event name and id; per kind the counts, sample rows and skips) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Pushing waits for a person in Sessionboard.** `push_event_agenda` writes into the organizer's own app, so it answers `needs_approval` with a URL: say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again for the same event.
- **Always preview first** with `preview_event_push`.
- **One way only.** Only accepted sessions and their speakers go. A session that is no longer accepted is removed in the app on the next push. Nothing comes back from the app, and attendee data is never read: say so if asked.
- Linking to a different app event leaves what was already pushed in the old one.
- Words: "agenda", "session", "speaker", "push". Never name the in-product assistant or internal engines.

## The workflow

### 1. Check the connection
`list_event_connections { event_id }`: each app, connected or not, health, the app event it is linked to, the plan's lock, and the last push (sent, unchanged, skipped, errors with reasons).
- Not connected: tell the person to open the event's Agenda page → Connections in Sessionboard and paste the app's keys there. Stop until they have.
- Locked by the plan: say what the plan allows (see Before you start). Do not look for another way.

### 2. Link the app's event
1. `link_event_connection { event_id, app_id: "swoogo", action: "list" }`: the app's events and the one linked now.
2. **Pause:** show the event you will link (name, dates, id) and, if one is linked already, that what was pushed there stays. On yes:
   `link_event_connection { event_id, app_id: "swoogo", action: "link", remote_event_id }`.

### 3. Preview
`preview_event_push { event_id, app_id: "swoogo" }`: per kind (sessions, speakers, tracks, rooms) the count, sample rows in the app's own field names, and what is skipped and why. It reads Sessionboard only and works before connecting. Before the event is linked to an app event, every row comes back skipped with "Missing event_id" (`code: "remote_event"`): that is expected. Say the rows are ready and that linking (step 2) is what's missing, not that the sessions are wrong.
**Pause:** show the counts, a few sample rows, and every skip with its reason. Offer to fix skips first (for example a session with no time: the `build-the-agenda` skill; a speaker with no email: `get-speakers-ready`). Ask "Push this to Swoogo?"

### 4. Push
On yes: `push_event_agenda { event_id, app_id: "swoogo", asked }` (pass the person's words in `asked`). It answers `needs_approval`: say "Waiting for your OK in Sessionboard: <url>" and stop. After a person approves, only what changed is sent. If a push is already running, the answer says so: wait and read the history.

### 5. Check the result
`get_push_history { event_id, app_id: "swoogo" }`: every push, newest first (up to 100): when, who, result, and sent / unchanged / skipped / errors per kind with reasons. Lead with the latest result and any errors in plain words, then what to fix before pushing again.

## When something goes wrong

- "Pushing the agenda to another app is part of Sessions Growth." (`plan_limit`): the Starter plan has no push. Nothing changed. A person with admin rights chooses Growth in Sessions → Plan and billing.
- 403 "Two-way integrations is not part of this Sessions plan" (`enterprise_only`): a second app on Growth. It is the platform.
- `trial_ended` / `plan_ended`: read-only. History and previews can still be read.
- 403 "Forbidden … read:sessions …": missing scope or not an organization admin. Reconnect if scopes were added later.
- 404: check the event id with `get_sessions_home`. 400 "remote_event_id is required to link": list the app's events first.
- Errors inside a push (in the history) come with the app's reason: say it as written and what in Sessionboard would fix it.

## What this skill does not do

- Cannot connect or disconnect the app, or take its keys (a person does it on the Agenda page).
- The push supports Swoogo. If the person names Cvent or Bizzabo, say the push works with Swoogo only.
- No two-way sync, no pulling sessions or attendees back, no scheduled automatic pushes.
- Pushes only accepted sessions and their speakers; no sponsors, submissions or custom fields.

## Tools used

- `get_sessions_home` — Sessions events (read)
- `find_event` — find a full-platform event by name (read)
- `list_event_connections` — apps, health, linked event, plan lock, last push (read)
- `link_event_connection` — list the app's events, or link one (`list` reads; `link` writes)
- `preview_event_push` — what one push would send, in the app's fields (read)
- `push_event_agenda` — push accepted sessions, speakers, tracks and rooms (writes to the app; waits in Sessionboard)
- `get_push_history` — every push with counts, skips and errors (read)
