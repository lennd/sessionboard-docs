---
name: turn-sessions-into-courses
description: Turn Sessionboard event sessions and recordings into Learning courses with quizzes, drafted for your review and published on your OK.
---

# Turn sessions into courses

The person gets draft courses made from their own sessions and recordings, reviewed with them, and published to learners once they approve in Sessionboard. Sessionboard Learning is an LMS; courses, certifications and credits are capabilities in it. It works the same for a self-serve Learning workspace and a full-platform organization with the Learning module. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to turn event sessions, recordings or webinars into Learning courses - put a whole meeting on demand, make a course from one or more videos with lessons, checkpoints and a quiz, edit the draft, reuse questions from their question bank or import them from another LMS, bring last year's meeting in from their registration platform, and publish once they approve. Triggers on "put the annual meeting on demand", "make courses from our conference sessions", "turn this webinar into a course", "add a quiz", "make it a certification", "edit lesson 2", "add 5 questions from our bank", "import our Moodle questions", "import last year's Cvent meeting and make courses", "publish the course".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Reads need `read:learning`; drafting and publishing need `write:learning`.
- Sessionboard checks that the organization has the Learning module and that the person has the Lessons permissions: `ORG.LESSONS.READ` to read, `ORG.LESSONS.CREATE` to draft, `ORG.LESSONS.UPDATE` to change and publish.

## Guardrails (read first)

- **Confirm before every write or send.** Before any draft, edit, import, question-bank change or publish, show exactly what will change (meeting, sessions and counts, course and lesson titles, questions, who gets assigned and messaged) and get a clear yes in this conversation. Never infer a yes from an earlier answer or a plan. Reads and previews need no confirmation.
- **Some actions wait for a person in Sessionboard.** Publishing (`publish_event_on_demand` step `publish`, `apply_course_draft`) answers `needs_approval` with a URL. Say "Waiting for your OK in Sessionboard: <url>" and stop. Do not call it again.
- **You never set credit.** Credit on a course is set by a person in Sessionboard Learning; no tool here sets or grants it. Do not promise credit amounts.
- **Faculty disclosures gate publishing.** A session whose faculty has no disclosure on file is held at publish. Name those sessions from the preview.
- **Attendance is never copied** into a course. Claims made in the room stay claims.
- A registration platform never sends recordings. On path D (a meeting imported from a registration platform), sessions without a recording become courses that wait for one. On path A only recorded sessions are drafted: a session without a recording is left out (`would_wait_for_recording` stays 0). Say which applies.
- Never ask for API keys. A platform that is not connected comes back with `connect_url`: give the person the link.
- Words: Learning, course, lesson, certification, credit, learner. Never "Lessons & Credits". Never name the in-product assistant.

## The workflow

Pick the path that matches what the person has.

### A. A meeting already in Sessionboard → on demand
1. `read_learning_workspace { view: "on_demand" }` lists meetings whose sessions have recordings. Pick one. If the meeting the person names is not in the list, find it with `find_event { search }` and run step 2 on it to say why (no recordings yet, or the event has not happened), then offer the meetings that are listed.
2. `publish_event_on_demand { event_id, step: "preview" }`: per session, the recording, faculty (and who has no disclosure), credit, attendance and course state. Read-only.
3. `publish_event_on_demand { event_id, step: "draft", dry_run: true }` returns counts only. Take the names from the step 2 preview: sessions with no recording, sessions with `disclosures_missing` > 0 (held at publish) and sessions that already have a course (`course` not null).
   **Pause:** show the count, those named sessions, and any session that is not teaching content (a networking lunch, a break, a reception): suggest leaving those out. Ask "Draft these as courses? Nothing is published."
   On yes: `publish_event_on_demand { event_id, step: "draft", session_ids? }`, with `session_ids` (from the preview) when the person leaves sessions out. Up to 60 per call; call again while `remaining` > 0. All go into one "<meeting> on demand" bundle.
4. `read_learning_workspace { view: "courses" }` to show the drafts: each course's `status` (draft or published), plus the `drafts[]` list with each draft's `status` (for example `ready`) and `progress`.
   **Pause:** "Publish these <n> courses to learners?"
   On yes: `publish_event_on_demand { event_id, step: "publish", lesson_ids?, prompt? }`. Leave out `lesson_ids` to publish every draft from the meeting; to publish only some (for example drafts that were held for disclosure and now have one), pass their course ids: the `id` of each course in `view: "courses"`, or `course.id` in the preview. It answers `needs_approval`: give the URL and stop.

### B. Videos or webinars → a course
1. `list_learning_media { kind?, q?, limit? }`. Use items with `has_transcript` and `can_make_course`.
2. **Pause:** show the videos in course order, the title, audience, whether to add a certification (and how many months it is valid), question types, checkpoints per lesson (default 2) and quiz questions (default 4). Ask for a yes.
   `draft_course_from_media { media_item_ids, title?, audience?, certification?, validity_months?, question_types?, checkpoints_per_lesson?, quiz_questions?, max_lessons_per_video? }`. It writes no lessons and notifies no one.
3. `read_course_drafts { action: "get", draft_id, wait_seconds: 50 }` until `status` is `ready` (one to a few minutes). Show each lesson, its questions and every `warnings` entry (questions dropped because the clip does not answer them).
4. Edits: send the whole bundle back with your changes and `base_updated_at` = the draft's `updated_at`: `update_course_draft { draft_id, bundle, base_updated_at, title? }`. Anything left out is dropped. Confirm the change first.
5. **Pause:** "Publish <course> to learners?" If they want it assigned, say who (the whole team or named teammates), the due date, and that each assignee gets a Slack DM or email.
   On yes: `apply_course_draft { draft_id, assign?, slack_channel_id?, allow_pending_media? }`. It waits for a person's OK in Sessionboard: give the URL and stop. Do not use `allow_pending_media` unless the person agrees to publish while clips are still being cut.

### C. A course built page by page
- New empty course: `draft_course_from_media { title, summary? }` returns a starter outline. Add recordings to an existing course: `draft_course_from_media { course_id, media_item_ids }`.
- Read it: `read_course_drafts { action: "get", draft_id: <course id> }` (modules, pages with `rev`, blocks, `problems`). Preview a page as a learner: add `view: "learner", page_id`.
- Edit it: `update_course_draft { draft_id: <course id>, operations }` with ops such as `add_module`, `add_page`, `set_blocks`, `set_quiz_settings`, `write_questions`. Pass the page's `rev` as `base_rev` on page edits. Not safe to repeat: after an error, read again before retrying.
- A SCORM, xAPI or cmi5 package the person uploaded: `list_course_packages { q? }`, then a `package` block.
- Publish with `apply_course_draft { draft_id: <course id> }` after a yes, as in B5. Assign afterwards with `assign_course` (see the keep-learners-on-track skill).

### D. Last year's meeting from a registration platform
1. `import_meeting_for_learning { step: "preview" }` lists platforms with what honestly comes across and whether each is `connected`. Then `{ step: "preview", app_id }` for its events and `suggested`; then `{ step: "preview", app_id, remote_event_id }` for what the import would do.
2. **Pause:** "Import <meeting> from <platform>? It creates or updates a Sessionboard event with its sessions, speakers, tracks and check-ins."
   On yes: `import_meeting_for_learning { step: "import", app_id, remote_event_id, wait_seconds: 50 }`.
3. **Pause:** "Make draft courses from its sessions?" On yes: `import_meeting_for_learning { step: "draft", event_id, job_id }`. Then publish as in A4 or let the person publish in Sessionboard Learning.

### Question bank
- Read: `read_question_bank { tags?, match?, q?, archived?, offset? }`.
- Add or change one question (after a yes): `manage_question_bank { action, item_id?, question?, tags? }`.
- Import from another LMS (GIFT, Aiken or CSV): `import_questions { text, format?, filename?, tags? }` first with `commit` left false. Show the summary and every row with errors.
  **Pause:** ask to add the ready rows; name rows with errors and get an OK before `skip_invalid`. Then `import_questions { text, commit: true, skip_rows?, skip_invalid? }`.
- Use the bank in a quiz: a `bank_draw` block (`{ tags, match, count }`) on a quiz page via `update_course_draft` operations.

## When something goes wrong

- **403 "Forbidden … needs the read:learning / write:learning scopes … the organization's Learning feature, and a user with the Lessons permission"**: say which is likely missing; the person reconnects or asks an admin.
- **"still being cut" / "being applied" / "not ready"**: wait and check again with `read_course_drafts`.
- **409** "The draft changed since you read it": `read_course_drafts { action: "get" }` and redo the edit on the latest version.
- **422 "Not ready to publish"** with pages listed: a question has no right answer or a page is empty. Fix with `update_course_draft`, then ask again.
- **`not_connected`** with `connect_url` from the import: give the link; the person connects the platform.
- **"That file is too large"** from `import_questions`: split it into parts under about 450 KB.
- **404**: check ids with `list_learning_media` or `read_course_drafts { action: "list" }`.

## What this skill does not do

- Set or change credit on a course. A person does that in Sessionboard Learning.
- Accept, edit or reject each generated question in the review queue. A person reviews drafts in Sessionboard Learning.
- Upload a video or a SCORM package. A person uploads them in Sessionboard.
- Collect a missing faculty disclosure.
- Transcribe a recording that has no transcript.

## Tools used

- `read_learning_workspace` — meetings with recordings, courses with their status, and drafts (read)
- `find_event` — find a meeting by name when it is not in the on-demand list (read)
- `publish_event_on_demand` — preview, draft, then publish a meeting on demand; publish waits for a person's OK (read / write)
- `list_learning_media` — videos and clips a course can be made from (read)
- `draft_course_from_media` — start a course draft from videos, an empty course, or add recordings (write)
- `read_course_drafts` — read a draft or a course's builder draft; preview a page as a learner (read)
- `update_course_draft` — save edits to a draft or a course (write)
- `apply_course_draft` — publish (and optionally assign); waits for a person's OK (write / sends)
- `assign_course` — assign a published course afterwards; messages each assignee (sends)
- `list_course_packages` — uploaded SCORM, xAPI and cmi5 packages (read)
- `import_meeting_for_learning` — preview, import a meeting from a registration platform, draft courses (read / write)
- `read_question_bank` — the organization's reusable questions (read)
- `manage_question_bank` — add, edit, archive or restore a bank question (write)
- `import_questions` — preview, then import questions from GIFT, Aiken or CSV (write)
