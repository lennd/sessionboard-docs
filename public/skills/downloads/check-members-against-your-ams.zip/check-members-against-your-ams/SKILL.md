---
name: check-members-against-your-ams
description: Check Sessionboard people against your AMS: the field mapping, a member's snapshot, and a previewed write-back run on your OK.
---

# Check your members against your AMS

The person learns how their members engage across events, webinars, learning and awards, sees whether Sessionboard reads the right fields from their AMS, and can write engagement back into it once they have seen exactly what would go. It works for any organization whose AMS (Fonteva through their Salesforce, Nimble AMS, or Protech on Microsoft Dynamics 365) is connected to Sessionboard CRM, self-serve or full platform. Plan limits and role permissions are enforced by Sessionboard, not by you.

Members live in People (tagged Member); a member who is also a speaker or sponsor contact has a separate, linked Contact record. They are two records, never one.

## When to use

Use this when someone wants to check their members against their AMS (Fonteva, Nimble AMS or Protech) in Sessionboard CRM — see which AMS fields Sessionboard reads and which are missing, get a member engagement snapshot (engaged, never engaged, lapsed, renewals at risk, speaker prospects among members, warm non-members), preview what Sessionboard would write back to the AMS, and run that write-back once they agree. Triggers on "how engaged are our members?", "which members never come to anything?", "renewals at risk", "is our Fonteva mapping right?", "what fields are missing?", "what would you write back to Nimble?", "push engagement to our AMS", "run the write-back", "members vs non-members at our events".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Scopes: `read:crm` for the mapping, snapshot and preview; `write:crm` to run write-back. They are preview scopes, so they must be named explicitly when the connector or key is set up.
- Sessionboard checks the person's org **Contacts** READ permission for every read here. Running write-back needs an org admin. A role limited to some portfolios is refused; that person uses Contacts in Sessionboard.
- The AMS must already be connected. Fonteva, Nimble AMS and Protech are connected with Sessionboard's help for now. Check with `list_crm_sources {}`; never ask for AMS keys.

## Guardrails (read first)

- **Every read is read-only toward the AMS and toward Sessionboard.** The mapping, the snapshot and the preview change nothing. The preview's dry run is recorded in Sessionboard's run log and sends nothing.
- **Confirm before the write-back.** Always show `preview_ams_writeback` first: which objects are on, and the creates, updates, unchanged and errors. Then ask "Write these to <AMS> now?" and pass `confirmed: true` only after a clear yes in this conversation. Never infer a yes from an earlier answer or a plan.
- **Write-back only touches Sessionboard's own objects** in the AMS (an engagement object and an activity object), only for the objects a person switched on, and only rows that changed since the last write. It never edits the customer's own member records. Say this when you ask.
- **A person does the switching.** Turning write-back on or off per object, turning on change events and changing the field mapping are done by a person with admin rights on the CRM Connections page. The tools return that page's link (`connections_url`); give it to them. Never try to do it yourself.
- **Orders are preview-only.** Order write-back (Fonteva only) can be previewed; running it is refused. Leave `orders` out of `kinds` on a run.
- **Numbers come from the answer.** Report the snapshot's counts as they are; never estimate a renewal risk or engagement figure that is not in it.
- Words: say **member**, **prospect** (never "lead"), and never "member intelligence" or "CDP". Never name the in-product assistant or internal engines.

## The workflow

1. **Which AMS.** `list_crm_sources {}`: is Fonteva, Nimble AMS or Protech connected, and is it healthy? If none is, say it is connected with Sessionboard's help and stop.
2. **Check the mapping.** `get_ams_mapping { app_id }` with `app_id` `fonteva`, `nimble-ams` or `protech`. For each member slot (email, member type, status, join and renewal dates, …) and registration slot (event, status, checked in, …) report which AMS field it reads, which were found, which are missing and which are required.
   - Protech has no published schema: the answer adds `discovery` with candidate tables. To see suggested columns for a table the person picks: `get_ams_mapping { app_id: "protech", members_table?, registrations_table? }`.
   - To change a slot, the person saves the mapping at `connections_url`.
   **Pause:** if a required slot is missing, say so and give the link before going on; the snapshot will be thin without it.
3. **Member snapshot.**
   - From members already in Sessionboard: `get_member_snapshot { as_of? }` (`as_of` is `YYYY-MM-DD`, default today).
   - Straight from the AMS, before anything is imported: `get_member_snapshot { app_id }`. The answer adds `source`. Do not pass `as_of` with `app_id`.
   Lead with members, engaged versus never engaged, lapsed, and members active in more than one channel. Then renewals at risk (up to 50), speaker prospects among members, warm non-members, the by-member-type table and the next steps it suggests.
4. **Who exactly.** To list members: `find_crm_people { member: true, linked?, lifecycle?, attended?, event_id?, sort? }`. `linked` is the AMS's slug from `facets.linked` (for example `fonteva`), or `none` for members linked to no system.
5. **Preview the write-back.** `preview_ams_writeback { app_id, kinds? }` (`kinds`: engagement, activity, orders; by default every object that is on). Report:
   - `settings`: which objects are switched on.
   - Whether Sessionboard's objects exist in the AMS; if not, the field lists the customer's admin must create first.
   - `preview`: creates, updates, unchanged, errors, with the first rows.
   If nothing is switched on, give `connections_url` and stop.
6. **Run the write-back.**
   **Pause:** "Write 1,240 engagement updates and 310 new activity rows to your Fonteva now? This writes only to Sessionboard's own objects, never to member records."
   On a clear yes: `run_ams_writeback { app_id, kinds?, confirmed: true }`. Report what the answer says was written. Leave `orders` out.

## When something goes wrong

- **"Not written: show the person what preview_ams_writeback would send and ask"**: `confirmed: true` was missing. Preview, ask, then call again.
- **"<object> write-back is off, so nothing was written"** or **"Write-back is off for every object"**: a person with admin rights switches it on at the link given; an assistant cannot.
- **"Order write-back is preview-only for now"**: leave `orders` out of `kinds`.
- **"The write-back was refused … Nothing was written"** (a 400 from Sessionboard): say the message and the link.
- **"as_of only applies to the snapshot from People tagged Member"**: drop `as_of` when reading straight from the AMS.
- **403 "This connection cannot use Sessionboard CRM"**: missing `read:crm` / `write:crm`, or the role lacks Contacts READ (or is not an org admin, for a run). If scopes were added after connecting, disconnect and reconnect.
- **Read-only** (`trial_ended`, `plan_ended`, `paused`, `payment_due`, `read_only`): reads still work; a person with admin rights fixes the plan in CRM → Plan and billing.
- **404 "Not found"**: check the app id, and that the AMS shows as connected, with `list_crm_sources`.

## What this skill does not do

- It cannot connect an AMS, change the field mapping, switch write-back on or off, or turn on change events; a person does those on the CRM Connections page.
- It cannot run order write-back, or edit the customer's own member records in the AMS.
- It cannot read past write-back runs from the run log, or change when the regular write-back runs.
- It does not import members by itself; bringing people in is the tidy-your-people-and-companies skill.

## Tools used

- `list_crm_sources` — which AMS is connected and healthy (read)
- `get_ams_mapping` — which AMS field each slot reads; Protech table suggestions (read)
- `get_member_snapshot` — member engagement snapshot, from People or straight from the AMS (read)
- `find_crm_people` — list members and who they are linked to (read)
- `preview_ams_writeback` — what is switched on and a dry run of a write (read)
- `run_ams_writeback` — write to Sessionboard's objects in the AMS, `confirmed: true` (write)
