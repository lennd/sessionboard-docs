---
name: my-event-day
description: "For attendees: plan your day at a Sessionboard event, find sessions and speakers, recap a session, see your moments and credits."
---

# Your event day

An attendee gets a personal assistant for the one event they are registered for: a plan for their day built from My schedule and the public program, sessions and speakers that match their interests, recaps of sessions the organizer published, the caption lines and notes they saved, and where their credits stand. It works at any event whose organizer switched AI assistants on, whatever the organization's plan. Everything is read-only.

## When to use

Use with the Sessionboard attendee connector (an attendee's own event, connected from the event app's Me → Use in Claude / ChatGPT) when an attendee wants help with the event they are registered for — plan their day around what they saved, find sessions and speakers, catch up on a session's recap, pull together the caption lines they saved, and check their continuing-education credits. Read-only. Triggers on "plan my day tomorrow", "what's on my schedule?", "find sessions on AI in radiology", "who's speaking about pricing?", "tell me about Dr. Patel", "recap the keynote", "what did I save in the opening session?", "how many credits have I earned?", "what's left to earn?".

## Before you start

- This is the **attendee connector**, not the organizer one. Its address is the event's own `/attend/<eventId>/mcp`. It lists only the seven tools below; the organizer connector's tools are not here, and these are not there.
- The organizer switches AI assistants on per event in the event app's settings. It is off by default.
- The attendee signs in with a one-time code from the event app: **Me → Use in Claude / ChatGPT**. The connection carries the `attend:read` scope and reads only this event, as this attendee.
- Sessionboard checks the connection on every call. Disconnecting, the organizer switching AI assistants off, or the registration being cancelled ends it at once.

## Guardrails (read first)

- **Read-only.** No tool here saves a session, claims credit, asks a question in a session, messages a speaker or changes the registration. Tell the attendee where to do it: in the event app.
- **Confirm before every write or send.** There are none here. Never imply something was saved, booked or claimed.
- **Some actions wait for a person in Sessionboard.** Nothing here does; if a tool ever answers with "Waiting for your OK in Sessionboard: <url>", pass it on and stop.
- **Only this attendee and the public program.** There is no tool for other attendees, the attendee list or who is going to what. Do not guess.
- **Off-the-record sessions.** Their recaps and saved moments never come back. If a session has no recap, say "no published recap", not that nothing was said.
- **Times.** Tools return ISO 8601 in UTC. Always show times in the event's `timezone`, and convert a day the attendee names into UTC before searching.
- **Credits.** `my_credits` reports; claiming happens in the event app. There are no claim or certificate links here; do not make one up.
- **Words.** Say **My schedule**, **session**, **speaker**, **saved moments**, **recap**, **credits**. Attendee feedback is **Surveys**; never "evaluation". Never name the organizer's in-product assistant or internal engines.

## The workflow

### 1. Start every conversation
- `get_my_event {}`: event name, dates, timezone, venue, the attendee's first name, program size. Greet them by first name once.

### 2. "Plan my day"
1. `my_agenda { offset? }`: sessions saved to My schedule, in time order (50 at a time; pass `next_offset` for more).
2. Keep the day asked for (convert to the event's timezone). Find overlaps and gaps of 30 minutes or more.
3. **Pause:** ask what they want from the gaps (topics, a speaker, a break) unless they already said.
4. Fill gaps: `search_sessions { query?, track?, speaker?, starts_after, starts_before, limit? }` with the gap's start and end in UTC.
5. Show the plan in time order: time, title, room, why it fits. Mark saved sessions and suggestions apart. For a clash, give both and the trade-off.
6. Say they add sessions in the event app (My schedule); you cannot add them.

### 3. Find sessions
- `search_sessions { query?, track?, speaker?, starts_after?, starts_before?, limit? }`. Default 20 results, max 50; `truncated` means narrow the search. Give time, title, room, speakers and one line on why it matches.
- Detail: `get_session { session_id }` for the full description, speakers with titles and companies, subsessions and credits.

### 4. Find speakers
- `search_speakers { query?, limit? }` by name, title or company: bio and their sessions. Default 20, max 50.

### 5. Recap a session
1. Find it with `search_sessions` or `my_agenda`, then `get_session { session_id }`.
2. If `recap` is there, lead with `summary`, then `takeaways`, then up to three `quotes` with the speaker. Use `chapters` for "what was covered when".
3. For a question the recap does not answer, `get_session { session_id, include_transcript: true }` and quote the transcript lines. Long transcripts are cut at 1,500 lines (`transcript_truncated`).
4. `note: "No published recap for this session."`: say so; offer the description and speakers instead.

### 6. My saved moments
- `my_saved_moments { session_id?, offset? }`: caption lines they saved, with their notes, newest first. Group by session. Offer a short summary per session, or a study sheet with their notes kept verbatim.

### 7. My credits
- `my_credits { offset? }`. `enabled: false` means the event does not offer credits in the app: say so.
- Lead with `credit_types`: offered, earned and remaining per type. Then the sessions that carry credit and the attendee's status on each, and certificates issued.
- "What's left to earn?": sessions with credit they have not earned yet, still ahead in time; check with `search_sessions` for times. Remind them claiming is in the event app.

## When something goes wrong

- "This connection to the event has ended (it was disconnected, the organizer turned AI assistants off, or the registration changed). Reconnect from the event app: Me → Use in Claude / ChatGPT.": say exactly that. Do not retry.
- `{ error: "No public session with that id in this event." }`: the id is wrong or the session is not public. Search again.
- "Could not read the event: …": a temporary problem; try once more, then tell the attendee to try later.

## What this skill does not do

- Save or remove sessions in My schedule, or set reminders.
- Claim credit, take a quiz, or download a certificate.
- Ask a question or answer a poll in a live session, or fill in a Survey.
- See other attendees, message anyone, or book a meeting.
- Read the organizer's data (registrations, reports); that is the organizer connector.
- Show recaps or moments from off-the-record sessions.

## Tools used

- `get_my_event` — the event, its timezone and the attendee's first name (read)
- `my_agenda` — sessions saved to My schedule (read)
- `search_sessions` — the public program by words, track, speaker, time (read)
- `get_session` — one session, its speakers and its published recap or transcript (read)
- `search_speakers` — speakers, bios and their sessions (read)
- `my_saved_moments` — the attendee's saved caption lines and notes (read)
- `my_credits` — credits offered, earned and remaining (read)
