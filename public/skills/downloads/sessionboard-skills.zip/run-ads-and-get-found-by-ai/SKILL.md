---
name: run-ads-and-get-found-by-ai
description: "Run Sessionboard Goals ads on your own ad account within an approved cap, and check whether AI assistants find your event (Found by AI)."
---

# Sessionboard: Run ads and get found by AI

Two ways to bring more people to an event:

- **Ads:** Goals drafts ads that point at the event's registration page and run on the organization's own LinkedIn or Meta ad account, to its own first-party audience, within a spend cap a person approves.
- **Found by AI:** each week Sessionboard asks the connected AI assistants (Claude, ChatGPT, through their APIs) up to 8 buyer questions and records whether the answers name the event, a speaker or a session, and whether they cite the event's own pages.

## When to use

"Set a goal for the Chicago event", "run LinkedIn ads for the webinar", "change the cap to $500", "pause the ads", "stop the ads", "which ad account do we use?", "do AI assistants know about my event?", "are we showing up in ChatGPT?", "ask the assistants now", "change the questions". Needs the Sessionboard MCP server's Marketing tools.

## Steps

### Goal and ads

1. **Start with a goal.** `suggest_goal { event_id }` gives the three starters (fill_event, win_back, ads), a suggested number with its reason, and which ad accounts are connected. Offer those, then `plan_goal` with the starter, number and date the person confirms. Progress: `get_goal`.
2. **Ad account.** LinkedIn needs the app connected (`connect_app` with `linkedin-ads`), then `list_ad_accounts` and, on the person's pick, `choose_ad_account { ad_account_id }`. Meta takes its account when it is connected.
3. **Draft.** `launch_ads` drafts ads and spends nothing. `update_ads { ad_id, … }` changes cap, dates, audience, copy or creatives. Every edit makes a new draft version.
4. **Pause:** show the cap, dates and copy. Only on a yes: `approve_ads` with the current draft version. If it answers `needs_approval` with a url, say "Waiting for your OK in Sessionboard: <url>".
5. **While it runs.** `get_goal` shows the ads. `pause_ads { ad_id }` stops spend until `resume_ads { ad_id }` (it never raises the cap). `cancel_ads { ad_id }` ends it for good: say which ad and its cap first.

### Found by AI

6. **Read.** `get_ai_discovery { event_id }`: how many answers named the event, the trend, each answer with its citations, and a next move. Lead with the next move.
7. **Change the questions.** Ask first, then `update_ai_discovery { event_id, questions }` (up to 8; keep each key so the trend compares like with like), or `topic`, `city`, `enabled`. Record ChatGPT Business Hub numbers only when the person reads them to you.
8. **Run now.** Tell the person the cost from `get_ai_discovery` (`cost.estimate_run_usd`, a few cents). On a yes: `run_ai_discovery { event_id }`. Answers arrive within a few minutes; it runs once a day per event.

## Guardrails

- No spend without an approved cap. An edit after approval needs a new approval.
- Ads use the organization's own audience; never claim reach the audience doesn't have.
- Found by AI asks assistants through their APIs; nothing is scraped. Say "about" for estimates and never invent a mention.

## Tools used

- `approve_ads` — Approve ad spend (write)
- `cancel_ads` — Cancel ads (write)
- `choose_ad_account` — Choose ad account (write)
- `connect_app` — Connect app (write)
- `get_ai_discovery` — What AI assistants say about an event (read)
- `get_goal` — Get goal status (read)
- `launch_ads` — Draft ads (no spend) (write)
- `list_ad_accounts` — List ad accounts (read)
- `pause_ads` — Pause ads (write)
- `plan_goal` — Plan a goal (write)
- `resume_ads` — Resume ads (write)
- `run_ai_discovery` — Ask the AI assistants now (write)
- `suggest_goal` — Suggest a goal (read)
- `update_ads` — Edit an ad draft (write)
- `update_ai_discovery` — Change what the AI check asks (write)
