---
name: set-up-sending-and-site-tracking
description: "Set up Sessionboard to email from your own domain, run your own web domains, and see which known people visit your site and what they consented to."
---

# Sessionboard: Set up sending and site tracking

The setup behind every email and page:

- **Sending domain:** email goes from the organization's own address (hello@mail.example.com) once its domain is authenticated with DKIM and return-path records.
- **Custom domains:** the organization's own web addresses on its pages and libraries.
- **Website tag:** a snippet on the organization's own site that counts visits by people it already knows (first-party only).
- **Consent:** each person's lists and their consent history.

## When to use

"Send our emails from events@acme.com", "why are emails still coming from Sessionboard?", "what DNS records do I add?", "check the domain now", "go back to the Sessionboard sender", "move our domain to the new library", "remove the old domain", "turn on the website tag", "who from our target accounts visited the pricing page?", "has Ada unsubscribed?". Needs the Sessionboard MCP server's Marketing tools.

## Steps

### Email from your own domain

1. **Check.** `get_sending_domain_health` says the From address in effect, whether its domain is verified, and what is missing. `list_sending_domains` shows each setup with its DNS records.
2. **Start.** Ask which address. `add_sending_domain { sender_email }` (a subdomain is safest) returns the records to add at the DNS provider. Nothing is sent.
3. **Wait for DNS.** `preview_sending_domain_dns { setup_id }` says which records are present, missing or conflicting. When they are all in: `check_sending_domain { setup_id }`. DNS can take minutes to hours; say so instead of checking in a loop.
4. **Fixes.** If another email service already uses the s1/s2 selectors: `regenerate_sending_domain_records { setup_id, custom_dkim_selector }`. To cancel a setup still waiting on DNS: `remove_sending_domain { setup_id }`. To go back to the Sessionboard sender after verifying: ask first, then `reset_sender_address`.

### Web domains

5. `list_custom_domains` lists each domain, what it serves and its DNS status. Connecting one is `connect_custom_domain` (sites skill). **Pause:** moving or removing a domain changes a live address. On a yes: `move_custom_domain { site_id, domain_id }` or `remove_custom_domain { domain_id }`. Never touch a first-party sessionboard.com address.

### Who visits your site

6. `get_website_tag` gives the snippet and whether it has been seen. If it is off: `enable_website_tag`, then give the person the snippet for their site's `<head>`.
7. `who_visited { path, days, target_accounts }` lists known people who viewed pages, with company, views and last page.

### Consent

8. `find_people` → the person's key, then `get_person_consent { person_key }`: their lists and consent history, one sentence each.

## Guardrails

- DNS changes happen at the person's provider; give them the exact records and never claim a record is in place until a check says so.
- Removing a domain or resetting the sender changes live addresses and email at once: ask first.
- Site tracking counts only people the organization already knows. Show names and companies; show emails only when asked.

## Tools used

- `add_sending_domain` — Add a sending domain (write)
- `check_sending_domain` — Check a sending domain (write)
- `connect_custom_domain` — Connect your own domain (write)
- `enable_website_tag` — Enable website tag (write)
- `find_people` — Find people (read)
- `get_person_consent` — A person's consent history (read)
- `get_sending_domain_health` — Email sending health (read)
- `get_website_tag` — Website tag (read)
- `list_custom_domains` — List your own domains (read)
- `list_sending_domains` — List sending domains (read)
- `move_custom_domain` — Move your own domain (write)
- `preview_sending_domain_dns` — Preview sending domain DNS (read)
- `regenerate_sending_domain_records` — New sending domain records (write)
- `remove_custom_domain` — Remove your own domain (write)
- `remove_sending_domain` — Cancel a sending domain setup (write)
- `reset_sender_address` — Reset the sender address (write)
- `who_visited` — Who visited (read)
