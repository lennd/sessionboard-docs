---
name: brand-and-gate-your-recordings
description: "Finish Sessionboard recordings and clips: branded overlay renders, an email gate, the button and end card, bulk review of clips, and who watched."
---

# Sessionboard: Brand and gate your recordings

Turn a recording or clip into something ready to share:

- **Branded renders:** a show overlay template (rundown of chapters, countdown, name plates, topic banner, ticker, highlighted captions) burned into a new video in the Brand kit's colours. The source recording is not changed.
- **Email gate:** ask for an email before a recording plays, or after the first few minutes. Anyone with a valid email watches at once and joins People; only people who tick the box join the newsletter.
- **Button and end card:** by default "Register for <your next event>"; change it to "Download the slides", or turn it off.
- **Clip review in bulk:** approve, archive, tag or add up to 200 library items to a campaign at once.
- **Who watched:** people who watched a recording and how far.

## When to use

"Brand the keynote with our overlay", "render the panel with name plates", "make a podcast-style version", "gate the keynote recording", "gate it after five minutes", "add a Download the slides button", "approve all the clips from Tuesday", "who watched the keynote?", "the transcript failed". Needs the Sessionboard MCP server's Marketing tools.

## Steps

1. **Find the recording or clip.** `list_recordings` (recordings) or `list_content` (clips, reels). `get_recording { media_id }` gives the transcript with who said what and when. If `transcript_status` is failed: `retry_transcript { media_id }` once (a recording with no speech fails again; say so).
2. **Branded render.**
   - `list_overlay_templates` shows the three built-ins (broadcast, lower-third, podcast) and the kit's own. To make one: `manage_overlay_template { action: "create", base, … }`.
   - `preview_overlay { media_id, template_id }` returns one still and the contrast check of every text colour. Show the still.
   - **Pause:** the full render takes a while. On a yes: `apply_overlay_template { media_id, template_id }`, then check `get_render { render_id }` until it is ready and share `download_url` (valid for 6 hours).
3. **Gate.** `get_video_options { media_id }` shows the gate, button and end card today. **Pause:** say exactly what visitors will see. On a yes: `gate_video { media_id }` (before it plays) or `gate_video { media_id, at_seconds: 300 }` (after five minutes). For a clip or reel: `gate_recording { target_kind: "content_item", target_id }`. Both return the share link.
4. **Button and end card.** **Pause:** say the change. On a yes: `set_video_options { media_id, cta_mode, cta_label, cta_url }` with only what the person asked to change.
5. **Review clips in bulk.** `list_content` → the ids. Say how many items will change, then `bulk_content { item_ids, action }` (approve, draft, archive, restore, tag, untag, add_to_campaign). It publishes and sends nothing.
6. **Who watched.** `get_watch_report { media_id, min_percent }`. `get_video_playback { media_id }` gives the stream, captions and chapters to embed elsewhere.

## Guardrails

- Gates, buttons, end cards and approvals change what visitors see on live public pages. Say the change and wait for a yes before each call.
- A render makes a new video; the original is never changed. Don't promise a time: say "it's rendering" and check `get_render`.
- Keep the newsletter consent box as it is: watching never subscribes anyone by itself.
- Transcriptions are audio-only. Never describe it as video streaming or video analysis.

## Tools used

- `apply_overlay_template` — Apply overlay template (write)
- `bulk_content` — Change many library items (write)
- `gate_recording` — Ask for an email before a recording plays (write)
- `gate_video` — Ask for an email to watch a recording (write)
- `get_recording` — Get a recording (read)
- `get_render` — Get render (read)
- `get_video_options` — Read a recording's gate, button and end card (read)
- `get_video_playback` — Recording playback (read)
- `get_watch_report` — Who watched (read)
- `list_content` — List content (read)
- `list_overlay_templates` — List overlay templates (read)
- `list_recordings` — List recordings (read)
- `manage_overlay_template` — Manage overlay template (write)
- `preview_overlay` — Preview overlay (write)
- `retry_transcript` — Retry transcript (write)
- `set_video_options` — Change a recording's button or end card (write)
