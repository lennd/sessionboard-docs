---
name: design-event-emails-and-page
description: "Design a Sessionboard field event or webinar's registration emails and event page: on-brand drafts, previews, a registration form, and a person publishes."
---

# Sessionboard: Design event emails and the event page

A field event or webinar sends its own emails on its own schedule (confirmation at sign-up, reminders before the start, the replay after a webinar) and has one public event page with a registration form. This skill restyles them in the organization's Brand kit and changes what the form asks. A person accepts or publishes.

## When to use

"Make the confirmation email match our brand", "rewrite the reminder", "preview the replay email", "restyle the event page", "remove the agenda block", "ask for job title on the form", "add a dietary question to every stop", "the page is ready, tell the team". Needs the Sessionboard MCP server's Marketing tools.

## Steps

### Emails

1. **Read.** `get_event_emails { event_id }`: each email's key, when it sends, its merge tags, current design, subject, `version`, and the Brand kit tokens. `list_brand_kits` shows which kit the event uses and what is still empty.
2. **Draft.** `update_event_email_draft { event_id, key, mjml, subject, base_version }` with a complete MJML document, only the merge tags listed for that email, and `{{brand.*}}` tokens for colours, fonts and logo. Without `apply` it is a proposal.
3. **Preview.** `preview_event_email { event_id, key, version: "proposed" }` renders it with real event values. Show it, and fix any `accessibility_warnings` in the next proposal.
4. **Pause:** the person accepts the proposal in Sessionboard (Event → Emails), or says yes here to `apply: true`, which puts it live (what sent before stays in the email's history).

### Page

5. **Read.** `get_event_page { event_id }` (note `site.revision`). `list_event_page_templates` lists starter styles; restyle with `update_event_page_draft { template_id }` (colours and font only).
6. **Edit.** `update_event_page_draft` for blocks and copy; `remove_event_page_block { event_id, block_id, base_revision }` to take a block out (the hero and register blocks stay). Show each answer's `what_changed.summary`, and nothing more.
7. **Registration form.** `get_registration_form { event_id }`, then `update_registration_form { event_id, fields }` with the whole list after Name and Email, or `add_registration_question { event_id, label, kind }`. Reuse a catalog question before making a new one. `apply_to_tour: true` keeps every stop's form the same.
8. **Pause:** `propose_event_page_publish { event_id }` tells the organizer the draft is ready; a person publishes. Publishing here is `publish_event_page` and only on the person's yes. If it answers `needs_approval` with a url, say "Waiting for your OK in Sessionboard: <url>".

## Guardrails

- Event emails send on the event's schedule; never suggest sending one by hand.
- Drafts and proposals change nothing live. `apply: true`, publishing and form changes on a live page do: say the change and get a yes.
- Always pass the version or revision you just read, so a change made since is caught instead of overwritten.
- Keep text readable on brand colours (WCAG 2.2 AA) and give every image alt text.

## Tools used

- `add_registration_question` — Add registration question (write)
- `get_event_emails` — Get event emails (read)
- `get_event_page` — Get event page (read)
- `get_registration_form` — Get registration form (read)
- `list_brand_kits` — List brand kits (read)
- `list_event_page_templates` — List event page templates (read)
- `preview_event_email` — Preview event email (read)
- `propose_event_page_publish` — Propose event page publish (write)
- `publish_event_page` — Publish event page (write)
- `remove_event_page_block` — Remove event page block (write)
- `update_event_email_draft` — Update event email (write)
- `update_event_page_draft` — Update event page draft (write)
- `update_registration_form` — Update registration form (write)
