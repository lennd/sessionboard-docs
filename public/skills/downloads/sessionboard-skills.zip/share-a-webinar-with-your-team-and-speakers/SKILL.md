---
name: share-a-webinar-with-your-team-and-speakers
description: "Get a Sessionboard webinar shared: email signatures for the team, share cards, speakers' tracked links and a ready-to-post team kit, before and after it runs."
---

# Sessionboard: Share a webinar with your team and speakers

Everyone who can post about a webinar gets something ready to use, and every share is credited through that person's own tracked link:

- **Email signatures:** a small banner plus a one-line invite each teammate pastes into their email signature. The banner says "Save your seat" until the start, then "Watch the recording" by itself.
- **Share cards:** six on-brand images (1200×627). Three use the speakers' faces (spotlight, lineup, portrait), three don't (headline, calendar, ticket). Each carries the title, date, time and registration link as text and a QR code.
- **Speaker links:** each speaker's and co-presenter's personal tracked link, so registrations they bring are credited to them.
- **Team kit:** ready-to-post LinkedIn posts with images and copy, sent to the team by email, Slack or Teams from Sessionboard.

Before the webinar, every link goes to the registration page. After it, links go to the recording and clips.

## When to use

"Get the team sharing the webinar", "make email signatures for the launch webinar", "send everyone their signature", "make share cards", "give the speakers their links", "who has shared so far?", "make a team kit with the clips", "the date changed, update the cards". Needs the Sessionboard MCP server's Marketing tools.

## Steps

1. **Find the webinar.** `list_events_with_status` → the webinar's `event_id`. Check how ready it is: `get_email_signatures { event_id }`, `get_share_cards { event_id }`, `get_speaker_links { event_id }`.
2. **Make what is missing or stale.** When `generated` is false or `stale` is true: `make_email_signatures { event_id }`. When `cards` is empty or `stale` is true: `make_share_cards { event_id }` (or only some `designs`). Show the person the banner and the cards. Neither sends anything.
3. **Speakers' links.** If any speaker has `pending: true`, or sharing is off: `give_speaker_links { event_id }`. Nobody is emailed: Sessionboard does not email speakers their links. Give the person each speaker's `share_url` to send, or draft a speaker share-kit campaign with `manage_campaign` (marketing-campaigns skill). Get speakers their link and kit while there is still time to post, not on the day.
4. **Choose the signature team.** `set_signature_team { event_id, action: "add", user_ids }` gives organization members their own tracked link without emailing them; `action: "remove"` with `teammate_id` takes one off.
5. **Pause:** name who will be emailed. Only after the person says yes: `send_email_signatures { event_id, user_ids }`. Each teammate gets a link to a page where they copy the signature. It is refused once the webinar has started.
6. **Team kit.** `make_team_kit { event_id, channel }` drafts the posts. Before the start it uses the share cards; after, the recording's clips (`clip_ids` picks them, else the first three; find them with `list_content`). It returns the draft's `url`: the person picks the team and sends it in Sessionboard.
7. **See who is sharing.** `get_email_signatures` → `team[]`: emailed, opened, copied, clicks, registrations. `get_speaker_links` → each speaker's shares. For everyone together: `find_people { event_id }` (marketing-people skill).

## After the webinar

Once the recording or clips are ready (`list_content`), switch to the after-event kit: `make_team_kit { event_id, clip_ids }`. Signatures and speaker links switch by themselves. Don't switch before there is something to watch.

## Guardrails

- Making signatures, cards and links sends nothing. Only `send_email_signatures` emails anyone; ask first and get a yes in this conversation.
- If it answers `needs_approval` with a url, say "Waiting for your OK in Sessionboard: <url>" and don't call it again. `list_approvals` shows what is waiting.
- Remake cards and signatures when the title, date, speakers or brand change (`stale: true`), so nobody shares an old date. Remaking updates the same images everywhere they are used.
- Use only the numbers the tools return for shares, clicks and registrations; never estimate reach.

## Tools used

- `find_people` — Find people (read)
- `get_email_signatures` — Get email signatures (read)
- `get_share_cards` — Get share cards (read)
- `get_speaker_links` — Get speaker links (read)
- `give_speaker_links` — Give speakers links (write)
- `list_approvals` — What is waiting for your OK (read)
- `list_content` — List content (read)
- `list_events_with_status` — List events with status (read)
- `make_email_signatures` — Make email signatures (write)
- `make_share_cards` — Make share cards (write)
- `make_team_kit` — Make a team sharing kit (write)
- `manage_campaign` — Manage marketing campaign (write)
- `send_email_signatures` — Send email signatures (write)
- `set_signature_team` — Set the email signature team (write)
