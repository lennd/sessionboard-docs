---
name: configure-an-event-or-webinar
description: "Configure a Sessionboard field event or webinar in one pass: basics, venue, hosts, webinar provider, invite list and teammates, with a diff before each write."
---

# Sessionboard: Configure an event or webinar

One read shows everything a field event or webinar can be set to, and what can be changed from here. Each change is previewed as a diff first. Configuring never publishes, sends invitations, cancels or deletes: those stay with a person.

## When to use

"Set the webinar to 45 minutes on Zoom with a waiting room", "change the venue and capacity", "make Grace and Alan the hosts", "turn on the waitlist", "add these people to the invite list", "invite my colleague to Sessionboard", "what can I still configure?", "archive the test event", "bring the event back". Needs the Sessionboard MCP server's Marketing tools.

## Steps

1. **Read.** `get_event_configuration { event_id }`: basics, settings with defaults, the capability map and `updated_at`. `list_event_capabilities { event_id }` lists each area (venue, registration, hosts, provider, emails, page, …), whether it is on, and the tool to change it.
2. **Change basics and settings.** `update_event_configuration { event_id, patch, base_updated_at, dry_run: true }` returns the diff. **Pause:** show it. On a yes, call again without `dry_run`.
3. **Hosts.** `set_event_hosts { event_id, hosts, base_updated_at, dry_run: true }` shows which contacts the names match; then again without `dry_run`.
4. **Webinar provider.** `configure_webinar_provider { event_id, provider, duration_minutes, registration, options, base_updated_at, dry_run: true }`, then without `dry_run`. Settings are stored only: nothing changes on Zoom, Webex, Teams or the other providers until an admin publishes.
5. **Invite list.** `invite_attendees { event_id, rows }` adds or updates people by email. It sends nothing; sending invitations is a button for the admin in Sessionboard.
6. **Teammates.** Only with addresses the person gave and confirmed: `invite_teammates { emails, role }`. It emails each address, so it waits for an OK in Sessionboard: say "Waiting for your OK in Sessionboard: <url>" and don't call again.
7. **Archive or restore.** **Pause:** archiving takes the public page offline for everyone. On a yes: `archive_event { event_id }`. `restore_event { event_id }` brings it back as it was.

## Guardrails

- Always dry-run first and pass `base_updated_at` from the read just before; a 409 means someone changed it since: read again.
- A 423 means an admin has paused agent writes: say so and stop.
- Nothing here publishes or sends to registrants. Emails and the page are the design-event-emails-and-page skill.

## Tools used

- `archive_event` — Archive event (write)
- `configure_webinar_provider` — Configure webinar provider (write)
- `get_event_configuration` — Event configuration (read)
- `invite_attendees` — Invite attendees (write)
- `invite_teammates` — Invite teammates (write)
- `list_event_capabilities` — Event capabilities (read)
- `restore_event` — Restore event (write)
- `set_event_hosts` — Set event hosts (write)
- `update_event_configuration` — Update event configuration (write)
