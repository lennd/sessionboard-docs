---
name: run-a-premiere
description: "Run a Sessionboard premiere: a recording plays at a set time for everyone on the event page, with questions, polls and reminders, then stays on demand."
---

# Sessionboard: Run a premiere

A premiere plays a recording at one time for everyone on the event page, clock-synced, with questions and polls beside it. Visitors can ask for a reminder (sent the day before and at the start). Afterwards it plays on demand with the recording's gate.

## When to use

"Run the keynote as a premiere next Tuesday at 11", "move the premiere to Thursday", "add a poll to the premiere", "hide that question", "what did people ask during the premiere?", "end the premiere now", "how many asked for a reminder?". Needs the Sessionboard MCP server's Marketing tools.

## Steps

1. **Find the recording.** `list_recordings` → `media_id`. Check what is already scheduled: `list_premieres`.
2. **Schedule it.** Turn the person's words into an exact time in the event's timezone and say it back ("Tuesday 3 March, 11:00 Chicago time"). `schedule_premiere { media_id, starts_at }` puts it on the event page DRAFT and returns `page.preview_url`.
3. **Pause:** show the preview. Only after the person says OK: `publish_event_page { event_id }`. If it answers `needs_approval` with a url, say "Waiting for your OK in Sessionboard: <url>".
4. **Before it starts.** `list_premieres` → reminders (people who asked). To add a poll, say its question and options and wait for a yes, then `manage_premiere_poll { premiere_id, action: "create", question, options }`. It opens at once.
5. **During it.** `get_premiere_room { premiere_id }` lists questions and poll votes. To hide, show or mark a question answered: say which one, then `moderate_premiere_question { premiere_id, question_id, action }`. To stop questions or end it: `update_premiere { premiere_id, qa_open: false }` or `{ end: true }`.
6. **Moving or cancelling.** `update_premiere { premiere_id, starts_at }` moves it and sends the reminders again for the new time; `status: "cancelled"` cancels it. Say this before you call.
7. **After it.** `get_premiere_room` for what people asked (offer to draft follow-up content from it), and `get_watch_report { media_id }` for who watched.

## Guardrails

- Everything here changes the live public page. Tell the person exactly what visitors will see and call only after they say yes.
- Always say the time back in the event's timezone before you schedule or move a premiere.
- Moving a premiere re-sends reminders to everyone who asked; say so first.

## Tools used

- `get_premiere_room` — Read a premiere's questions and polls (read)
- `get_watch_report` — Who watched (read)
- `list_premieres` — List premieres (read)
- `list_recordings` — List recordings (read)
- `manage_premiere_poll` — Add or change a premiere poll (write)
- `moderate_premiere_question` — Hide, show or answer a premiere question (write)
- `publish_event_page` — Publish event page (write)
- `schedule_premiere` — Schedule a premiere on the event page draft (write)
- `update_premiere` — Move, cancel or end a premiere (write)
