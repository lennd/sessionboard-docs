---
name: promote-sessions-and-speakers
description: "Get accepted Sessionboard speakers ready and promoting: the speaker emails plan, session recordings and transcripts, and each speaker's share kit."
---

# Sessionboard: Promote sessions and speakers

After sessions are accepted, three things keep speakers moving:

- **Speaker emails plan:** what accepted speakers are asked for (profile, headshot, description, slides), by when, and when reminders go. Nothing reaches speakers until a person approves the plan; after that, invites and reminders go by themselves.
- **Recordings:** each session's recording from a YouTube or Vimeo link, transcribed within the organization's caption hours, ready for clips.
- **Share kits:** with Marketing, each accepted speaker's kit and what it brought (shares, clicks, registrations).

## When to use

"Ask speakers for headshots and slides by 1 March", "remind them a week before", "who hasn't sent their slides?", "approve the speaker emails", "pause the speaker emails", "add the keynote recording from YouTube", "transcribe the panel", "which speakers have shared?". Needs the Sessionboard MCP server's Sessions tools.

## Steps

### Speaker emails

1. **Read.** `get_speaker_emails { event_id }`: the tasks, due date, reminders, opening paragraphs, approved or paused, and each speaker's tasks and emails (sent, opened, ready).
2. **Change the plan.** `update_speaker_emails_plan { event_id, tasks, due_date, reminder_days_before_due, final_days_before_due, invite_intro }`. Nothing is emailed by changing it.
3. **Pause:** show the plan and who will be emailed. Only after the person asks: `approve_speaker_emails { event_id }`. It waits for their OK in Sessionboard: say "Waiting for your OK in Sessionboard: <url>".
4. **Stop or restart.** `pause_speaker_emails { event_id, paused: true }` stops every email at once, including any queued; `paused: false` resumes.

### Recordings

5. `list_session_media { event_id, session_id }` shows recordings, transcript status and clips.
6. Ask the person to confirm they own or may use the recording, then `add_session_recording { event_id, session_id, url, certified: true }`. Check progress with `list_session_media`.
7. `transcribe_session_media { event_id, session_id, media_id }` uses caption hours; when they don't cover it, nothing starts and you get the minutes needed.

### Share kits

8. `get_sessions_marketing { event_id }`: whether the organization has Marketing, caption hours left, and each accepted speaker's share kit (not sent, sent, opened, shared) with shares, clicks and registrations. Kits are sent with Marketing's campaign tools (marketing-campaigns skill).

## Starting Sessions

If the organization doesn't have Sessions yet and the person wants it: `add_sessions` starts a 14-day trial. It waits for their OK in Sessionboard.

## Guardrails

- Approving the plan emails speakers and keeps emailing them on schedule: it is a person's yes, then their OK in Sessionboard.
- Only add recordings the person confirms they may use.
- Transcription is audio-only and uses caption hours; say how many minutes it needs when it can't start.

## Tools used

- `add_session_recording` — Add a session recording from a link (write)
- `add_sessions` — Add Sessions to the organization (write)
- `approve_speaker_emails` — Approve the speaker emails (write)
- `get_sessions_marketing` — Get Marketing for a Sessions event (read)
- `get_speaker_emails` — Get the speaker emails plan (read)
- `list_session_media` — List a session's media (read)
- `pause_speaker_emails` — Pause or resume the speaker emails (write)
- `transcribe_session_media` — Transcribe a session recording (write)
- `update_speaker_emails_plan` — Change the speaker emails plan (write)
