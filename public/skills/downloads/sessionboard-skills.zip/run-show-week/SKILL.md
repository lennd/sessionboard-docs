---
name: run-show-week
description: "Run a weekly show in Sessionboard Marketing: plan the episode and guest, link the recording, and draft the podcast episode, clips, newsletter and guest kit."
---

# Run a show week

A recurring show (for example "Event Content Lab with Chris & Josh") lives in
Sessionboard Marketing as a show with numbered episodes. You do the busywork
around each episode; the hosts pick guests, record, approve and post.

## When to use

- "Set up our weekly show." / "Plan next week's episode."
- "Ep 3 is recorded, make everything from it."
- "What's waiting for us on the show this week?"
- "Log the results for last week's episode."

## The flow

1. **Find or make the show.** `list_shows`. No show yet? Create one as a draft
   with `create_show` (name, cadence, usual weekday and time, hosts). It needs
   a podcast feed for episodes: `list_podcasts`, or `create_podcast` for a feed
   of its own, then `update_show { podcast_show_id }`.
2. **Plan the episode.** `get_show` shows every episode and its status
   (idea → booked → recorded → produced → published → shared). Add the next
   one with `create_show_episode` (topic, guests as CRM contacts from
   `find_crm_contacts`, `scheduled_at`, the Zoom link). Booking the guest and
   sending invites happen in the person's calendar and email, after their OK.
3. **Link the recording.** After the call, `list_recordings { available: true }`
   then `import_recording`, and `update_show_episode { recording_media_id }`.
4. **Draft everything.** `run_show_episode` makes, as drafts: the podcast
   episode, a reel, clips, quote cards, a post pack and recap, a newsletter
   issue, a guest kit dry run and the page section. Content renders in the
   background: check `list_content { run_id }`, then run `run_show_episode`
   again to refresh the guest kit (finished steps answer `done`).
5. **Review with the hosts.** Show them what was drafted: the podcast episode
   title, the clips, the newsletter issue, who the guest kit goes to.
6. **Guest review.** On the hosts' OK, `send_content_kits` with confirm sends
   the guest their clips and quotes to review. Sending the kit is a request,
   not the guest's approval: check `list_content` for their decision before
   anything featuring them is published.
7. **Publish on the hosts' OK, one tool each.** `set_podcast_episode_status`
   (published) and `schedule_newsletter_issue`. The episode section for the
   show page is in the run result: add it to the show's Site, check
   `get_site_diff`, then `publish_site`. Mark the episode
   `update_show_episode { status: "published" }` only once those tools report
   it done (not on `needs_approval`, and not before a scheduled send goes
   out), and `shared` once the posts are out.
8. **Results.** A week later, `get_podcast_stats` and `list_content`; keep the
   numbers with `update_show_episode { results }` (they merge).

## Examples

- "Plan episode 4 with Dana from Northwind on hybrid sponsorship, Tuesday 2 pm
  ET" → `find_crm_contacts { q: "Dana" }` → `create_show_episode`.
- "Ep 3 is in Zoom, make everything" → `list_recordings { available: true }` →
  `import_recording` → `update_show_episode` → `run_show_episode`.

## Guardrails

- Ask before every write, and say what it will do: creating or changing a
  show, podcast or episode, importing a recording, and running the episode
  (it spends AI work on clips and posts). Reads need no OK.
- Everything `run_show_episode` makes is a draft. Never publish the podcast
  episode, schedule the newsletter, send guest kits or publish the page
  without the hosts' explicit OK in this conversation. Their assistant's
  permission prompt is the approval; Sessionboard asks again only if the
  organization turned on Assistant Approvals.
- Don't publish anything featuring the guest until the guest has approved
  their kit.
- Never invent results; record only numbers a tool returned or a host gave.
- The show's name is "Event Content Lab"; never shorten it to "Content Lab".
  Don't describe the show as live streamed.

## Tools used

- `create_podcast` — Create a podcast (write)
- `create_show` — Create a show (write)
- `create_show_episode` — Add a show episode (write)
- `find_crm_contacts` — Find CRM contacts (read)
- `get_podcast_stats` — Podcast downloads (read)
- `get_show` — Get a show (read)
- `get_site_diff` — What changed on a Site (read)
- `import_recording` — Import a recording (write)
- `list_content` — List content (read)
- `list_podcasts` — List podcasts (read)
- `list_recordings` — List recordings (read)
- `list_shows` — List shows (read)
- `publish_site` — Publish a Site (write)
- `run_show_episode` — Run a show episode (write)
- `schedule_newsletter_issue` — Schedule a newsletter issue (write)
- `send_content_kits` — Send presenters their kits (write)
- `set_podcast_episode_status` — Set podcast episode status (write)
- `update_show` — Update a show (write)
- `update_show_episode` — Update a show episode (write)
