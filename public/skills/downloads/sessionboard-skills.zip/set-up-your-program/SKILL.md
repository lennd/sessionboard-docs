---
name: set-up-your-program
description: "Set up a Sessionboard program event: import it from its web page, then rooms, tracks, tags, formats and statuses, and audience personas for review."
---

# Sessionboard: Set up your program

The groundwork before a call for speakers or an agenda: the event itself, its metadata (rooms, tracks, tags, formats, levels, languages, statuses, custom fields) and the audience personas reviewers use to judge sessions.

## When to use

"Set up our conference from its website", "add tracks for AI, Data and Leadership", "make a 'Needs edits' status", "add a Workshop format", "rename the Main Hall", "create personas for our audience", "who are our personas?". Needs the Sessionboard MCP server's Sessions and Program tools.

## Steps

1. **Make the event.** From its public page: `import_sessions_event_from_url { url, dry_run: true }`. Show the preview and the speakers the page lists. On a yes, call again without `dry_run`. A page imported before returns that event, not a duplicate. Speakers aren't added (pages rarely give emails); add each to a session with `manage_program_session` once the person gives their email.
2. **Read metadata.** `list_metadata { event_id }` shows what exists, so nothing is made twice.
3. **Add or change metadata.** `manage_metadata { action, entity_type, event_id, name, … }`. A status needs `name`, `color` and `status` (its base approval status). Say what will be created or renamed, then call.
4. **Personas.** `read_personas { event_id }`, then `manage_personas { action: "create", event_id, name, title, biography, likes_1, dislikes_1, … }` for each audience type the person describes. Reviewers see sessions through these personas.
5. **Next.** Open the call (run-a-call-for-speakers skill) or build the agenda (build-the-agenda skill).

## Guardrails

- Read before you write so rooms, tracks and statuses aren't duplicated.
- Deleting metadata or a persona needs the person's yes; a room or track a session still uses can't be removed (409 `in_use`): say which sessions use it.
- Say "review" for committee scoring, never "evaluation".

## Tools used

- `import_sessions_event_from_url` — Make a Sessions event from its page (write)
- `list_metadata` — List metadata (read)
- `manage_metadata` — Manage metadata (write)
- `manage_personas` — Manage personas (write)
- `manage_program_session` — Add or update a session (write)
- `read_personas` — Read personas (read)
