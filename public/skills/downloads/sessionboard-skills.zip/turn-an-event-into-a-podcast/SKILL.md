---
name: turn-an-event-into-a-podcast
description: "Turn a Sessionboard event's recorded sessions into a podcast show: draft episodes from sessions or recordings, review, publish, and tidy the show."
---

# Sessionboard: Turn an event into a podcast

Every session with a recording (or an approved audio recap) becomes a draft episode on the event's show. Nothing is published until a person reviews and publishes each episode.

## When to use

"Turn this event into a podcast", "add the keynote and the closing panel as episodes", "publish episodes 1 to 3", "take that episode out", "archive the old show". Needs the Sessionboard MCP server's Marketing tools.

## Steps

1. **Find the event.** `list_events_with_status` → `event_id`. Existing shows: `list_shows`.
2. **Make the show.** `make_podcast_from_event { event_id }` creates the event's show on the first call (reused after) with a DRAFT episode for every session that has a recording or approved recap.
3. **Add more.** `add_podcast_episodes { show_id, session_ids }` or `recording_ids` (from `list_recordings`). Sessions already in the show are skipped.
4. **Review.** `get_podcast { show_id }` lists episodes with title, status, source session, whether audio is ready and duration. Tell the person which are ready.
5. **Pause:** name the episodes to publish. On a yes: `set_podcast_episode_status` for each. If it answers `needs_approval` with a url, say "Waiting for your OK in Sessionboard: <url>".
6. **Tidy.** Ask first, then `remove_show_episode { show_id, episode_id }` (the recording and anything drafted from it stay) or `archive_show { show_id }`.
7. **Next.** Offer a branded podcast render (brand-and-gate-your-recordings skill, `podcast` overlay) or a newsletter issue with the episodes (run-your-newsletter-and-sign-ups skill).

## Guardrails

- Making and adding episodes publishes nothing. Publishing, removing and archiving need a yes first.
- Use only the organization's own recordings.

## Tools used

- `add_podcast_episodes` — Add podcast episodes (write)
- `archive_show` — Archive a show (write)
- `get_podcast` — Get a podcast (read)
- `list_events_with_status` — List events with status (read)
- `list_recordings` — List recordings (read)
- `list_shows` — List shows (read)
- `make_podcast_from_event` — Turn an event into a podcast (write)
- `remove_show_episode` — Remove a show episode (write)
- `set_podcast_episode_status` — Set podcast episode status (write)
