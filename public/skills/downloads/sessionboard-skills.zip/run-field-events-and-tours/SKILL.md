---
name: run-field-events-and-tours
description: "Run Sessionboard in-person field events and multi-city tours: target accounts, guest lists, host-signed invitations, approvals, listings and results."
---

# Sessionboard: Run field events and tours

Field events are in-person dinners, roundtables and labs. A tour groups several of them into a roadshow (dinners in five cities). Each stop has target accounts with a host (the rep), a guest list, invitations signed by each guest's host, approvals against capacity, check-in on the day and a results story afterwards.

## When to use

"Plan dinners in Chicago, Austin and Denver", "add a Boston stop like the Chicago one", "who should we invite from our target accounts?", "invite these 40 people to the tour", "send the invitations", "approve the waitlist", "put the tour on our events page", "list it on LinkedIn Events", "did the Chicago dinner move pipeline?". Needs the Sessionboard MCP server's Marketing tools.

## Steps

### Set up

1. **See what exists.** `list_tours` (stops, counts, next stop) and `list_events_with_status`.
2. **Add a stop.** `clone_in_person_event { eventId, startsLocal, city, venue }` copies seats, access, plus-ones, hosts, follow-up and tour onto a new date. `update_in_person_event { eventId, … }` changes basics (capacity, waitlist, access, hosts, date status). Neither sends anything.
3. **Make the tour.** `make_tour { name, eventIds }`, or add stops to an existing tour with `tourId`.
4. **Listing page.** `get_tour_listing { tourId }`. **Pause:** the listing page is public as soon as it is made. On a yes: `add_tour_to_listing { tourId }`. To post one stop to LinkedIn Events or Luma, ask first, then `post_event_listing { eventId, provider }`.

### Who to invite

5. **Target accounts.** `get_target_accounts { eventId, source }` shows the current list with hosts, plus suggestions from People or HubSpot. `set_target_accounts { eventId, targets }` replaces the list (send it whole).
6. **Guest list.** `add_guests { eventId, rows }`, or `accounts` to add everyone in People at those accounts with their account's host. For a tour: `invite_to_tour { tourId, rows, dryRun: true }` first, show where each person lands (nearest upcoming stop), then again without `dryRun` on a yes.

### Send and manage

7. **Pause:** say how many people, which stops and that each is signed by their host. The event page must be live. Only after a yes in this conversation: `send_invitations { eventId }` for one stop, or `send_tour_invitations { tour_id }` for every stop (stops without a live page are skipped and named).
8. **Approvals.** `whos_coming { event_id }` lists registrations. `set_guest_status { eventId, ids, action }` approves, declines, waitlists or checks people in; each guest gets the matching email, so ask first. Approvals respect capacity and a freed seat promotes the waitlist.

### Results

9. `get_field_event_results { eventId }`: invited → registered → approved → attended, accounts in the room vs. targeted, follow-up status and, with HubSpot connected, open pipeline at those accounts (influence, not attribution). Use its headline, findings and next move as given; say what `story.missing` lists instead of guessing.

## Guardrails

- Adding guests, targets and stops sends nothing. Invitations, status changes and listings reach people or go public: get a yes first.
- If a call answers `needs_approval` with a url, say "Waiting for your OK in Sessionboard: <url>" and don't call it again.
- Never estimate a number the results return as null.
- Keep plans to the event's results, content and follow-up.

## Tools used

- `add_guests` — Add guests (write)
- `add_tour_to_listing` — Make a tour's listing page (write)
- `clone_in_person_event` — Clone a stop (write)
- `get_field_event_results` — In-person event results (read)
- `get_target_accounts` — Target accounts (read)
- `get_tour_listing` — Get a tour's listing page (read)
- `invite_to_tour` — Invite to a tour (write)
- `list_events_with_status` — List events with status (read)
- `list_tours` — List tours (read)
- `make_tour` — Make a tour (write)
- `post_event_listing` — Post an event listing (write)
- `send_invitations` — Send invitations (write)
- `send_tour_invitations` — Send tour invitations (write)
- `set_guest_status` — Set guest status (write)
- `set_target_accounts` — Set target accounts (write)
- `update_in_person_event` — Update an in-person event (write)
- `whos_coming` — Who's coming (read)
