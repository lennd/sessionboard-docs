---
name: run-your-newsletter-and-sign-ups
description: "Run the Sessionboard newsletter and its first-party list: sign-up forms, issues, test sends, scheduling, journeys, results and who signed up."
---

# Sessionboard: Run your newsletter and sign-ups

The organization's own list, built from its own pages: sign-up forms on event pages, galleries and clips, and recording gates. People confirm by email (double opt-in) before they are on the list. The newsletter sends issues to that list after each event, monthly or by hand, and four fixed journeys follow up on their own.

## When to use

"Add a sign-up form to my event page", "how many people signed up this week?", "who signed up from the keynote gate?", "draft this month's newsletter", "send me a test", "schedule it for Tuesday", "hold the newsletter", "undo my last edit to the issue", "how did the last issue do?", "turn on the no-show journey". Needs the Sessionboard MCP server's Marketing tools.

## Steps

### Sign-ups

1. **Read.** `count_signups { days }` for "how many this week" (say its `message`). `list_subscribers` for who: filter by `status`, `source`, `event_id`, `q` or `since`. `list_signup_forms` for every form and gate, where it sits and how many signed up.
2. **Add a form.** `add_signup_form { event_id }` makes one form per event with copy from the event and places it on the event page DRAFT. Show `page.preview_url`. **Pause:** it goes live only after the person says OK: `publish_event_page { event_id }`. Without `event_id` you get an org form placed nowhere, for a show or agent-built page.
3. **Change a form.** `update_signup_form { form_id, … }` or `add_signup_question { form_id, label, kind }`. A form on a live page changes at once, and a new required question blocks sign-ups until the page asks it: say the change and wait for a yes.

### Newsletter

4. **Settings.** `get_newsletter` → name, from, reply-to, cadence, issues, and `missing`. A postal address is required by law before any issue sends: `update_newsletter { postal_address }` with the address the person gives.
5. **Draft an issue.** `draft_newsletter_issue` (from the latest event's recap, clips and episodes), then `get_newsletter_issue { issue_id }` and show its `html` as the preview.
6. **Edit.** Read the issue first, then `update_newsletter_issue { issue_id, blocks, base_updated_at }` with the whole changed blocks list. Every image needs alt text. Use only the organization's own material. To undo: `list_newsletter_issue_versions { issue_id }` → `restore_newsletter_issue_version { issue_id, version_id }` (ask first; the current issue is kept, so this can be undone too).
7. **Test.** `send_newsletter_test { issue_id }` sends it only to the person this assistant is connected as.
8. **Pause:** say the subject, recipient count and send time. On a yes: `schedule_newsletter_issue`. To hold it: `unschedule_newsletter_issue { issue_id }` (not once it is sending).
9. **Results.** `get_newsletter_results { issue_id }`: delivered, opens, clicks by link, unsubscribes, bounces.

### Journeys

10. `list_journeys { event_id }` shows the four fixed journeys (no-show → recording, attendee → recap and next event, new subscriber → welcome, invited not registered → reminder), whether each is on and how many people each would reach.

## Guardrails

- Keep double opt-in on unless the person asks; it is what makes the list first-party and consented. Ask only for fields the person will use.
- Nothing reaches subscribers without a yes in this conversation. If a send answers `needs_approval` with a url, say "Waiting for your OK in Sessionboard: <url>" and don't call it again.
- A sent issue is history and cannot change.
- Show emails only when the person asks; counts usually answer the question.

## Tools used

- `add_signup_form` — Add a sign-up form (write)
- `add_signup_question` — Add a question to a sign-up form (write)
- `count_signups` — Count sign-ups (read)
- `draft_newsletter_issue` — Draft a newsletter issue (write)
- `get_newsletter` — Get the newsletter (read)
- `get_newsletter_issue` — Get a newsletter issue (read)
- `get_newsletter_results` — Newsletter results (read)
- `list_journeys` — List journeys (read)
- `list_newsletter_issue_versions` — Newsletter issue versions (read)
- `list_signup_forms` — List sign-up forms (read)
- `list_subscribers` — List sign-ups (read)
- `publish_event_page` — Publish event page (write)
- `restore_newsletter_issue_version` — Restore a newsletter issue version (write)
- `schedule_newsletter_issue` — Send a newsletter issue (write)
- `send_newsletter_test` — Send a newsletter test to me (write)
- `unschedule_newsletter_issue` — Unschedule a newsletter issue (write)
- `update_newsletter` — Update newsletter (write)
- `update_newsletter_issue` — Edit a newsletter issue (write)
- `update_signup_form` — Update a sign-up form (write)
