---
name: track-event-budgets
description: "Track a Sessionboard event's budgets (flights, hotel rooms, speaker fees, AV, passes) against live record values, find who is missing a value, and test changes."
---

# Sessionboard: Track event budgets

A budget adds up a field across the event's records (speakers, sessions, sponsors, exhibitors): flights, hotel rooms, speaker fees, AV, catering or passes. Totals are live, with a status of on track, near the limit or over budget, and a per-record limit if the person wants one.

## When to use

"How are my budgets doing?", "which budgets are over?", "who are my most expensive speakers against Flights?", "who's still missing a flight estimate?", "set up a hotel budget of 60 rooms", "what if Ada's flight is $1,200?", "copy last year's budgets". Needs the Sessionboard MCP server's Program tools.

## Steps

1. **Read.** `list_budgets { event_id }`: each budget with used, remaining, percent and status.
2. **One budget.** `get_budget { event_id, budget_id }`: each record's contribution, largest first, plus records with no value and those over the per-record limit. `what_if` shows totals as if values were set, writing nothing.
3. **Make one.** `suggest_budgets { event_id }` first, so field names are never guessed: templates matched to this event's fields and which fields can be added up. Then `manage_budget { action: "create", event_id, name, record_type, fields, amount, dry_run: true }`. **Pause:** confirm the numbers. On a yes, call again without `dry_run`.
4. **Copy.** `manage_budget { action: "copy_from_event", event_id, source_event_id }` and say what was skipped.
5. **Before changing a cost.** `budget_impact { event_id, changes }` shows how each budget moves and whether a status changes ("this tips Flights over budget"). Tell the person, then change the record with its own tool on their yes.

## Guardrails

- Always dry-run creates and updates and confirm the numbers first.
- Deleting a budget removes the budget only; cost values stay. Confirm the name first.
- Quote totals as the tools give them; never round a status away.

## Tools used

- `budget_impact` — Budget impact (read)
- `get_budget` — Get budget (read)
- `list_budgets` — List budgets (read)
- `manage_budget` — Manage budget (write)
- `suggest_budgets` — Suggest budgets (read)
