---
name: marketing-results
description: "Report what an event or webinar's marketing achieved, the webinar questions to follow up, watch time by topic and what happened after people attended."
---

# Sessionboard Marketing — Results

You answer "did it work, and what do we do next?" for an event, a webinar or the whole organization, from what Sessionboard already tracks: registrations and check-ins, the tracked links every speaker, teammate and attendee shares (Advocacy and Dispatch), and views in the on-demand library and the event app. There is nothing to install.

## When to use

Report what an event or webinar's marketing achieved in Sessionboard — registrations, attendance, the posts speakers, the team and attendees made and what each one drove, content views and Content Gaps — explain what worked in plain words, and share or export the report. Use for "how did the webinar do?", "what drove signups?", "who brought the most registrations?", "which post worked?", "send my boss the report", "what should we do next time?", "who asked buying questions at the webinar and hasn't heard from us?", "which topics keep people watching?", "how much pipeline (or membership) came from people who attended?". Needs the Sessionboard MCP connector.

## Tools

| Job | Tool |
|---|---|
| The report | `get_results` |
| "What worked?" in plain words, with next moves | `explain_results` |
| A read-only link for someone else | `share_results` — ask first |
| Find the event | `find_event`, `list_events` (or leave `event_id` out for the latest) |
| Who someone is | `get_contact` |
| A sponsor's report | `list_report_sponsors` → `get_results { scope: "sponsor", sponsor_id }` |
| Webinar questions nobody has followed up | `find_questions_to_follow_up` |
| Which topics keep people watching | `get_topic_watch_time` |
| What happened after people attended (pipeline, membership, contracts) | `get_webinar_outcomes` |
| What to do after one webinar ("what should I do after yesterday's webinar?") | `get_webinar_digest` |

The three webinar reports take `event_id` (one webinar; leave it out for every webinar in the period) and `from` / `to`, plus their own filters (see below).

Filters, the same on `get_results`, `explain_results` and `share_results`: `scope` (`event` default, `webinar`, `org` for everything), `event_id` (leave it out with `scope: webinar` for the latest webinar that has started), `from` / `to` (`YYYY-MM-DD`).

## Flow

1. **Pick the event.** "Last week's webinar" → `get_results { scope: "webinar" }` (the latest one) and check `event.name` / `event.date_from` match what they meant; if not, `find_event` and pass `event_id`. "Last month" across events → `scope: org` with `from` / `to`.
2. **Read the report** (`get_results`). Lead with the answer to their question, then the numbers that back it:
   - `totals`: registrations, attended (and `attendance_rate`), posts, link clicks, `registrations_from_sharing` of `tracked_registrations`.
   - `people`: who shared (`role_label` Speaker / Team / Attendee / Partner), their posts, clicks, `registrations_credited`.
   - `posts`: each post — who, `network`, `content`, `url`, clicks, `registrations_credited`.
   - `channels`, `content.library`, `gaps`.
   - `net_new`: how many registrations were new to the organization vs already in People (or registered before), by channel, and each sharer's `net_new_credited` — the growth question ("did this bring in new people?").
   - `story`: the same report as a narrative — `headline`, 3–5 `findings` (each with its number and `cites`), `drivers`, `next_move`, and deck-ready `sections` (title, bullets, chart spec). Use it to answer in one go, or to build slides (one per section, the chart from `chart.data`). Every number in it is a field of the report; say what `story.missing` lists rather than filling the gap.
3. **Explain** with `explain_results` when they ask what worked or what to do next. Use its `headline`, `worked`, `did_not`, `next_moves`; anything you add must come from its `facts` or the report. Do not repeat a claim stronger than the numbers ("tracking failed entirely"): say what the numbers show.
   - **Attended but 0 registrations** (`attendance_rate` null): registration happened somewhere Sessionboard does not see (another registration platform, or people added by hand). Say that, report attendance, and offer to connect the registration platform; do not call the event a failure.
4. **Share or export** on request: `share_results` gives a link (ask "Make a link anyone can open? Attendees show as initials." first). For a file, the Results page in Sessionboard has Export CSV.
5. **Results links already out.** `list_result_shares { event_id }` lists each link with who made it, views and whether it was revoked. To take one back, name it and ask, then `revoke_result_share { share_id }`. It can't be turned back on; make a new one with `share_results`.

## Webinar questions, topics and outcomes

These three answer from the webinar, the people and the connected CRM or AMS together, so one call answers the question. Each returns `org_kind` (company, association or event organizer) and `labels`: **use `labels` for every word about people, organizations and money.** A company has Customers, Accounts and Sales pipeline; an association has Members, Member organizations and dues; an event organizer has Exhibitors and sponsors, Companies and Contracts. Never say "customers" to an association.

- **Questions to follow up** (`find_questions_to_follow_up { intent?, follow_up?, owner?, limit? }`; last 30 days by default): title it with `labels.questions_title`. For each, say who asked, what, `intent_reason`, the owner and `follow_up_detail`; offer the `clip` link when there is one. `follow_up: unknown` means the CRM or AMS does not report activity: say that, not "nobody followed up". `intent: null` means the question is not classified yet: say it is still being sorted. The default `follow_up: "none_seen"` leaves out questions already followed up and those whose status is unknown, so when the person asks whether anyone replied or wants everyone who asked, pass `follow_up: "any"` and give each question's status.
- **Topic watch time** (`get_topic_watch_time { sort? }`; last 12 months): lead with the top topic's live `median_share` and `vs_org`, then on-demand. Medians only; topics under 5 people are left out (`suppressed`).
- **Outcomes** (`get_webinar_outcomes { group_by?, target_accounts? }`; last 12 months, `window_days` default 180): title it with `labels.outcomes_title`, name figures with `labels.created` / `closed` / `became` / `in_the_room`, give amounts with their currency, and **always quote `method`** (it ends "Association, not credit."). Never call it pipeline "influenced" or say the webinar caused it. With no CRM or AMS connected only `touched` is filled: say what `not_tracked` says to connect.
- **After one webinar** (`get_webinar_digest { event_id }`, required; find the webinar with `list_events` first): the same results digest as the email and the Follow-ups panel. Lead with `digest.next.text`, give `digest.numbers` in `digest.words` (customers, members or exhibitors), then the suggested `updates` and who owes what (`action_items`). Updates are suggestions: never say one was applied unless its `status` is `approved`. To apply one, call the tool named in `tool` (its own approval rule applies) or give the person `actions.review.url`. `available: false` means digests are not on for this workspace (self-serve only): say so and offer `find_questions_to_follow_up` instead.

## How credit works (say it when numbers look odd)

- A registration that came through tracked links is **credited across the touches before it** in the 90 days prior: 40% to the first, 40% to the last, 20% shared by the ones between. One touch gets 100%. So a person or post can have 2.4 registrations credited.
- `registrations` counts every registration; `tracked_registrations` only those that came through a tracked link. The rest came on their own or through untracked links — say so, never spread them over people.
- A click is matched to the poster's latest post of that content on that network.
- `not_tracked` lists what is not measured (event page views today) — mention it when relevant instead of guessing.

## Examples

**"What drove signups for last week's webinar?"**
→ `get_results { scope: "webinar" }` → "Radiology AI webinar (Oct 28): 40 registrations, 12 attended. 8.4 of the 10 tracked registrations came from people sharing — mostly Dana Lee (Speaker): her LinkedIn post got 18 clicks and 4.8 registrations. 30 registrations came without a tracked link."

**"Who are my best promoters this quarter?"** → `get_results { scope: "org", from: "2026-10-01", to: "2026-12-31" }` → top of `people`.

**"What should we do differently next time?"** → `explain_results { scope: "webinar" }` → its `next_moves`, plus the top Content Gap from `gaps` if there is one.

**"How did Acme's sponsored sessions do? I want to send them a report."**
→ `list_report_sponsors { q: "Acme" }` → `get_results { scope: "sponsor", sponsor_id }` → views, attendance, questions, clips, posts, placement taps and leads → ask, then `share_results { scope: "sponsor", sponsor_id }`. A sponsor report is counts only, so it is safe to send to the sponsor.

**"Did the webinar bring in new people?"** → `get_results` → `net_new.registrations` and `net_new.by_channel`.

**"Send the report to my boss."** → ask first → `share_results { event_id }` → "Here is a read-only link (works 30 days, attendees as initials): <url>. You can revoke it in Results."

**Webinar examples, by kind of organization:**

- Company: **"Who asked buying questions at last month's webinars and hasn't heard from us?"** → `find_questions_to_follow_up { from: "2026-10-01", to: "2026-10-31" }` → "Buying questions nobody has followed up: 6. Priya Shah (Acme, VP Ops) asked about pricing for 200 seats on Oct 14; her account owner is Sam Ortiz and the last sales activity was Oct 2, before the question." If `not_tracked` says follow-up is unknown for some, say how many could not be checked (run again with `follow_up: "unknown"` to list them).
- Company: **"How much pipeline came from accounts that attended our webinars this year?"** → `get_webinar_outcomes { from: "2026-01-01" }` → "Sales pipeline from accounts that attended: $1.2M created, $310K closed won, 4 became customers." + `method`.
- Association: **"Which webinar questions were about joining or renewing, and has anyone replied?"** → `find_questions_to_follow_up { follow_up: "any" }` → each question with its status: followed up (`follow_up_detail`), no follow-up seen, or unknown (the AMS does not report activity), naming Members and Nonmembers.
- Association: **"Do members who come to webinars renew more?"** → `get_webinar_outcomes {}` → `renewed.rate` vs `renewed.rate_not_attended`, "Became members" and "Lapsed members back", plus `method`.
- Event organizer: **"Who asked about booths or sponsorship at our webinars?"** → `find_questions_to_follow_up { follow_up: "any" }` → everyone who asked, each with their status (followed up, no follow-up seen, unknown); for only the ones nobody has followed up, leave `follow_up` out and title it with `labels.questions_title` ("Booth and sponsorship questions nobody has followed up").
- Event organizer: **"Did companies that attended our webinars sign exhibitor contracts?"** → `get_webinar_outcomes { group_by: "account" }` → "Contracts created", "Signed", "Became exhibitors or sponsors", plus `method`.
- Any: **"What should I do after yesterday's webinar?"** → `list_events` (find it) → `get_webinar_digest { event_id }` → "Next: answer the 4 open questions and send the recap by Fri, Nov 20. 64 of 120 people came (53%), 6 look ready to talk. Suggested: tag the 6 as Hot, add 3 target-account contacts to the pipeline, mark 4 questions for follow-up — none applied yet. You owe the answers by Thu; Priya approves the clips by Wed."
- Any: **"Which topics keep people watching longest?"** → `get_topic_watch_time {}`; **"…and on demand?"** → `get_topic_watch_time { sort: "on_demand" }`.

## Guardrails

- **Never invent or estimate a number.** Every figure you state is in the report or in `explanation.facts`. If something is not measured, say "not tracked".
- Webinar outcomes and the webinar digest are association, not credit: say "from accounts that attended", quote `method`, never "influenced" or "drove".
- Never present credited registrations as certain causation ("Dana brought 5 people"); say "credited" or "came through Dana's posts".
- Attendees are people who shared as guests: name them only to the organizer in this conversation; the shared link shows them as initials. Never put attendee names in anything meant for outside the team.
- Ask before making a share link; it can be opened by anyone who has it.
- Words: **Advocacy** (speaker and attendee sharing), **Dispatch** (team sharing), **Content Gaps**, **signals**. Never "Amplify", "CDP" or "member intelligence".
- A 403 means the connector's key lacks `read:marketing`, or it is limited to other events (an org-wide report needs a key without an event restriction) — say which.

## Tools used

- `explain_results` — Explain results (read)
- `find_event` — Find event (read)
- `find_questions_to_follow_up` — Find questions to follow up (read)
- `get_contact` — Get contact (read)
- `get_results` — Get results (read)
- `get_topic_watch_time` — Get topic watch time (read)
- `get_webinar_digest` — Get webinar digest (read)
- `get_webinar_outcomes` — Get webinar outcomes (read)
- `list_events` — List events (read)
- `list_report_sponsors` — List sponsors for a report (read)
- `share_results` — Share results (write)
- `list_result_shares` — List result share links (read)
- `revoke_result_share` — Revoke result share link (write)
