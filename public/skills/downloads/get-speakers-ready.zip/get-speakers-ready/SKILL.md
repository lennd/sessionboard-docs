---
name: get-speakers-ready
description: Find what each speaker and session in a Sessionboard event is still missing, and fix records after you confirm each change.
---

# Get your speakers ready

The person gets a speaker list for the event with what is still missing per speaker and per session, and the fixes they confirm made in Sessionboard. It works for any Sessionboard organization: a self-serve Sessions workspace and a full-platform account use the same tools. Plan limits and role permissions are enforced by Sessionboard, not by you.

## When to use

Use this when someone wants to know who is speaking at an event, what is still missing for each speaker or session (job title, company, bio, headshot, session description, time, room), and fix the records they confirm. Triggers on "who's speaking at the summit?", "list our speakers", "which speakers are missing a bio?", "who hasn't sent a headshot?", "which sessions have no description?", "what's missing before we go live?", "is everyone's job title filled in?", "fix Dana's company to Acme", "update the panel description", "speaker readiness report".

## Before you start

- The Sessionboard connector is signed in with OAuth as the person.
- Scopes: `read:sessions` for speakers, sessions and the agenda; `read:contacts` for contact records; `read:insights` for questions answered with `query_data`; `write:sessions` to change a session; `write:contacts` to change a contact.
- Sessionboard applies the person's own permissions. The Sessions tools let any organization member who can use the event read and need an organization admin to change; a role that sees only some contacts is refused there and uses the event's pages.
- `list_event_speakers` works on both a Sessions event and a full-platform event.
- The Sessions tools (`list_event_speakers`, `get_event_agenda`, `get_call_questions`, `manage_program_session`) take the event id as a number. The platform record tools (`list_sessions`, `get_session`, `list_contacts`, `get_contact`, `manage_session`, `manage_contact`, `list_metadata`, `query_data`) take it as a string (`"6815"`). Speaker `contact_id`s and session ids are the same in both.
- Personal data is not masked: names, emails and phone numbers come back as stored. Share only what the person needs.

## Guardrails (read first)

- **Confirm before every write.** Before `manage_contact`, `manage_session` or `manage_program_session`, show the record, each field's current and new value, and get a clear yes in this conversation. One yes can cover a list of fixes you showed field by field. Never infer a yes from an earlier answer or a plan. Reads need no confirmation.
- **Only fix what the person gives you.** Never invent a bio, title or company. Drafting a bio from the session description is fine only if the person asks, and it is shown before saving.
- **Read right before you write.** `manage_contact` and `manage_session` updates need the record's current `updated_at` from `get_contact` / `get_session`. A 409 means it changed: read again, show the new values, ask again.
- Changing a speaker's email changes who Sessionboard reaches. Ask twice.
- Nothing here emails speakers. Say so if the person expects a reminder to go out.
- Words: "speaker", "session", "submission". Never "evaluation". Never name the in-product assistant or internal engines.

## The workflow

### 1. Who is speaking
- `list_event_speakers { event_id }` (Sessions and full-platform events): each speaker's `contact_id`, name, email, job title, company and sessions, plus the plan's speaker `limit`. Speakers linked with no accepted session show `sessions: []`.
- Any event: `list_contacts { event_id, page?, limit? }` (up to 100 a page) for every contact on the event.
- Lead with the count, then call out first anyone with `sessions: []` as "not on an accepted session", then a table: name, title, company, sessions.

### 2. What is missing
1. Standard fields: flag empty job title, company or email straight from step 1.
2. Bio, headshot and other speaker answers: `get_call_questions { event_id }` lists the speaker questions with `answered` (how many already have an answer). Say "Bio: 18 of 25 answered".
3. Per person: `get_contact { event_id, contact_id }` returns the full record with its stored fields. Its names differ from what `manage_contact` writes: it reads `company_name` (written as `company`), `title` (job title), `about` (the bio), `photo_url` (the headshot) and `phone_mobile` (written as `phone`). An empty `about` is a missing bio; an empty `photo_url` is a missing headshot.
4. Across everyone at once: `query_data { prompt, event_id }`, e.g. "speakers with no bio" or "sessions without a description". Read the returned `query` and `explanation` before trusting the rows: it may narrow the question on its own (for example to accepted sessions only). If the rows contradict step 1 (0 rows while the speakers you listed clearly lack the field), say so and fall back to `get_contact` per speaker. It returns up to 50 rows; if `truncated`, say so and narrow the question.
5. Sessions: `get_event_agenda { event_id }` (Sessions events) shows sessions with no time, room or track. `list_sessions { event_id }` / `get_session { event_id, session_id }` show any session in full (description, status, times). The session list can lag about two minutes behind a change; `get_session` is current.
6. **Pause:** show a readiness list per speaker and per session (what is missing). Ask what to fix and with what values.

### 3. Fix a speaker's record
1. `get_contact { event_id, contact_id }` for the current values and `updated_at`.
2. **Pause:** show current → new for each field, using the names from step 2.3 (current `company_name` → new `company`, `phone_mobile` → `phone`). On yes:
   `manage_contact { action: "update", event_id, contact_id, updated_at, first_name?, last_name?, company?, title?, phone?, email? }`.
3. A speaker who is not a contact yet: `manage_contact { action: "create", event_id, email, first_name?, last_name?, company?, title?, phone? }` (finds the existing contact by email or creates one). This does not put them on a session.

### 4. Fix a session
- Sessions events, simplest: `manage_program_session { action: "update", event_id, session_id, title?, description?, starts_at?, ends_at?, room_id?, track_id?, sponsor_ids? }`.
- Any event: `get_session { event_id, session_id }` for `updated_at`, then `manage_session { action: "update", event_id, session_id, updated_at, title?, description?, status?, starts_at?, ends_at?, capacity? }`. Room, tracks and tags are not changed by this update; use the `build-the-agenda` skill.
- A custom session field: find its `internal_name` with `list_metadata { event_id, entity_type: "field" }`, then `manage_session { action: "update_fields", event_id, session_id, values: [{ internal_name, value, language? }] }`.
- **Pause** before each, showing current → new.

### 5. Report
Read the records again and give the updated readiness list: what is done, what is still missing and who it waits on.

## When something goes wrong

- Sessions tools: 403 "Forbidden … read:sessions …" (scope or not an organization admin); `trial_ended` / `plan_ended` (read-only); 404 (check ids with `list_event_speakers` / `get_event_agenda`).
- Record tools return "Error: API <status> …": 403 "Token missing required scope: …" names the scope to add (reconnect the connector); 409 means `updated_at` is stale: read again and re-confirm; 404 a wrong id or the record is not on this event; 400 says what to fix.
- `query_data` errors usually mean the question could not be turned into a query: rephrase it more concretely.

## What this skill does not do

- Cannot write a contact's bio, headshot or other custom contact fields: `manage_contact` sets name, email, company, job title and phone only. The person updates the rest in Sessionboard or the speaker sends it through the call.
- Cannot upload a headshot or slides.
- Cannot add a speaker to an existing session or remove one.
- Does not email speakers or send reminders for missing items; there is no speaker portal in Sessions.

## Tools used

- `list_event_speakers` — speakers on an event with title, company, sessions, plan limit (read)
- `get_call_questions` — speaker questions and how many have answers (read)
- `get_event_agenda` — sessions without a time, room or track (read)
- `list_contacts` — every contact on an event (read)
- `get_contact` — one contact in full, with `updated_at` (read)
- `list_sessions` — an event's sessions (read)
- `get_session` — one session in full, with `updated_at` (read)
- `query_data` — a plain-English question across the event's data, read-only (read)
- `list_metadata` — session fields and their internal names (read)
- `manage_contact` — create or update a contact's standard fields (write)
- `manage_session` — update a session or its custom fields (write)
- `manage_program_session` — update a session on a Sessions event (write)
